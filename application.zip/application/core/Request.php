<?php


class Request extends CI_Controller{
    
   public static function post($keys=[]){
		$return = $_POST;
		if(empty($keys)){
			return $return;
		}
		if(!is_array($keys)){
			$keys = [$keys];
		}
		for($i=0; $i<count($keys); $i++){
			if(isset($return[$keys[$i]])){
				if($i === count($keys)-1){
					return $return[$keys[$i]];
				}else{
					$return = $return[$keys[$i]];
				}
			}else{
				break;
			}
		}
		return '';
	}
//	public static function postWrap($keys, $wraps){
//		return Text::wrap($wraps, self::post($keys));
//	}
}
