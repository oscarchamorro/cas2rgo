<?php 
 
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.orient.com.co';
$config['smtp_user'] = 'no-reply@orient.com.co';
$config['smtp_pass'] = 'Colombia.2018';
$config['smtp_port'] = 587;
 
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n"; 