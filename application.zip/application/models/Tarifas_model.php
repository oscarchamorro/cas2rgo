<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tarifas_model extends CI_Model{
    
    public function get_tarifas(){
        if($this->input->post('hertz')){
            $provider = $this->input->post('hertz');
            
        $this->db->select('porcentaje');
        $this->db->from('tarifas');
        $this->db->where('proveedor',$provider);
        $this->db->where('estado',1);
        $query = $this->db->get();
        return $query->result();
        }else
            if($this->input->post('dollar')){
            $provider = $this->input->post('dollar');
            
        $this->db->select('porcentaje');
        $this->db->from('tarifas');
        $this->db->where('proveedor',$provider);
        $this->db->where('estado',1);
        $query = $this->db->get();
        return $query->result();
        
        } else 
            if($this->input->post('thrifty')){
            $provider = $this->input->post('thrifty');
            
        $this->db->select('porcentaje');
        $this->db->from('tarifas');
        $this->db->where('proveedor',$provider);
        $this->db->where('estado',1);
        $query = $this->db->get();
        return $query->result();
        }
       else{
           echo '1.05';
       }
        
    }
}
