<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Carlist_model extends CI_Model{
    public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }
    public function get_mantenimiento(){
            $this->db->select('estado');
            $this->db->from('mantenimiento');
            $query = $this->db->get();
            return $query->result();
    }
}
