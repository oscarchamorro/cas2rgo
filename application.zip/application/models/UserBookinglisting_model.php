<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class UserBookinglisting_model extends CI_Model{
    public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }
        public function get_bookinglist($email){
            $this->db->select('id,recogida, devolucion, referencia, nombre, apellido, correo, phone1, reservaid, amount, currencycode, model, vehicle, vendor, fechadesolicitud, pago, estado, responsepasarella');
            $this->db->from('reserva');
            $this->db->where('estado != ',2);
            $this->db->where('correo',$email);
            $this->db->where("(responsepasarella='APPROVED' OR responsepasarella='APPROVAL')", NULL, FALSE);
            $this->db->order_by('id','DESC');
            $query = $this->db->get();
            return $query->result();
        }
        public function get_picklocaionbyid($pickuplocation){
             //echo $pickuplocation;
            $pickuplocation = explode(',',$pickuplocation);
             foreach($pickuplocation as $pickuplocations){
                 
            $this->db->select('city, address1, ZipCode');
            $this->db->from('locations');
            $this->db->where('oag_code',$pickuplocations);
            $query = $this->db->get();
            return $query->result();
        } }
        public function get_droplocaionbyid($droplocation){
            $droplocation = explode(',',$droplocation);
            foreach($droplocation as $droplocations){
                
            $this->db->select('city, address1, ZipCode');
            $this->db->from('locations');
            $this->db->where('oag_code',$droplocations);
            $query = $this->db->get();
            return $query->result();
        }
        }
        public function get_canceledlist($email){
           $this->db->select('recogida, devolucion, referencia, nombre, apellido, correo, phone1, reservaid, amount, currencycode, model, vehicle, vendor, fechadesolicitud, pago, estado, responsepasarella');
            $this->db->from('reserva');
            $this->db->where('estado',2);
            $this->db->where('correo',$email);
            $this->db->order_by('id','DESC');
            $query = $this->db->get();
            return $query->result();
        }
        public function get_rejectedlist($email){
            $this->db->select('recogida, devolucion, referencia, nombre, apellido, correo, phone1, reservaid, amount, currencycode, model, vehicle, vendor, fechadesolicitud, pago, estado, responsepasarella');
            $this->db->from('reserva');
            $this->db->where('reservaid != ','WAIT');
            $this->db->where('correo',$email);
            $this->db->where("(responsepasarella='INVALID CARD' OR responsepasarella='DECLINED')", NULL, FALSE);
            $this->db->order_by('id','DESC');
            $query = $this->db->get();
            return $query->result();
        }
        public function get_userprofile(){
            $this->db->select('');
            $this->db->from('');
            $this->db->where('');
            $this->db->order_by('');
            $query = $this->db->get();
            return $query->result();
        }
        public function cancel_cars(){
            $uid = $this->input->get('id');
            $field = array(
                    'estado' => 2,
            );
            $this->db->where('id', $uid);
            $this->db->update('reserva', $field);
            if($this->db->affected_rows() > 0){
                    return true;
            }else{
                    return false;
            }
        }
        public function getcars_byid($id){
            $this->db->where('id',$id);
            $query = $this->db->get('reserva');
            return $query->result();
        }
        public function reservation_cancel_update($canid){
            $data =array(
                'estado'=> 2
            );
            $this->db->where('reservaid',$canid);
            $this->db->update('reserva',$data);
            if($this->db->affected_rows() > 0){
                    return true;
            }else{
                    return false;
            }
        }
}
