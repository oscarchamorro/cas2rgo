<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgetpassword_model extends CI_Model{
   
     public function reset_password_insert($mail,$tokens){
            $this->db->where('email',$mail);
             $this->db->update('registro',$tokens);
             return $tokens;
        }
    public function reset_password($tokens,$pass){
       
            $passd= array('password'=>$pass);
             $this->db->where('token',$tokens);
             $this->db->update('registro',$passd);
             $this->db->where('token',$tokens);
	     $result = $this->db->get('registro');
             return $result->result();
             //return $tokens;
        }
}
