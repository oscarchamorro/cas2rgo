<?php
defined('BASEPATH') OR exit('No direct script access allowed');

   class User_model extends CI_Model{
    public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }

		// Log user in
    public function login($email, $password){
                // Validate
                $this->db->where('email', $email);
                $this->db->where('password', $password);
                $this->db->where('activo',1);
                $result = $this->db->get('registro');
                if($result->num_rows() == 1){
                        return $result->row(0)->id;
                } else {
                        return false;
                }
        }



        // Check email exists
    public function check_email_exists($email){
                $query = $this->db->get_where('registro', array('email' => $email));
                if(empty($query->row_array())){
                        return true;
                } else {
                        return false;
                }
        }
    public function get_user_data($user_id){
//                    $query = $this->db->get_where('usersauth', array('user_id' => $user_id));
//			return $query->result_array();
                $this->db->select('*');
                $this->db->from('registro');
                $this->db->where('id', $user_id);	
                $query = $this->db->get();

                $user_data = array(
                        'user_id'=> $query->row('id'),
                        'name'	=> $query->row('names1'),
                        'lastname'=> $query->row('lastname1'),
                        'email'=> $query->row('email'),
                        'phone'=> $query->row('phone'),
                        'password'=> $query->row('password'),
                        );

                 return $user_data;
                }
    public function register_user($status,$password){
        if($this->input->post('company')!='' and $this->input->post('ssn_tin')!=''){
            $discount = 1.05;
        }else{
            $discount = 0;
        }
            $data = array(
                        'names1' => $this->input->post('names1'),
                        'lastname1' => $this->input->post('lastname1'),
                        'email' => $this->input->post('email'),
                        'phone' => $this->input->post('phone'),
                        'country' => $this->input->post('country'),
                        'city' => $this->input->post('city'),
                        'address' => $this->input->post('address'),
                        'postalcode' => $this->input->post('postalcode'),
                        'termns' => $this->input->post('termns'),
                        'perfil' => 2,
                        'commission' => $discount,
                        'company' => $this->input->post('company'),
                        'ssn_tin' => $this->input->post('ssn_tin'),
                        'date' => date('Y-m-d H:i:s'),
                        'activo' => $status,
                        'password' =>$password
                    );
			// Insert user
			 $this->db->insert('registro', $data);
                        return $data;
        }

    public function getcurrentuserdata($user_id){
            $this->db->select('*');
            $this->db->from('registro');
            $this->db->where('id', $user_id);	
            $query = $this->db->get();
            return $query->result();
    }
    public function update_userprofile($data,$userid){
            // print_r($data);die;
            $this->db->where('id', $userid)->update('registro', $data);  
            return $userid;

        }
   
}