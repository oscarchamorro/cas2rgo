<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PickupandDropLocation_model extends CI_Model{
    
    public function getpickuplocation($term){
      
        $query = $this->db->select("vendor, oag_code, Country, state1, city, description",FALSE);
		$this->db->where('vendor !=','ZT');
		$this->db->where("CONCAT(Country, state1, city, description) LIKE '%".$term."%'");
		$this->db->order_by("(CASE
        WHEN description LIKE '%Airport%' THEN 1
        ELSE 2 END)",'ASC');
		$this->db->limit(10); 
        $query = $this->db->get('locations');
       
        return $query->result();
    }
    public function getdroplocation($term){
        $this->db->select('vendor, oag_code, Country, state1, city, description');
        $this->db->from('locations');
        $this->db->where('vendor !=','ZT');
        $this->db->where("CONCAT(Country, state1, city, description) LIKE '%".$term."%'");
        $this->db->order_by("(CASE
        WHEN description LIKE '%Airport%' THEN 1
        ELSE 2 END)",'ASC');
        $this->db->limit(10); 
        $query = $this->db->get();
        return $query->result();
    }
}
