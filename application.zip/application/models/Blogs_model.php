<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogs_model extends CI_Model{
    
    public function get_bloglit(){
        $this->db->select('*');
        $this->db->from('blog');
        $this->db->where('active',1);
        $query = $this->db->get();
        return $query->result();
    }
     public function get_blogdetail($blogid){
         
        $this->db->select('*');
        $this->db->from('blog');
        $this->db->where('id',$blogid);
        $query = $this->db->get();
        return $query->result();
    }
}
