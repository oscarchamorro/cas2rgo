<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class History_model extends CI_Model{
   public function __construct()
        {
            parent::__construct();
            $this->db = $this->load->database("default",TRUE);
        }
        public function get_history_Approved(){
            $this->db->select('*');
            $this->db->from('reserva');
            $this->db->order_by('id','DESC');
            $this->db->where('responsepasarella','APPROVED');
            $query = $this->db->get();
            return $query->result();
        }
        public function get_history_locationbyID(){
            $id = $this->input->get('id');
		$this->db->where('id', $id);
		$query = $this->db->get('reserva');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
            
        }
}
