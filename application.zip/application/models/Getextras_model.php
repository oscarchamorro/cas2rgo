<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Getextras_model extends CI_Model{
    
    public function getextras_location(){
        $location = $this->input->post('location');
        $vendor = $this->input->post('vendor');
        $this->db->select('CSIDailyRate, CSTDailyRate, BSTDailyRate, NEVDailyRate, SKVDailyRate, '
                . 'SNODailyRate, SBRDailyRate, SRCDailyRate, HMMDailyRate, '
                . 'LDWDailyRate, SDWDailyRate, LISDailyRate, PPIDailyRate, TPDailyRate, PKGDailyRate');
        $this->db->from('locations');
        $this->db->where('OAG_CODE',$location);
        $this->db->where('VENDOR',$vendor);
        $query= $this->db->get();
        return $query->result();
    }
    public function tarifas_agentopeators(){
       $operator = $this->input->post('operator');
        $this->db->select('discount');
        $this->db->from('registro');
        $this->db->where('id',$operator);
        $query= $this->db->get();
        return $query->result();
    }
    public function tarifas_agentopeatorcomissions(){
        $operators = $this->input->post('operator');
        $this->db->select('commission, payment');
        $this->db->from('registro');
        $this->db->where('id',$operators);
        $query= $this->db->get();
        return $query->result();
    }
}
