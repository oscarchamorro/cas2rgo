<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paynow_Model extends CI_Model{
    
    public function save_paymentdone($data){
        return $this->db->insert('reserva',$data);
    }

    public function getdatauser_byid($email){
        $this->db->select('phone, perfil, commission, payment');
        $this->db->from('registro');
        $this->db->where('email',$email);
        $query = $this->db->get();
        return $query->result();
    }
    public function mantenimientopagos(){
        $this->db->select('estado');
        $this->db->from('mantenimiento_pagos');
        $query = $this->db->get();
        return $query->result();
    }
   
    public function updateAfter_payment($data,$emilid,$referencia){
        $this->db->where('referencia',$referencia);
        $this->db->where('correo',$emilid);
        $this->db->update('reserva',$data);
        return $data;
         
    }
    public function updateAfter_getdata($approved,$email,$referencia){
        $this->db->select('*');
        $this->db->from('reserva');
        $this->db->where('responsepasarella',$approved);
        $this->db->where('correo',$email);
        $this->db->where('referencia',$referencia);
        $query = $this->db->get();
        return $query->result();
    }
    public function getfinal_update($id,$data){
        $this->db->where('id',$id);
        $this->db->update('reserva',$data);
        return $data;
         
    }
    public function getdata_invoice($emilid,$referencia){
        $this->db->select('recogida, devolucion, nombre, apellido, correo, phone1, reservaid, amount, currencycode, model, vehicle, vendor, fechadesolicitud, responsepasarella');
        $this->db->from('reserva');
        $this->db->where('id',$emilid);
        $this->db->where('referencia',$referencia);
        $query = $this->db->get();
        return $query->result();
    }
    public function getdata_invoiceCancel($id,$referencia){
        $this->db->select('recogida, devolucion, nombre, apellido, correo, phone1, reservaid, amount, currencycode, model, vehicle, vendor, fechadesolicitud, responsepasarella');
        $this->db->from('reserva');
        $this->db->where('id',$id);
        $this->db->where('referencia',$referencia);
        $query = $this->db->get();
        return $query->result();
    }
    public function get_pickup($plocatio){
        $recogida = explode(',',$plocatio);
        foreach ($recogida as $recogidas){
        $this->db->select('vendor, oag_code, Country, state1, city, description');
        $this->db->from('locations');
        $this->db->where('oag_code',$recogidas);
        $query = $this->db->get();
        return $query->result();
        }
    }
    public function get_drop($dlocatio){
         $devolucion = explode(',',$dlocatio);
        foreach ($devolucion as $devolucions){
        $this->db->select('vendor, oag_code, Country, state1, city, description');
        $this->db->from('locations');
        $this->db->where('oag_code',$devolucions);
        $query = $this->db->get();
        return $query->result();
    }
    }
}
