<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>Forget Password</h1>
                        <!--<p>Cras eros lorem, rhoncus ac risus sit amet, fringilla ultrices purus.</p>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="<?= base_url('assets/js/sweetalert.min.js')?>"></script>
<?php if( $this->session->flashdata('password_changed')){ ?>
<script>
	Swal.fire('<?php echo  $this->session->flashdata('password_changed'); ?>')
</script>
<?php  } ?>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2 class="mb-30">Reset Password In Here!</h2>
                    <?php echo form_open('passwordreset?token='.$this->input->get('token')); ?>
                    <div class="rn-contact-form">
                            <div class="row mb-30">
                                <div class="col-12 mb-30">
                                    <div class="rn-icon-input">
                                        <i class="far fa-user"></i>
                                        <input type="hidden" name="token" value="<?php echo $this->input->get('token'); ?>">
                                        <input type="text" name="pass" placeholder="New Password">
                                        <?php echo form_error('pass'); ?>
                                    </div>
                                </div>
                                <div class="col-12 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="far fa-user"></i>
                                        <input type="password" name="passconf" placeholder="Conform Password">
                                        <?php echo form_error('passconf'); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <input class="btn btn-main btn-lg btn-block btn-shadow" type="submit" value="Reset Password">
                            </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
                <!--<div class="col-md-6">
                    <img src="<?//= base_url('assets/images/login.png')?>" class="img-fluid slide-it" />
                </div>-->
            </div>
        </div>
    </section>

 