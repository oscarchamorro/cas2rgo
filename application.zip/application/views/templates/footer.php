<footer class="rn-footer">
        <div class="rn-footer-widgets">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <section class="rn-widget">
                            <h2 class="rn-widget-title">About Us</h2>
                            <div class="rn-widget-content">
                                <a class="brand-name" href="<?= base_url() ?>">
                                    <img src="<?= base_url('assets/images/logo-dark.png')?>" class="img-fluid" alt="Logo">
                                </a>
                                <p>Cars2Go, general sales agent of Hertz International, Dollar and Thrifty, has been operating for more than 10 years with a large structure focused mainly on serving the market of Tourism Agencies, Operators and Consumers. Through this site, you will find a wide variety of cars and rates to facilitate your quotes, reservations and Issue vouchers.</p>
                                <ul class="rn-widget-social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                </ul>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-5">
                        <section class="rn-widget">
                            <h2 class="rn-widget-title">Quick Links</h2>
                            <div class="rn-widget-content">
                                <div class="row rn-quick-links">
                                    <div class="col-6">
                                        <ul>
                                            <li><a href="<?= base_url('abouts') ?>">About Us</a></li>
                                            <li><a href="<?= base_url('contacts') ?>">Contact Us</a></li>
                                            <li><a href="<?= base_url('blogs') ?>">Blog</a></li>
                                            <li><a href="<?= base_url('locations') ?>">Locations</a></li>
                                            <li><a href="<?= base_url('faq') ?>">FAQs</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-6">
                                        <ul>
                                            <li><a href="<?= base_url('termsandconditions') ?>">Terms and Conditions</a></li>
                                            <li><a href="https://www.privacypolicies.com/privacy/view/5e66e5998f269b496f491cf3955b10d4" target="_blank">Privacy Policy</a></li>
                                            <li><a href="#">Help</a></li>
                                            <li><a href="<?= base_url('user_auth/login') ?>">Sign In</a></li>
                                            <li><a href="<?= base_url('user_auth/userregister') ?>">Register / Join Now</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-3">
                        <section class="rn-widget">
                            <h2 class="rn-widget-title">Contact Us</h2>
                            <div class="rn-widget-content">
                                <div class="rn-icon-contents">
                                    <div class="rn-phone rn-icon-content">
                                        <div class="rn-icon">
                                            <i class="lnr lnr-phone"></i>
                                        </div>
                                        <div class="rn-info">
                                            <ul>
                                                <li>(954)-944-1250</li>
                                                <li>(954)-944-1251</li>
                                            </ul>
                                        </div>
                                    </div>
									
                                    <div class="rn-email rn-icon-content">
                                        <div class="rn-icon">
                                            <i class="lnr lnr-envelope"></i>
                                        </div>
                                        <div class="rn-info">
                                            <ul>
                                                <li>info@cars2gorentals.com</li>
                                            </ul>
                                        </div>
                                    </div>
                                   <div class="rn-address rn-icon-content">
                                        <div class="rn-icon">
                                            <i class="lnr lnr-map-marker"></i>
                                        </div>
                                        <div class="rn-info">
                                            <ul>
                                                <li>8300 NW 53rd St</li>
                                                <li>Miami, FL 33166</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
        <div class="rn-footer-copyright">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <p>Copyright © Cars2go Rentals <?php echo date('Y') ?>. All rights reserved. Powered by: <a href="https://www.astintechnology.com/" target="_blank">Astin Technology Pvt. Ltd.</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="<?= base_url('assets/js/jquery.min.js')?>"></script>
    <script src="<?= base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?= base_url('assets/js/slick.js')?>"></script>
    <script src="<?= base_url('assets/libs/bootstrap/js/bootstrap.min.js')?>"></script>
    <script src="<?= base_url('assets/js/starrr.min.js')?>"></script>
    <script src="<?= base_url('assets/js/jquery.magnific-popup.min.js')?>"></script>
    <script src="<?= base_url('assets/js/scripts.js')?>"></script>
    <script type="text/javascript" src="<?= base_url('js/jquery.flexisel.js')?>"></script>
    <script defer src="<?= base_url('js/jquery.flexslider.js')?>"></script>
    <script defer src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script defer src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
     <script src="<?= base_url('dataget_jsfile/pickup_drop_js/pickup_drop.js')?>"></script>
     <script src="<?= base_url('validation_js/jquery.validate.js')?>"></script>
     <script src="<?= base_url('validation_js/registeration_validation.js')?>"></script>
     <script src="<?= base_url('assets/js/sweetalert.min.js'); ?>"></script>
     <script src="<?= base_url('assets/js/print.js')?>"></script>
    <script src="<?= base_url('assets/jquery-ui.min.js')?>"></script>
<script type="text/javascript">
$(function () {
    $(".pickupdates").datepicker({
        dateFormat: "yy-mm-dd",
        numberOfMonths: 1,
        orientation: "bottom left",
        minDate: 0,
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $(".dropdates").datepicker("option", "minDate", dt);
        }
    });
    $(".dropdates").datepicker({
        dateFormat: "yy-mm-dd",
        numberOfMonths: 1,
        onSelect: function (selected) {
            var dt = new Date(selected);
            dt.setDate(dt.getDate() + 1);
            $(".pickupdates").datepicker("option", "maxDate", dt);
        }
    });
});

function hideCalandar(){
    $('#ui-datepicker-div').hide();
}
</script>
    <script>
        $(document).ready(function () {
            $(".tabLink").click(function(e){
                var cat= $(this).attr('class');
                if(cat == "tabLink active"){
                    $(".sliding-tabs").slideUp();
                    $(this).removeClass('active');
                    $(this).children('i').attr('class','fa fa-angle-right fa-pull-right')
                }
                else if(cat == "tabLink"){
                    $(".tabLink i").attr('class','fa fa-angle-right fa-pull-right');
                    $(this).children('i').attr('class','fa fa-angle-down fa-pull-right');
                    $(".sliding-tabs").attr('data-index',0);
                    $(".tabLink").removeClass('active');
                    var target= $(this).attr('data-toggle');
                    $(target).attr('data-index',1);
                    var index= $(target).attr('data-index');
                    if(index==1){
                        $(".sliding-tabs").slideUp();
                        $(this).addClass('active');
                        $(target).slideToggle();
                    }
                    else{
                        return false;
                    }
                }
            })
            var title = location.pathname.split('/').slice(-1)[0];
            var result= title.split('.php').join('');
            if(result==''){
            }
            else{
                $("#main-navbar li").removeClass("active");
            }
            $("#" + result).addClass("active");
            $('.rn-car-item').click(function(e){
                $(this).children('.radiobtn').find('input[type=radio]').prop('checked', true);
                if ($(this).children('.radiobtn').find('input[type=radio]').is(':checked')==true){
                    $("#searchSecond .rn-car-item").removeClass('selected');
                    $(this).addClass('selected');
                }
            });
        });
    </script>
    <script>
        <?php  if($this->session->userdata('logged_in')) { ?>
        $('#loginpannel, #signIn').addClass('hidden')
        <?php } else { ?>
        $('#loginpannel').removeClass('hidden')
        <?php } ?>


       $(document).ready(function() {
            $('#example').DataTable();
           
            $("#drop-select").on('change',function(){
                if($("#drop-select").is(":checked")==true){
                    $('#drop-location').show();
                }
                else{
                    $('#drop-location').hide();
                }
            });
            
            $('.droplist').click(function(){
               $('.userdroplist').slideToggle(); 
            });
            
            
            
//            $('#pickup-date').on('blur',function(){
//                var pickDateattr= $('#pickup-date').val();
//                if(pickDateattr==''){
//                    $('#drop-date').addClass('click-none');
//                }
//            });


          
       });

  


       


       $(window).scroll(function(){
           var scrollPos= $(window).scrollTop();
           if(scrollPos > 0.1){
               $('header').addClass('fixed');
           }
           else{
               $('header').removeClass('fixed');
           }
       });
       $(window).on('load',function(){
            $('.brand-name').addClass('animate-logo');
       });
    </script>
    <script>
        function previewFile() {
            var preview = document.querySelector('#news-picture,#profile-pic');
            var file = document.querySelector('input[type=file]').files[0];
            var reader = new FileReader();
            reader.onloadend = function () {
                preview.src = reader.result;
            }
            if (file) {
                reader.readAsDataURL(file);
            } else {
                preview.src = "";
            }
                $('#imagepath').val($('#news-picture').attr('src'))
        }
    </script>
    <script>
        $('.blog').slick({
            dots: true,
            infinite: true,
            autoplay: true,
            speed: 300,
            slidesToShow: 2,
            slidesToScroll: 1,
            responsive: [
              {
                breakpoint: 1024,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1,
                  infinite: true,
                  dots: true
                }
              },
              {
                breakpoint: 600,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
          });
          
          
        function bookValidate(){
            if($("#book-guest").is(':checked')==true){
                $("#continue").removeClass('hidden');
                $("#popup").addClass('hidden');
            }
            if($("#book-user").is(':checked')==true){
                $("#continue").addClass('hidden');
                $("#popup").removeClass('hidden');
            }
        }
        
        
    </script>
</body>

</html>