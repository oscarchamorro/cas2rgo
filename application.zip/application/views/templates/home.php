<div class="rn-carousel carousel slide" id="carouselExampleControls" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item beactive">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">#1 Car Rent Service<br> In Your City</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
            <img class="d-block w-100" src="assets/images/slide1.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">Quality Cars with<br> Unlimited Miles</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
            <img class="d-block w-100" src="assets/images/slide2.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">24/7 Customer<br> Support</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
                 <a class="btn btn-main btn-lg rn-fade-bottom rn-caption-item-3" href="#">Book Now</a> 
            </div>-->
            <!-- <div class="rn-slider-overlayer"></div> -->
            <img class="d-block w-100" src="assets/images/slide3.jpg" alt="slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="lnr lnr-chevron-left" aria-hidden="true"></span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="lnr lnr-chevron-right" aria-hidden="true"></span>
    </a>
    <div class="rn-small-search-form">
        <div class="rn-small-search-form-title">
            <h2>Book Now</h2>
        </div>
            <?php echo form_open('carslists','class="padding6Form" autocomplete="off"'); ?>
        <?php if(!$this->session->userdata('logged_in')){ ?>
        <div class="rn-icon-input row">
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                <?php }else{ ?>
            <div class="rn-icon-input row" style="display: none">
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                 <?php } ?>
            <div class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input name="formulario" type="hidden" value="OTA_VehAvailRQCore"/>
                <input type="text" id="rec" name="selectpickup" placeholder="Pickup Location" required="required">
                <?php echo form_error('selectpickup') ?>
                <div id="selectpickupShow"></div>
                <input id="recogida" type="hidden" name="recogida[lugar]" />
                <input id="recogida_vendor" type="hidden" name="recogidavendor" />
            </div>
            <div class="col-md-12 text-white p-0" id="returnInAnother">
                <input type="checkbox" id="drop-select">
                <label for="drop-select" value="1" id="checkreturnLotation">I want to return my car in other location </label>
            </div>
            <div id="drop-location" class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input type="text" name="selectpickupdrop" id="dev" placeholder="Drop Location" required="required">
                <div id="selectDevShow"></div>
                 <input id="devolucion" type="hidden" name="devolucion[lugar]" />
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="recogida[fecha]" placeholder="Pickup Date" readonly id="pickup-date" class="flatpickr-input datepicker pickupdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>
                            <input type="text" name="recogida[hora]" placeholder="Time" id="pickup-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="recogidaHora" name="recogida[hora]" id="pickup-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                         
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="devolucion[fecha]" placeholder="Drop Date" readonly id="drop-date" class="flatpickr-input dropdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>-->
    <!--                        <input type="text" name="devolucion[hora]" placeholder="Time" id="drop-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="devolucionHora" name="devolucion[hora]" id="drop-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="countryrecogida" id="countryrecogida">
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-md-6 p-0">
                        <div class="rn-icon-input">
                            <select class="flatpickr-input bg-white" id="ageSelector" name="ageSelector" required="required">
                                <option value="">Select Age</option>
                                <option value="30-69">30-69</option>
                                <option value="29">29</option>
                                <option value="28">28</option>
                                <option value="27">27</option>
                                <option value="26">26</option>
                                <option value="25">25</option>
                                <option value="24">24</option>
                                <option value="23">23</option>
                                <option value="22">22</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 p-0">
                        <select class="flatpickr-input bg-white" name="preferencias[0][vehiculo][categoria]" class="form-control cursorPointer" id="preferenciasVehicleType" required="required">
                            <option value="">Vehicle Type</option>
                            <option value="">no-preference</option>
                            <option value="1">car-economy</option>
                            <option value="2">car-compact</option>
                            <option value="3">car-intermediate</option>
                            <option value="4">car-standard</option>
                            <option value="5">car-fullsize</option>
                            <option value="6">suv-intermediate</option>
                            <option value="7">van-mini</option>
                            <option value="8">convertible-standard</option>
                            <option value="9">suv-standard</option>
                            <option value="10">van-fullsize</option>
                            <option value="11">car-premium</option>
                            <option value="12">car-luxury</option>
                            <option value="13">suv-fullsize</option>
                        </select>
                    </div>
                </div>
            </div>
            <button id="continue" class="btn btn-main btn-lg btn-shadow btn-block" type="submit">
            <i class="fas fa-search"></i> Check Now</button>
            <button id="popup" type="button" data-toggle="modal" data-target="#login" class="btn btn-main btn-lg btn-shadow btn-block m-0 hidden">
            <i class="fas fa-search"></i> Check Now</button>
        <?php echo form_close(); ?>
    </div> 
</div>
<section class="rn-search-form-big rn-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="rn-section-title rn-title-bg-color-white-10 rn-title-color-white">
                    <h2 class="rn-title">About Us</h2>
                    <p class="text-white">Cars2Go, general sales agent of Hertz International, Dollar and Thrifty, has been operating for more than 10 years with a large structure focused mainly on serving the market of Tourism Agencies, Operators and Consumers. Through this site, you will find a wide variety of cars and rates to facilitate your quotes, reservations and Issue vouchers.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="rn-shape rn-shape-bottom">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path class="rn-shape-fill" d="M500.2,94.7L0,0v100h1000V0L500.2,94.7z" />
        </svg>
    </div>
</section>
<section class="rn-section pb-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-section-title ">
                        <h2 class="rn-title">Why Us?</h2>
                        <span class="rn-title-bg">Why Us</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="col-md-12 p-0 tab-contents">
                        <h2><a data-toggle="#tab1" class="tabLink">Payment <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab1" class="sliding-tabs tab1">
                            <div class="rn-faq-item">
                                <div class="rn-faq-icon">
                                    <i class="fas fa-question"></i>
                                </div>
                                <div class="rn-faq-content">
                                    <ul>
                                        <li>Pay Now. 100% secure payment.</li>
                                        <li>Pay your rental or deposit with Debit Cards</li>
                                        <li>$50 USD Cash deposit for Caribbean Renters (FL. Only)</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab2" class="tabLink">Minimum Cancellation Fees <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab2" class="sliding-tabs">
                            <p>If a reservation is cancelled more than 24 hours before the pickup time, a $50 cancellation fee will be assessed. If the reservation is cancelled within 24 hours before the pickup time, a $100 fee will be assessed.  If the customer does not cancel the reservation prior to the time of pick-up and the rental vehicle is not picked up on the rental date, the entire prepaid amount will be forfeited.</p>
                    
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab3" class="tabLink">Best Quality Cars <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab3" class="sliding-tabs">
                            <p>
                                From sea to shining sea, get there with our best fleet ever. Cars2forentals.com offers a variety of all-American, European, Luxuries and prestige cars so you can choose the one that’s right for you. We’re here to get you there.
                                Enjoy from our exclusive Hertz, Dollar and Thrifty fleet cars at any U.S.destination.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab5" class="tabLink">Our Rates <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab5" class="sliding-tabs">
                            <p>Our rates include unlimited mileage. At Hertz, Dollar and Thrifty  corporate locations, vehicles are available for rental with unlimited mileage and all rate structures are honored, including one-way, inter-city rates.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab6" class="tabLink">Unlimited Miles <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab6" class="sliding-tabs">
                            <p>Our rates include unlimited mileage. At Hertz, Dollar and Thrifty  corporate locations, vehicles are available for rental with unlimited mileage and all rate structures are honored, including one-way, inter-city rates.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab7" class="tabLink">24/7 Customer Support <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab7" class="sliding-tabs">
                            <p>Contact Us at 1-800-654-4173 (Open 6 AM- 7 PM Central Time, Monday-Friday) or email us by clicking <a href="<?= base_url('contacts')?>">here</a>. You can also mail a letter to the address below:</br>
							1425 Pointe Lane, <br>Miami Florida – 33169, USA</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab4" class="tabLink">Terms and Conditions <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab4" class="sliding-tabs">
                        <div class="col-md-12">
                            <h3 class="text-center mb-30">Program Terms and Conditions</h3>
                        </div>
                        <p><strong>Changes/Modifications to "Pay Now" rentals are subject to the terms and conditions below.</strong></p>
                        <ol>
                            <li>Discount will vary depending on location, length and date of rental; discount will not apply in all cases.</li>
                            <li>No refunds or credits for unused rental days.</li>
                            <li>Prepaid rates cannot be combined with any promotional offer, voucher or certificate.</li>
                            <li>Rates exclude vehicle licensing recovery fee, airport facility use fee/customer facility charge, hotel concession fees, other cost recovery fees, governmental surcharges, taxes or other optional items such as child seats, luggage racks, refueling items, insurance, NeverLost® or optional refueling, or one-way charges for which the renter may be responsible. Excluded services cannot be prepaid; if accepted, must be paid locally at time of rental.</li>
                            <li>Changes to a reservation must be done at cars2gorentals.com using the "Modify/Cancel" option. Any changes to the reservation may impact the rental charges. If a prepaid reservation is cancelled more than 24 hours before the pickup time, a $50 cancellation fee will be assessed. If the prepaid reservation is cancelled within 24 hours before the pickup time, a $100 fee will be assessed.  If the customer does not cancel the reservation prior to the time of pick-up and the rental vehicle is not picked up on the rental date, the entire prepaid amount will be forfeited.</li>
                            <li>Approximate rental charges are based on available information at the time of reservation for renters age 25 and older. For minimum age requirements please see "Rental Qualifications and Requirements" link below for details. Please note that for renters under age 25 an additional daily age differential charge may apply. Additional fees or surcharges may be applied at time of rental. </li>
                            <li>The customer will be asked to enter a valid credit card number at the end of a change to a prepaid reservation. This must not be the same credit card that was used for the original reservation. If the customer wishes to change the credit card, then the original reservation must be cancelled (see terms and conditions for Cancellations) and a new reservation made. Debit cards and Hertz Credit Cards are valid forms of payment for prepaid rates.</li>
                            <li>When renting the vehicle at the counter, you must produce the same or different credit card with which you paid online and a valid driver's license. The credit card used must be in your name and presented at the time of rental. </li>
                            <li>Standard rental qualifications and rental period restrictions apply.</li>
                            <li>A valid drivers license and credit card must be presented at the time of rental to cover any reasonably anticipated charges which have not been included in the prepaid voucher.</li>
                            <li>All rentals are subject to Hertz, Dollar and Thrifty  standard terms and conditions of the  Rental Agreement in effect at time and place of rental.</li>
                            <li>Rental days are based on 24 hour periods commencing at time of pickup. Additional days will apply if the rental is kept longer than specified (additional days begin after a 29 minute grace period and will be billed at a higher rate).</li>
                            <li>This program is available at participating cities/locations and blackouts may apply.</li>
                            <li>Voluntary upgrades will be charged at locally applicable rates.</li>
                            <li>Please print your prepay confirmation and present at the counter.</li>
                            <li>Prepaid rates are subject to availability. </li>
                            <li>LIS cannot be provided for rentals in excess of 30 days in certain states, including CA, NY, FL, TX, NC and RI.</li>
                            <li>Please note that due to the nature of the prepaid rates, Hertz, Dollar and Thrifty cannot provide a single receipt for a prepaid rental.  Two receipts will be provided - one receipt for the prepaid amount and one receipt for the remainder of charges payable at the counter.</li>
                            <li>Your cars2gorentals.com  Prepaid Rental will appear on your credit card statement as "Cars2gorentals".</li>
                        </ol>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12">
                    <div class="col-md-12 p-0">
                        <h2><a data-toggle="#tab8" class="tabLink">FAQs <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                        <div id="tab8" class="sliding-tabs">
                            <h4>What kind of Driver's License do I need in order to rent a car in the U.S.?</h4>
                            <p class="pl-4">The only Driver License (driving permit) accepted to rent a car in the U.S. (up to 15 passengers) is your original and official driver's license from your country of residence, along with your passport. The drivers license must be valid for the entire rental period.The International Driving Permit by itself will not be sufficient to rent a car, since the International Driving permit is only considered to be a translation of the original National License, and although it is recommended, it is not required.</p>
                            <h4>Are these rates guaranteed or will I have to pay any additional charges other than the amount on my confirmation voucher?</h4>
                            <p class="pl-4">In order to guarantee the promotional rates listed below, we strongly recommend completing the reservation as soon as possible. These promotional rates are subject to change without previous notice and will only be guaranteed once the reservation is confirmed. There are no mandatory charges in addition to the amount shown on your confirmation voucher, however, upon vehicle pickup, the rental agent may offer additional services and insurance coverages, as well as vehicle category upgrades. Such services are optional and shall be refused by the customer if not interested. The non acceptance of such optional services does not impede the customer from renting the vehicle. Carefully read the rental contract before signing to make sure that only requested services have been included, because once any optional services have been accepted the total rental charges will be altered and no amounts will be refunded.</p>
                            <h4>What are the age requirements for renting a car?</h4>
                            <p class="pl-4">In order to rent a car in the United States and Canada, and qualify for these promotional rates, the renter must be at least 21 years of age, have a valid driver’s license from the country of residence (non-U.S.), and a major credit card in his/her name. The minimum age for renting a car in the United States is 21. However, drivers between the ages of 21 and 24 will be charged an underage fee of U$ 35.00 p/day in addition to the regular rental charges.</p>
                            <h4>What is TollPass?</h4>
                            <p class="pl-4">All Hertz, Thrifty, and Dollar vehicles in the State of Florida are already equipped with the TollPass Service (SunPass / EZ Pass) . This toll service allows drivers to utilize the express lanes without having to stop at the toll booths. The cost of the toll charges and administrative fees associated with this service are not included in the published rates and will be charged to your credit card separately, if the service is utilized. Hertz TollPass Convenience Charge is a $5.95 per day if you use a toll express lane on roadways covered by our TollPass provider, plus the cost of all unpaid tolls. Thrifty & Dollar TollPass Convenience Charge is a $15.00 charge for each time you use a toll express lane on roadways covered by our TollPass provider, up to a maximum of $105.00 per rental, plus the cost of all unpaid tolls.</p>
                            <h4>Where can I view my TollPass charges?</h4>
                            <p class="pl-4">Drivers may keep track of the amount of Toll charges being debited to their credit cards on the following websites: Hertz, Dollar and Thrifty: <a href="www.platepass.com/receipt" target="_blank">www.platepass.com/receipt</a></p>
                            <h4>How can I pay for my rental vehicle?</h4>
                            <p class="pl-4">All car rental reservations confirmed by Cars2Go Rentals are to be paid directly on this site on the payment tab. Payment is accepted via major credit cards (Visa, Master, Amex & Discover) in the renters name.</p>
                            <h4>Can i rent a car without a credit card?</h4>
                            <p class="pl-4">Yes. you may choose to pay by cash at the end of the rental, when the vehicle is returned. Only airport locations accept cash payment at the end of the rental.</p>
                            <h4>Can I rent a car without insurance?</h4>
                            <p class="pl-4">No, all rental plans offered by Cars2Go Rentals are promotional rates which already include the CDW/LDW insurance coverages; therefore, no insurance exclusions are allowed. For additional information regarding insurance coverage please visit our website's Terms & Conditions section.</p>
                            <h4>Where should I pick-up/return my rental car at the Port of Miami, Ft. Lauderdale & Cape Canaveral?</h4>
                            <p class="pl-4">At the Miami, Ft. Lauderdale & Cape Canaveral cruise ports there are no rental car company facilities on the premises. However, the rental car companies provide a Free Shuttle service between the cruise passenger terminal and the car rental locations (to and from). All rental vehicles must be picked up and returned at the car rental facility outside of the port. The free shuttle service runs on a continuous basis; therefore, there is no need to make reservations for this shuttle service.</p>
                            <h4>What kind of vehicle documents will I receive when I collect the vehicle?</h4>
                            <p class="pl-4">In the U.S. the only rental vehicle documents that you will receive at the time the vehicle is picked up will be the rental agreement contract. The rental agreement is the only document you will need, and all necessary information pertaining to the vehicle's registration, which you may need to present to the local authorities if requested, will be included in the rental agreement.</p>
                            <h4>What is an additional driver?</h4>
                            <p class="pl-4">An additional driver is a person authorized to drive the rental vehicle, other than the primary driver (renter). All additional drivers must meet the rental qualifications with respect to age and licensing. Most rental car companies charge an additional driver fee of U$13.00 p/day p/additional driver, however, some rental plans allow one additional driver at no cost. The names of all additional drivers must be added to the contract at the time the vehicle is being picked up (retrieved) or at any time during the rental period at a car rental office. The primary driver and additional driver must both be present.</p>
                            <h4>Can I rent a child seat?</h4>
                            <p class="pl-4">All car rental companies offer child seat rentals as an optional service at an average price of $13.00 p/day up to a maximum of $90.00 p/rental (plus applicable taxes). By law the use of child seats is only mandatory for children 5 years of age or younger. Child seats may be requested at the time the reservation request is being submitted or directly at the counter upon collecting vehicle (vehicle pick-up).</p>
                            <h4>With how much fuel will I receive the vehicle?</h4>
                            <p class="pl-4">Common practice among car rental companies in the U.S. is to deliver the rental vehicle with a full tank of fuel to the renter. At the time of making the reservation the customer will have the option of selecting a rental plan that already includes the first tank of fuel; therefore, the customer will be allowed to return the vehicle with any amount of fuel at no additional cost. Upon delivery of the rental vehicle the client will also have the option to either prepay for the first tank of fuel, and not have to worry about refueling before return, or to refuel at a gas station of choice before returning the vehicle. If none of the three options is selected, the rental car company will charge the renter for the cost of the missing fuel plus a refueling service charge.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<section class="rn-section pt-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="rn-section-title mb-4">
                    <p class="mt-3">Prepaid Terms and conditions are noted on your www.cars2gorentals.com reservation confirmation. Additionally, for the US prepaid program the terms and conditions are noted below - more details can also be found in the Products & Services page for <a href="https://www.hertz.com/rentacar/productservice/index.jsp?targetPage=prepaid.jsp&leftNavUserSelection=globNav_3_5_1&selectedRegion=United%20States" target="_blank">Pay Now and Save!</a></p>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="rn-section-title mb-4">
                    <a href="<?= base_url('termsandconditions') ?>" class="btn btn-main">View Terms and Conditions</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="rn-section rn-section-light-gray">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="rn-section-title  rn-title-bg-color-white ">
                    <h2 class="rn-title">Rate Packages</h2>
                    <span class="rn-title-bg">Rate Packages</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="rn-car-item">
                    <div class="rn-car-item-info">
                        <h3>Basic Protection</h3>
                        <div class="rn-car-list-n-price">
			    <ul>
                                <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                            </ul>
			</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="rn-car-item">
                    <div class="rn-car-item-info">
                        <h3>Inclusive Protection</h3>
                        <div class="rn-car-list-n-price">
			    <ul>
                                <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                                <li><i class="fa fa-user"></i> Additional Driver</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="rn-car-item">
                    <div class="rn-car-item-info">
                        <h3>Full Protection </h3>
                        <div class="rn-car-list-n-price">
			    <ul>
                                <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                                <li><i class="fa fa-user"></i> Additional Driver</li>
                                <li><i class="fa fa-file"></i> Liability Insurance Supplement</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="rn-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <img src="assets/images/clients/strip-lg.jpg" class="img-fluid">
            </div>
        </div>
    </div>
</section>
<section class="rn-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="rn-section-title rn-title-bg-color-white ">
                    <h2 class="rn-title">Top Destinations</h2>
                    <!--<p>Inbecilloque elegans errorem concedo etsi electram.</p>--><span class="rn-title-bg">Most Popular Destinations</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="rn-team-member">
                    <div class="rn-team-member-img">
                        <div class="rn-overlayer"></div>
                        <img class="img-fluid" src="<?= base_url('assets/images/team-member-1.jpg')?>" alt="Team member">
                    </div>
                    <div class="rn-team-member-info">
                        <div class="rn-team-member-name">Atlanta</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="rn-team-member">
                    <div class="rn-team-member-img">
                        <div class="rn-overlayer"></div>
                        <img class="img-fluid" src="<?= base_url('assets/images/team-member-2.jpg')?>" alt="Team member">
                    </div>
                    <div class="rn-team-member-info">
                        <div class="rn-team-member-name">Miami</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="rn-team-member">
                    <div class="rn-team-member-img">
                        <div class="rn-overlayer"></div>
                        <img class="img-fluid" src="<?= base_url('assets/images/team-member-3.jpg')?>" alt="Team member">
                    </div>
                    <div class="rn-team-member-info">
                        <div class="rn-team-member-name">New York</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="rn-team-member">
                    <div class="rn-team-member-img">
                        <div class="rn-overlayer"></div>
                        <img class="img-fluid" src="<?= base_url('assets/images/team-member-4.jpg')?>" alt="Team member">
                    </div>
                    <div class="rn-team-member-info">
                        <div class="rn-team-member-name">Los Angeles</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="rn-team-member">
                    <div class="rn-team-member-img">
                        <div class="rn-overlayer"></div>
                        <img class="img-fluid" src="<?= base_url('assets/images/team-member-5.jpg')?>" alt="Team member">
                    </div>
                    <div class="rn-team-member-info">
                        <div class="rn-team-member-name">Las Vegas</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="rn-team-member">
                    <div class="rn-team-member-img">
                        <div class="rn-overlayer"></div>
                        <img class="img-fluid" src="<?= base_url('assets/images/team-member-6.jpg')?>" alt="Team member">
                    </div>
                    <div class="rn-team-member-info">
                        <div class="rn-team-member-name">San Francisco</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <a href="<?= base_url('locations') ?>" class="btn btn-main btn-lg">View All Locations</a>
            </div>
        </div>
    </div>
</section>
<!--<section class="rn-section rn-section-light-gray">
<div class="container">
    <div class="row">
        <div class="col-lg-12">

            
        <div class="rn-section-title   ">
                <h2 class="rn-title">What Our Client Say</h2>
                <p>Inbecilloque elegans errorem concedo etsi electram.</p>
                <span class="rn-title-bg">Client Review</span>
        </div>

        <div class="rn-testimonials">
                <div class="rn-testimonials-carousel carousel slide" id="rn-testimonials" data-ride="carousel">
                        <div class="carousel-inner">
                                <div class="carousel-item">
                                    <blockquote class="rn-testimonial-item">
                                        <div class="rn-testimonial-author">
                                            <div class="rn-testimonial-author-thumb">
                                                <img src="<?= base_url('assets/images/author-1.jpg')?>" alt="John Doe">
                                            </div>
                                            <div class="rn-testimonial-author-info"><strong>Katherine Powell</strong>
                                                <p>CEO, Example Inc.</p>
                                            </div>
                                        </div>
                                        <p>Curabitur neque turpis, pellentesque vel semper ut, tempor vel arcu. Nulla facilisi. Phasellus feugiat nunc eget eros varius, et mollis magna elementum.</p>
                                    </blockquote>
                                </div>
                                <div class="carousel-item">
                                    <blockquote class="rn-testimonial-item">
                                        <div class="rn-testimonial-author">
                                            <div class="rn-testimonial-author-thumb">
                                                <img src="<?= base_url('assets/images/author-2.jpg')?>" alt="John Doe">
                                            </div>
                                            <div class="rn-testimonial-author-info"><strong>Patrick Cox</strong>
                                                <p>CEO, Example Inc.</p>
                                            </div>
                                        </div>
                                        <p>Curabitur neque turpis, pellentesque vel semper ut, tempor vel arcu. Nulla facilisi. Phasellus feugiat nunc eget eros varius, et mollis magna elementum.</p>
                                    </blockquote>
                                </div>
                                <div class="carousel-item active">
                                    <blockquote class="rn-testimonial-item">
                                        <div class="rn-testimonial-author">
                                            <div class="rn-testimonial-author-thumb">
                                                <img src="<?= base_url('assets/images/author-3.jpg')?>" alt="John Doe">
                                            </div>
                                            <div class="rn-testimonial-author-info"><strong>Lauren Anderson</strong>
                                                <p>CEO, Example Inc.</p>
                                            </div>
                                        </div>
                                        <p>Curabitur neque turpis, pellentesque vel semper ut, tempor vel arcu. Nulla facilisi. Phasellus feugiat nunc eget eros varius, et mollis magna elementum.</p>
                                    </blockquote>
                                </div>
                            </div>
                    <a class="carousel-control-prev" href="#rn-testimonials" role="button" data-slide="prev">
                        <i class="fas fa-angle-left" aria-hidden="true"></i>
                    </a>
                    <a class="carousel-control-next" href="#rn-testimonials" role="button" data-slide="next">
                <i class="fas fa-angle-right" aria-hidden="true"></i>
            </a>
        </div>
    </div>
</div>
</div>
</div>
</section>-->
<div id="login" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="mb-0">Sign In Here!</h2>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div id='err_msg' style='display: none'>  
                <div id='content_result'>  
                <div id='err_show' class="w3-text-red">  
                <div id='msg'> </div></label>  
                </div></div></div>  
                <div class="row">
                    <div class="col-lg-8 position-center">
                        <div class="rn-contact-form">
                                <div class="row mb-30">
                                    <div class="col-12 mb-30">
                                        <div class="rn-icon-input">
                                            <i class="far fa-user"></i>
                                            <input type="text" id="usuario" name="usuario" placeholder="User ID">
                                        </div>
                                    </div>
                                    <div class="col-12 mb-10">
                                        <div class="rn-icon-input">
                                            <i class="far fa-user"></i>
                                            <input type="password" id="pass" name="pass" placeholder="Password">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <p class="m-0">If you don't have any account yet. Click here to <a class="text-warning" href="<?= base_url('user_auth/userregister')?>">create one.</a></p>
                                    </div>
                                </div>
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <div class="col-8 position-center">
                    <input class="btn btn-main btn-lg btn-block btn-shadow" id="submit" type="button" value="Sign In">
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<script type="text/javascript"> 
$(document).ready(function(){  
        $("#login").on('click','#submit',function(){  
        var userid = $('#usuario').val();
        var password = $('#pass').val(); 
        
        // Returns error message when submitted without req fields.  
        if(userid==''||password=='')  
        {  
        jQuery("div#err_msg").show();  
        jQuery("div#msg").html("All fields are required");  
        }  
        else  
        {  
        // AJAX Code To Submit Form.  
        $.ajax({  
        type: "POST",  
        url:  '<?= base_url('user_auth/ajax_login'); ?>',
        data: {email: userid, pass: password},  
        cache: false,  
        success: function(result){  
            if(result!=0){  
                // On success redirect.  
            window.location.replace('<?= base_url() ?>');  
            }  
            else  
                jQuery("div#err_msg").show();  
                jQuery("div#msg").html("Login Failed");  
        }  
        });  
        }  
        return false;  
        });  
        });  
</script>

