<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
        <link rel="shortcut icon" href="<?php echo base_url('assets/favicon.ico'); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
          <?php if(isset($pagetitle)){ ?>
        <title> <?= $pagetitle ?> </title>
        <?php } else { ?>
        <title> Car Rental USA | Minivan Rental USA - Cars2GoRental </title>
         <?php } ?>
         <?php if(isset($discription)){ ?>
        <meta name="description" content="<?= $discription ?>">
        <?php } else { ?>
        <meta name="description" content="Cars2GoRental Offers budget minivan car rental in popular area's in USA like Atlanta ,Austin, Boston, Charlotte, Chicago O’Hare, Cleveland, Dallas/Fort Worth, Denver, Detroit, Fort Lauderdale, Houston Hobby, Houston Intcntl, Kansas City, Las Vegas, Los Angeles, Miami, Minneapolis-St. Paul, Nashville and more.">
        <?php } ?>
	<style>#preloader:after,#preloader:before{content:"";display:block;left:-1px;top:-1px}#preloader-overlayer,#preloader:after,#preloader:before{position:absolute;height:100%;width:100%}#preloader-overlayer{position:fixed;top:0;left:0;background-color:#112E3B;z-index:999}#preloader{height:40px;width:40px;position:fixed;top:50%;left:50%;margin-top:-20px;margin-left:-20px;z-index:9999}#preloader:before{-webkit-animation:rotation 1s linear infinite;animation:rotation 1s linear infinite;border:2px solid #ffb320;border-top:2px solid transparent;border-radius:100%}#preloader:after{border:1px solid rgba(255,255,255,.1);border-radius:100%}@media only screen and (min-width:768px){#preloader{height:60px;width:60px;margin-top:-30px;margin-left:-30px}#preloader:before{left:-2px;top:-2px;border-width:2px}}@media only screen and (min-width:1200px){#preloader{height:80px;width:80px;margin-top:-40px;margin-left:-40px}}@-webkit-keyframes rotation{from{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}@keyframes rotation{from{-webkit-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(359deg);transform:rotate(359deg)}}</style>
	<link rel="stylesheet" href="<?= base_url('assets/libs/bootstrap/css/bootstrap.min.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/libs/fontawesome/css/fontawesome-all.min.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/libs/fontawesome/css/fontawesome.css')?>">
    <link rel="stylesheet" href="<?= base_url('css/font-awesome.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/libs/linearicons/linearicons.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/rentnow-icons.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/magnific-popup.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/dataTables.bootstrap4.min.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/printpage.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/sweetalert.css'); ?>" />
    <script src="<?= base_url('assets/js/sweetalert.min.js'); ?>"></script>
    <link rel="stylesheet" href="<?= base_url('assets/css/slick.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/slick-theme.css')?>">
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <![endif]-->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-159387816-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-159387816-1');
	</script>
	<meta name="google-site-verification" content="uLxDiUUn1oJ_cvc581tyZVdBTL0yqtBGWY5nyZfA_l4" />
</head>

<body class="rn-preloader">
    <div id="preloader"></div>
    <div id="preloader-overlayer"></div>
    <header class="rn-header">
        <div class="rn-topbar">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-12 col-sm-5 col-lg-3">
                        <ul class="rn-social">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-sm-7 col-lg-9">
                        <div class="rn-icon-contents">
                            <div class="rn-phone rn-icon-content">
                                <div class="rn-icon">
                                    <i class="lnr lnr-phone"></i>
                                </div>
                                <div class="rn-info">
                                    <ul>
                                        <li>(954)-944-1250</li>
                                        <li>(954)-944-1251</li>
                                    </ul>
                                </div>
                            </div>
                            <!--<div class="rn-address rn-icon-content">
                                <div class="rn-icon">
                                    <i class="lnr lnr-map-marker"></i>
                                </div>
                                <div class="rn-info">
                                    <ul>
                                        <li>1425 Pointe Lane, Miami</li>
                                        <li>Florida – 33169, USA</li>
                                    </ul>
                                </div>
                            </div>-->
                            <div class="rn-email rn-icon-content">
                                <div class="rn-info">
                                    <ul id="loginpannel">
                                        <li>
                                            <a href="<?= base_url('user_auth/login') ?>" class="btn btn-outline-main text-white btn-round">Sign In</a>
                                            <a href="<?= base_url('user_auth/userregister') ?>" class="btn btn-outline-success text-white btn-round ml-3">Register/Join Now</a>
                                        </li>
                                    </ul>
                                    <?php 
                               
                                 if($this->session->userdata('logged_in')){
                                 if($this->session->userdata('user_data_session')){
                                 $user_detail = $this->session->userdata('user_data_session');
                                 $name = $user_detail['name'];
                                 $lname = $user_detail['lastname'];
                                 $id = $user_detail['user_id'];
                                 //$images = $user_detail['image'];
                                // print_r($images);
                                     }
                                ?>
                                    <ul class="profile-wrapper">
                                         <li>
                                             <div class="profile">
                                                <a href="<?= base_url('bookinglist')?>" class="btn btn-outline-main text-white btn-round">Management</a>
                                                <div class="droplist">
                                                    <a href="#" class="dropdown-toggle btn btn-outline-success text-white btn-round ml-2">
                                                        <i class="fa fa-user"></i> <span class="color000"><?php echo $name ?> <?php echo $lname ?></span>
                                                    </a>
                                                    <div class="userdroplist">
                                                        <ul>
                                                            <li><a href="<?= base_url('bookinglist')?>"><i class="fa fa-list"></i> Booking List</a></li>
                                                            <li><a href="<?= base_url('canceledlist')?>"><i class="fa fa-list"></i> Cancel List</a></li>
                                                            <li><a href="<?= base_url('rejectedlist')?>"><i class="fa fa-list"></i> Modify List</a></li>
                                                            <li><a href="<?= base_url('userprofiledetails')?>"><i class="fa fa-user"></i> User Profile</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <a href="<?= base_url();?>user_auth/logout" class="btn btn-outline-success text-white btn-round ml-2">
                                                    <i class="fas fa-sign-out-alt"></i> Logout
                                                </a>
                                            </div>
                                         </li>
                                    </ul> 
                                <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="rn-menubar">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <a class="brand-name" href="<?= base_url() ?>">
                            <img class="img-fluid" src="<?= base_url('assets/images/logo.png')?>" alt="Logo">
                        </a>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                        <nav class="rn-navbar-container">
                            <button class="rn-navbar-toggler" id="rn-navbar-toggler">
                                <span class="rn-navbar-toggler-bar"></span><span class="rn-navbar-toggler-bar"></span><span class="rn-navbar-toggler-bar"></span>
                            </button>
                            <ul id="main-navbar" class="rn-navbar">
                                <li id="index" class="active"><a href="<?= base_url() ?>">Home</a></li>
                                <li id="locations"><a href="<?= base_url('locations') ?>">Locations</a></li>
                                <li id="about"><a href="<?= base_url('abouts') ?>">About</a></li>
                                <li id="contact"><a href="<?= base_url('contacts') ?>">Contact</a></li>
                                <li id="faq"><a href="<?= base_url('faq') ?>">FAQs</a></li>
                                <li id="terms-and-conditions"><a href="<?= base_url('termsandconditions') ?>">T & C</a></li>
                                <li id="blog"><a href="<?= base_url('blogs') ?>">Blog</a></li>
                                <li id="signIn"><a href="<?= base_url('user_auth/login') ?>">Sign In</a></li>
                                <li id="joinNow"><a href="<?= base_url('user_auth/userregister') ?>">Join Now</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <img class="img-fluid client-responsive" src="<?= base_url('assets/images/clients/strip.jpg')?>" alt="Logo">
                    </div>
                </div>
            </div>
        </div>
    </header>
    