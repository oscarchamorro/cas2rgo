<div class="col-md-12 user-navbar">	
    <div class="row" style="font-size:12px;">
        <ul class="user-menu">
            <li><a href="<?= base_url('') ?>"><label style="white-space: nowrap;"><i class="fa fa-info-circle colorFFF"></i><span class="colorFFF"> Booking List </span></label></a></li>
            <li><a href="<?= base_url('') ?>"><label style="white-space: nowrap;"><i class="fa fa-heart colorFFF"></i><span class="colorFFF"> Canceled List </span></label></a></li>
            <li><a href="<?= base_url('') ?>"><label style="white-space: nowrap;"><i class="fa fa-briefcase colorFFF"></i><span class="colorFFF"> Modify List </span></label></a></li>
            <li><a href="<?= base_url('') ?>"><label style="white-space: nowrap;"><i class="fa fa-home colorFFF"></i><span class="colorFFF"> User Profile </span></label></a></li>
        </ul>
    </div>
</div>
<div class="container-fluid marginbottom4 tab-content" >
    <h2 class="text-center bacgroundFACF00">Reservation history</h2>
        <ul class="nav nav-tabs marginTop1">
            <li><a data-toggle="tab" class="active" href="#home"><label>Approved</label></a></li>
            <li><a data-toggle="tab" href="#menu0"><label>Canceled</label></a></li>
            <li><a data-toggle="tab" href="#menu1"><label>Modify</label></a></li>
            <li><a data-toggle="tab" href="#menu2"><label>Slopes</label></a></li>
        </ul>
        <div class="tab-content">
            <div id="home" class="tab-pane fade in active show">
                <div class="col-md-12 p-0" id="content">
                    <table id="example" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>E-Mail</th>
                                <th>Phone</th>
                                <th>Booking ID</th>
                                <th>Amount</th>
                                <th>Model</th>
                                <th>Image</th>
                                <th>Vendor</th>
                                <th>Booking Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($historyAppdetail as $historyAppdetails): ?>
                                <tr>
                                    <td><?php echo $historyAppdetails['name1'] ?> <?php echo $historyAppdetails['name2'] ?> </td>
                                    <td><?php echo $historyAppdetails['email'] ?></td>
                                    <td><?php echo $historyAppdetails['phone'] ?></td>
                                    <td><?php echo $historyAppdetails['reservID'] ?></td>
                                    <td><?php echo $historyAppdetails['amount'] ?> <?php echo $historyAppdetails['currencycode'] ?></td>
                                    <td><?php echo $historyAppdetails['model'] ?></td>
                                    <td>
                                        <?php //$path = 'http://localhost/cars2gorentals/vehicles/' ?>
                                        <img src="<?= base_url('vehicles/').$historyAppdetails['image']; ?>" alt="" style="width: 80px;" /></td>						</td>
                                    <td><?php echo $historyAppdetails['vendor'] ?></td>						</td>
                                    <td><?php echo $historyAppdetails['date'] ?></td>
                                    <td style="width:40px">
                                        <a href="javascript:void(0);" onclick="getid('<?php echo $historyAppdetails['id'] ?>')" data-toggle="modal" data-target="#myModal"><i class="fa fa-eye mr-10"></i></a>
                                        <a href="#" class="text-danger"><i class="fa fa-times"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <div id="menu0" class="tab-pane fade">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <tr class="bacgroundFACF00">
                        <td>ITINERARY</td>
                        <td>NAME</td>
                        <td>E-MAIL</td>
                        <td>PHONES</td>
                        <td>RESERVATION ID</td>
                        <td>AMOUNT</td>
                        <td>MODEL</td>
                        <td>IMAGE</td>
                        <td>VENDOR</td>
                        <td>RESERVATION DATE</td>
                    </tr>
                        <tr>
                             <td>
                        <label>Pickup Location</label><br />
                        <div style="white-space: nowrap;">MIAMI 3900 NW 25TH STREET SUITE 410 33142</div><div style="white-space: nowrap;">2019-02-16</div><div style="white-space: nowrap;">11:00</div>							<br />
                        <br />
                        <label>Return Location</label><br />
                        <div style="white-space: nowrap;">MIAMI 3900 NW 25TH STREET SUITE 410 33142</div><div style="white-space: nowrap;">2019-02-23</div><div style="white-space: nowrap;">11:00</div>						</td>
                    <td> Hernan <br />Prada </td>
                    <td>hprada@hertzgsacaribbean.com</td>
                    <td></td>
                    <td>Pending payment</td>
                    <td>179.05USD</td>
                    <td>B FORD FOCUS OR SIMILAR</td>
                    <td>
                        <img src="https://images.hertz.com/vehicles/220x128/ZEUSCCAR999.jpg" alt="B FORD FOCUS OR SIMILAR" style="width: 70%;" />						</td>
                    <td>
                        <img src="img/hertzico.png" class="marginTop3" alt="hertz rent a cars" style="width: 50%;" />						</td>
                    <td>2019-02-15 08:02:47</td>
                </tr>
                </table>
            </div>
            <div id="menu1" class="tab-pane fade">
                <table class="table table-striped table-bordered grid-data">
                        <tr class="bacgroundFACF00">
                                <td>ITINERARY</td>
                                <td>NAME</td>
                                <td>E-MAIL</td>
                                <td>PHONES</td>
                                <td>RESERVATION ID</td>
                                <td>AMOUNT</td>
                                <td>MODEL</td>
                                <td>IMAGE</td>
                                <td>VENDOR</td>
                                <td>RESERVATION DATE</td>
                        </tr>
                        <tr>
                         <td>
                            <label>Pickup Location</label><br />
                            <div style="white-space: nowrap;">MIAMI 3900 NW 25TH STREET SUITE 410 33142</div><div style="white-space: nowrap;">2019-02-16</div><div style="white-space: nowrap;">11:00</div>							<br />
                            <br />
                            <label>Return Location</label><br />
                            <div style="white-space: nowrap;">MIAMI 3900 NW 25TH STREET SUITE 410 33142</div><div style="white-space: nowrap;">2019-02-23</div><div style="white-space: nowrap;">11:00</div>						</td>
                        <td> Hernan <br />Prada </td>
                        <td>hprada@hertzgsacaribbean.com</td>
                        <td></td>
                        <td>Pending payment</td>
                        <td>179.05USD</td>
                        <td>B FORD FOCUS OR SIMILAR</td>
                        <td>
                            <img src="https://images.hertz.com/vehicles/220x128/ZEUSCCAR999.jpg1" alt="B FORD FOCUS OR SIMILAR" style="width: 70%;" />						</td>
                        <td>
                            <img src="img/hertzico.png" class="marginTop3" alt="hertz rent a cars" style="width: 50%;" /></td>
                        <td>2019-02-15 08:02:47</td>
                    </tr>
                    </table>
                </div>
            <div id="menu2" class="tab-pane fade">
        <table class="table table-striped table-bordered grid-data">
                <tr class="bacgroundFACF00">
                        <td>ITINERARY</td>
                        <td>NAME</td>
                        <td>E-MAIL</td>
                        <td>PHONES</td>
                        <td>RESERVATION ID</td>
                        <td>AMOUNT</td>
                        <td>MODEL</td>
                        <td>IMAGE</td>
                        <td>VENDOR</td>
                        <td>RESERVATION DATE</td>
                </tr>
                <tr>
                    <td>
                        <label>Pickup Location</label><br />
                            <label>Return Location</label><br />
                    </td>
                        <td>ewewqerwq
                        </td>
                        <td>eqweqw</td>
                        <td>sadaf</td>
                        <td>Pending payment</td>
                        <td>
                               ewqqrqrqerwrw
                        </td>
                                <td>awerqwreqw</td>
                                <td>dwqerqrqwerq
                                </td>
                                <td>
                                        wqeqqrqr
                                </td>
                                <td>ewrwqerwqer
                                </td>
                        </tr>
                </table>
            </div>
                </div>
    <div class="clearfix"> </div>
</div>
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">ITINERARY DETAILS</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="printElement">
                    <div class="col-md-12 p-0">
                        <div class="col-4 pull-left">
                            <strong>Pickup Location</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <p id="locationname"></p>
                            <span><input type="text" name="txtEmployeeName" readonly="read"></span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-4 pull-left">
                            <strong>Pickup Date/Time</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <span>2019-02-16 / <span>11:00</span></span>
                        </div>
                        <div class="clearfix mb-4"></div>
                        <div class="col-4 pull-left">
                            <strong>Drop Location</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <span>Miami 3900 NW 25th Street Suite 410 33142</span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-4 pull-left">
                            <strong>Pickup Date/Time</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <span>2019-02-16 / <span>11:00</span></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="printButton" class="btn btn-success" data-dismiss="modal">Print</button>
                <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
    function getid(ids){
         $.ajax({
                type: 'ajax',
                method: 'get',
                url: '<?php echo base_url() ?>history/viewdetails',
                data: {id: ids},
                async: false,
                dataType: 'json',
                success: function(data){
                    $('input[name=txtEmployeeName]').val(data.nombre);
                       
                    },
                error: function(){
                        alert('Could not availabe Data');
                }
        });
    }
</script>
