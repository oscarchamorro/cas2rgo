<section class="rn-section">
        <div class="container">
            <?php if( $this->session->flashdata('user_registered')){ ?>
        <script>
            Swal.fire('<?php echo  $this->session->flashdata('user_registered'); ?>')
        </script>
        <?php  } ?>
            <?php echo form_open('user_auth/userregister','id="registration"');?>
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="mb-30">Create Account Here!</h2>
                        <div class="rn-contact-form">
                            <div class="row mb-30">
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-user"></i>
                                        <input type="text" id="names1" name="names1" placeholder="First Name">
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-user"></i>
                                        <input type="text" name="lastname1" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-envelope"></i>
                                        <input type="text" name="email" placeholder="Email">
                                        <p class='text-danger'><?php echo form_error('email'); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-mobile"></i>
                                        <input type="text" name="phone" placeholder="Phone No.">
                                        <?php //echo form_error('phone'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-globe"></i>
                                        <input type="text" name="country" placeholder="Country">
                                        <?php //echo form_error('country'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-map-marker"></i>
                                        <input type="text" name="city" placeholder="City">
                                        <?php echo form_error('city'); ?>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-home"></i>
                                        <input type="text" name="address" placeholder="Address">
                                        <?php echo form_error('address'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-map"></i>
                                        <input type="text" name="postalcode" placeholder="Zip Code">
                                        <?php echo form_error('postalcode'); ?>
                                    </div>
                                </div>
                                <div class="col-md-12 mb-10 mt-4">
                                    <div class="rn-icon-input">
                                        <input type="checkbox" name="termns" value="1" checked id="tc" />
                                        <label for="tc">I agree to accept <a href="#">terms and conditions</a></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <h4 class="mb-30">If you are a representative of a travel agency or a commercial ally, fill in the following form</h4>
                        <div class="rn-contact-form">
                            <div class="row mb-30">
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-user"></i>
                                        <input type="text" name="company" placeholder="Company's Name">
                                    </div>
                                </div>
                                <div class="col-md-4 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="fa fa-user"></i>
                                        <input type="text" name="ssn_tin" placeholder="SSN/TIN">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <p><i>* The activation of the user is subject to the approval of the administrator. Once this request is approved, we will send an email with the access data to the platform.</i></p>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <input class="btn btn-main btn-lg btn-shadow" type="submit" value="Create Account">
                        </div>
                    </div>
                </div>
           <?php echo form_close(); ?>
        </div>
    </section>