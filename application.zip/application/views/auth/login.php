<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>Login</h1>
                        <!--<p>Cras eros lorem, rhoncus ac risus sit amet, fringilla ultrices purus.</p>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2 class="mb-30">Sign In Here!</h2>
                    <div class="rn-contact-form">
                       <p><?php echo $this->session->flashdata('login_failed'); ?></p> 
                       <?php echo form_open('user_auth/login'); ?>
                            <div class="row mb-30">
                                <div class="col-12 mb-30">
                                    <div class="rn-icon-input">
                                        <i class="far fa-user"></i>
                                        <input type="text" name="usuario" placeholder="User ID">
                                        <?php echo form_error('usuario'); ?>
                                    </div>
                                </div>
                                <div class="col-12 mb-10">
                                    <div class="rn-icon-input">
                                        <i class="far fa-user"></i>
                                        <input type="password" name="pass" placeholder="Password">
                                        <?php echo form_error('pass'); ?>
                                    </div>
                                    <a href="#" data-toggle="modal" class="mt-20 fa-pull-left" data-target="#recover-password">Forgot Password?</a>
                                </div>
                                <div class="col-12">
                                    <p class="m-0">If you don't have any account yet. Click here to <a class="text-warning" href="<?= base_url('user_auth/userregister')?>">create one.</a></p>
                                </div>
                            </div>
                            <div class="text-right">
                                <input class="btn btn-main btn-lg btn-block btn-shadow" type="submit" value="Sign In">
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="<?= base_url('assets/images/login.png')?>" class="img-fluid slide-it" />
                </div>
            </div>
        </div>
    </section>
  </div>
<div class="modal fade" id="recover-password" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog cascading-modal modal-avatar modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <img src="<?= base_url('assets/images/pass.jpg')?>" class="rounded-circle img-responsive" alt="Avatar photo">
            </div>
            <div class="modal-body text-center mb-1">
                <p class="mt-1 mb-2">We will send the data to re-establish your password to the email address you entered at the time of registration.</p>
                <div class="md-form ml-0 mr-0">
<!--                    <div class="alert alert-success fade in alert-dismissible show" style="margin-top:18px;">-->
						<div class="text-center">
							<img id="request-ldr" src='<?= base_url("assets/images/loader.gif")?>' class="hidden" width="25"/>
						</div>
                        <div id="message"></div>
<!--                    </div>-->
                    <div id="err_msg"></div>
                    <input type="text" type="text" id="mailid" class="form-control ml-0 email-text" placeholder="Enter Email" required>
                </div>
                <div class="text-center mt-4">
                    <button class="btn btn-main text-white" id="submit" data-toggle="modal" data-target="#sent">Send Request</button>
                </div>
            </div>
        </div>
    </div>
</div>
  <script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
  <script type="text/javascript">  
$(document).ready(function(){ 
        $("#recover-password").on('click','#submit',function(){
        var mail = $('#mailid').val(); 
        // Returns error message when submitted without req fields.  
        if(mail=='')  
        {  
			jQuery("div#err_msg").show();  
			jQuery("div#msg").html("All fields are required");  
        }  
        else  
        {  
			$('#request-ldr').show();
        // AJAX Code To Submit Form.  
    $.ajax({  
        type: "POST",  
        url:  '<?= base_url('forgetpassword'); ?>',
        data: {email: mail},  
        cache: false,  
        success: function(result){  
            if(result){
				$('#request-ldr').hide();
                $('#message').html('<div class="alert alert-success fade in alert-dismissible show" style="margin-top:18px;"><strong>Success!</strong> Your request has been sent successfully.</div>');
				setTimeout(function() {$('#recover-password').modal('hide');}, 2000);
				window.location.reload();
            }  
            else  
                jQuery("div#err_msg").show();  
                jQuery("div#msg").html("Login Failed");  
        }  
        });  
        }  
        return false;  
        });  
        }); 
  </script>