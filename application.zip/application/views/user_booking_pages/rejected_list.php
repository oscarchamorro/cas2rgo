<div class="col-md-12 user-navbar">	
    <div class="row" style="font-size:12px;">
        <ul class="user-menu">
            <li><a href="<?= base_url('bookinglist') ?>"><label style="white-space: nowrap;"><i class="fa fa-info-circle colorFFF"></i><span class="colorFFF"> Booking List </span></label></a></li>
            <li><a href="<?= base_url('canceledlist') ?>"><label style="white-space: nowrap;"><i class="fa fa-heart colorFFF"></i><span class="colorFFF"> Canceled List </span></label></a></li>
            <li><a href="<?= base_url('rejectedlist') ?>"><label style="white-space: nowrap;"><i class="fa fa-briefcase colorFFF"></i><span class="colorFFF"> Modify List </span></label></a></li>
            <li><a href="<?= base_url('userprofiledetails') ?>"><label style="white-space: nowrap;"><i class="fa fa-home colorFFF"></i><span class="colorFFF"> User Profile </span></label></a></li>
        </ul>
    </div>
</div>
<div class="container-fluid marginbottom4 tab-content" >
    <h2 class="text-center bacgroundFACF00">Rejected List</h2>
    <table id="example" class="table table-striped table-bordered grid-data">
        <thead>
            <tr class="bacgroundFACF00">
                <th>Pickup Location</th>
                <th>Drop Location</th>
                <th>Booking ID</th>
                <th>Booking Date</th>
                <th>Payment Status</th>
                <th>Image</th>
                <th>Vendor</th>
            </tr>
         </thead>
         <tbody>
             <?php foreach ($rejectedlist as $rejectedlists): ?>
            <tr>
                <td><div style="white-space: nowrap;"><?php echo $rejectedlists['pick_city'] ?> <?php echo $rejectedlists['pick_state'] ?> <?php echo $rejectedlists['pick_zipcode'] ?></div><div style="white-space: nowrap;">2019-02-16</div><div style="white-space: nowrap;">11:00</div></td>
                <td><div style="white-space: nowrap;"><?php echo $rejectedlists['drop_city'] ?> <?php echo $rejectedlists['drop_state'] ?> <?php echo $rejectedlists['drop_zipcode'] ?></div><div style="white-space: nowrap;">2019-02-23</div><div style="white-space: nowrap;">11:00</div></td>
                <td><?php echo $rejectedlists['bookid'] ?></td>
                <td><?php echo $rejectedlists['date'] ?></td>
                <td><?php echo $rejectedlists['amount'] ?> <?php echo $rejectedlists['currencycode'] ?> (Pending)</td>
                <td>
                   <img src="<?= base_url('/vehicles/').$rejectedlists['image'] ?>" alt="" style="width: 70px;" /><br>
                    <span><?php echo $rejectedlists['modelNo'] ?></span>
                </td>
                <td>
               <?php if($rejectedlists['vendor']=='ZR'){ ?>
                        <img src="img/dollarico.png" class="marginTop3 img-fluid" alt="" />
                        <?php if($rejectedlists['vendor']=='ZT'){ ?>
                        <img src="img/thriftyicono.png" class="marginTop3 img-fluid" alt="" />
                    <?php } } else{ ?>
                        <img src="img/hertzico.png" class="marginTop3 img-fluid" alt="" /></td>
                    <?php } ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="clearfix"> </div>
</div>
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">ITINERARY DETAILS</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div id="printElement">
                    <div class="col-md-12 p-0">
                        <div class="col-4 pull-left">
                            <strong>Pickup Location</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <p id="locationname"></p>
                            <span><input type="text" name="txtEmployeeName" readonly="read"></span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-4 pull-left">
                            <strong>Pickup Date/Time</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <span>2019-02-16 / <span>11:00</span></span>
                        </div>
                        <div class="clearfix mb-4"></div>
                        <div class="col-4 pull-left">
                            <strong>Drop Location</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <span>Miami 3900 NW 25th Street Suite 410 33142</span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-4 pull-left">
                            <strong>Pickup Date/Time</strong><span class="pull-right">:</span>
                        </div>
                        <div class="col-8 pull-left">
                            <span>2019-02-16 / <span>11:00</span></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
