<div class="col-md-12 user-navbar">	
    <div class="row" style="font-size:12px;">
        <ul class="user-menu">
            <li><a href="<?= base_url('bookinglist') ?>"><label style="white-space: nowrap;"><i class="fa fa-info-circle colorFFF"></i><span class="colorFFF"> Booking List </span></label></a></li>
            <li><a href="<?= base_url('canceledlist') ?>"><label style="white-space: nowrap;"><i class="fa fa-heart colorFFF"></i><span class="colorFFF"> Canceled List </span></label></a></li>
            <li><a href="<?= base_url('rejectedlist') ?>"><label style="white-space: nowrap;"><i class="fa fa-briefcase colorFFF"></i><span class="colorFFF"> Modify List </span></label></a></li>
            <li><a href="<?= base_url('userprofiledetails') ?>"><label style="white-space: nowrap;"><i class="fa fa-home colorFFF"></i><span class="colorFFF"> User Profile </span></label></a></li>
        </ul>
    </div>
</div>
<div class="container-fluid marginbottom4 tab-content" >
    <h2 class="text-center bacgroundFACF00">Reservation List</h2>
    <table id="example" class="table table-striped table-bordered grid-data">
        <thead>
            <tr class="bacgroundFACF00">
                <th>Pickup Location</th>
                <th>Drop Location</th>
                <th>Booking ID</th>
                <th>Booking Date</th>
                <th>Payment Status</th>
                <th>Image</th>
                <th>Vendor</th>
                <th>Action</th>
            </tr>
         </thead>
         <tbody>
             <?php foreach ($bookinglist as $bookinglists): ?>
            <tr>
                <td><div style="white-space: nowrap;"><?php echo $bookinglists['pick_city'] ?> <?php echo $bookinglists['pick_state'] ?> <?php echo $bookinglists['pick_zipcode'] ?></div><div style="white-space: nowrap;"><?php echo $bookinglists['date']  ?></div><div style="white-space: nowrap;"><?php echo $bookinglists['time']  ?></div></td>
                <td><div style="white-space: nowrap;"><?php echo $bookinglists['drop_city'] ?> <?php echo $bookinglists['drop_state'] ?> <?php echo $bookinglists['drop_zipcode'] ?></div><div style="white-space: nowrap;"><?php echo $bookinglists['dropdate']  ?></div><div style="white-space: nowrap;"><?php echo $bookinglists['droptime']  ?></div></td>
                <td><?php echo $bookinglists['bookid'] ?></td>
                <td><?php echo $bookinglists['date'] ?></td>
                <?php if($bookinglists['bookid']!=='WAIT'){ ?>
                 <td><?php echo $bookinglists['amount'] ?> <?php echo $bookinglists['currencycode'] ?></td>
                <?php }elseif($bookinglists['bookid']=='WAIT'){ ?>
                 <td><?php echo $bookinglists['amount'] ?> <?php echo $bookinglists['currencycode'] ?> (Pending)</td>
                <?php } ?>
                <td>
                    <img src="<?= base_url('/vehicles/').$bookinglists['image'] ?>" alt="" style="width: 70px;" /><br>
                    <span><?php echo $bookinglists['modelNo'] ?></span>
                </td>
                <td>
                    <?php if($bookinglists['vendor']=='ZR'){ ?>
                        <img src="img/dollarico.png" class="marginTop3 img-fluid" alt="hertz rent a cars" />
                        <?php if($bookinglists['vendor']=='ZT'){ ?>
                        <img src="img/thriftyicono.png" class="marginTop3 img-fluid" alt="hertz rent a cars" />
                    <?php } } else{ ?>
                        <img src="img/hertzico1.png" class="marginTop3 img-fluid" alt="hertz rent a cars" /></td>
                    <?php } ?>
                <?php 
                date_default_timezone_set('Asia/Kolkata'); 
                $times = date("Y-m-d,H:i"); 
                ?>
                <?php if(strtotime($bookinglists['timedate']) > strtotime($times)){ ?>
                <td style="width:40px">
                   <a onclick="cancel_car(<?php echo $bookinglists['id'] ?>);"><i class="fa fa-times text-danger ml-2 mr-2"></i></a>
                </td>
               <?php }elseif(strtotime($bookinglists['timedate']) <= strtotime($times)){?>
                <td style="width:40px">
                   <a onclick="donotcancel();"><i class="fa fa-times text-warning ml-2 mr-2"></i></a>
                </td>
                <?php } ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="clearfix"> </div>
</div>

<div id="cancelModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm Cancel</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
    <form id="reservar" name="reservar">
            <input name="formulario" type="hidden" value="OTA_VehCancelRQCore"/>
            <input type="hidden" id="apellido" name="apellido">
            <input type="hidden" id="nombres" name="nombres">
            <input type="hidden" id="numeroreserva" name="numeroreserva">
            <input type="hidden" id="compania" name="compania">
     </form>
        	Do you want to Cancel this Car?
      </div>
      <div class="modal-footer">
        <button type="button" id="close_popup" class="btn btn-default" data-dismiss="modal">Close</button>
        <a id="btncancelcar" class="btn btn-danger carcancel text-white">Cancel</a>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<script type="text/javascript">
    function donotcancel(){
       Swal.fire('Cancel Only within 24 hours, I think you have crosed the time!');
    }
function cancel_car(id){
        var note=   '<h4 class="text-left">Keep In Mind</h4>'
            note+=  '<ul class="mb-4 text-left" style="font-size:13px;">'
            note+=  '   <li>Any changes to the reservation may impact the rental charges.</li>'
            note+=  '   <li>If a prepaid reservation is cancelled more than 24 hours before the pickup time, a $50 ($ 50 CAD) cancellation fee will be assessed.</li>'
            note+=  '   <li>If the prepaid reservation is cancelled within 24 hours before the pickup time, a $100 ($100 CAD) fee will be assessed.</li>'
            note+=  '   <li>If the customer does not cancel the reservation prior to the time of pick-up and the rental vehicle is not picked up on the rental date, the entire prepaid amount will be forfeited.</li>'
            note+=  '</ul>'
        $('.swal2-popup').addClass('swal2-large');
        $('.swal2-large').append(note);
    $.ajax({
        type: 'ajax',
        method: 'post',
        async: false,
        url: 'cancelcarrequest',
        data:{id:id},
        dataType: 'json',
        success: function(data){
            // console.log(data[0].referencia);
            $('input[name=numeroreserva]').val(data[0].reservaid);
            $('input[name=apellido]').val(data[0].apellido);
            var firstName=data[0].nombre;
            var lastName=data[0].apellido;
            var fullname = firstName+' '+lastName;
            $('input[name=nombres]').val(fullname);
            if(data[0].vendor=='ZR' || data[0].vendor=='ZT' || data[0].vendor=='ZE' ){
                $('input[name=compania]').val(data[0].vendor);
            }
        },
         error: function(){
                alert('Could not Data');
        }
    });
    const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success',
          cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false,
    });

    swalWithBootstrapButtons.fire({
        html:note,
        title: 'Are you sure?',
        text: "You want to cancel this reservation!",
        icon: 'warning',
        showCancelButton: true,
        customClass: "swal2-large",
        confirmButtonText: 'Yes, cancel it!',
        cancelButtonText: 'No, cancel!',
        reverseButtons: true
    }).then((result) => {
        if (result.value) {
            var dataform = $('#reservar').serializeArray();
            $.ajax({
                data: dataform,
                dataType:'json',
                type:'post',
                url:'cancelcarrequest/getcancel',
                error:function(){
                    console.log(arguments);
                },
                success:function(response){
                    if (response.datos.Errors){
                        if (response.datos.Errors.Error['@attributes'].ShortText){
                            Swal.fire(response.datos.Errors.Error['@attributes'].ShortText);
                        }
                    }
                    if(response.datos.VehCancelRSCore){
                        if(response.datos.VehCancelRSCore['@attributes'].CancelStatus == 'Cancelled'){
                            var cancelid = response.datos.VehCancelRSCore.UniqueID['@attributes'].ID;
                            updatedata(cancelid);
                            swalWithBootstrapButtons.fire(
                                'Cancelled!',
                                'Your reservation has been cancelled.',
                                'success'
                            )
                        }
                    }
                }
            });
        } else if (
          result.dismiss === Swal.DismissReason.cancel
        ) {
            swalWithBootstrapButtons.fire(
              'Cancellation Stopped',
              'Your reservation is safe!',
              'error'
            )
        }
    })
}

    //$('#cancelModal').modal('show');
    
</script>
<script>
$(document).ready(function(){
    $('#btncancelcar').click(function(){
        
     });
});

function updatedata(cancelid) { 
    $.ajax({
        type:'post',
        url:'cancelcarrequest/updatecancelreservation',
        data: {cid:cancelid },
        success:function(response){
            Swal.fire('Your reservation has been successfully Cancel!');
            $('#close_popup').click();
            delay(3000);
            window.location.reload(1);
        }
    });
 }

</script>