<div class="col-md-12 user-navbar">	
    <div class="row" style="font-size:12px;">
        <ul class="user-menu">
            <li><a href="<?= base_url('bookinglist') ?>"><label style="white-space: nowrap;"><i class="fa fa-info-circle colorFFF"></i><span class="colorFFF"> Booking List </span></label></a></li>
            <li><a href="<?= base_url('canceledlist') ?>"><label style="white-space: nowrap;"><i class="fa fa-heart colorFFF"></i><span class="colorFFF"> Canceled List </span></label></a></li>
            <li><a href="<?= base_url('rejectedlist') ?>"><label style="white-space: nowrap;"><i class="fa fa-briefcase colorFFF"></i><span class="colorFFF"> Modify List </span></label></a></li>
            <li><a href="<?= base_url('userprofiledetails') ?>"><label style="white-space: nowrap;"><i class="fa fa-home colorFFF"></i><span class="colorFFF"> User Profile </span></label></a></li>
        </ul>
    </div>
</div>
<div class="container-fluid marginbottom4 tab-content" >
    <h2 class="text-center bacgroundFACF00">User Profile</h2>
</div>

<?php echo form_open_multipart(); ?>
<?php foreach ($user_list as $user_lists): ?>
<div class="container marginbottom4 tab-content">
    <?php if($this->session->flashdata('updateprofile')){ ?>
    <div class="alert alert-success"><?php echo $this->session->flashdata('updateprofile'); ?></div>
    <?php } ?>
    <div class="row">
        <div class="col-md-3">
            <?php if($user_lists['image']){ ?>
            <img src="<?php echo base_url('assets/user_image/').$user_lists['image']; ?>" id="profile-pic" class="user-profile-pic" />
            <input type="hidden" name="old_image" value="<?= $user_lists['image']; ?>">
            <?php } else { ?>
            <img src="<?= base_url('assets/images/pass.jpg');?>" id="profile-pic" class="user-profile-pic">
            <?php } ?>
        </div>
        <div class="col-md-9 row">
            <div class="col-md-6">
                <div class="form-group d-flex">
                    <label class="col-md-5">First Name <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="text" name="fname" value="<?php echo $user_lists['fname']  ?>" class="form-control">
                    <?php echo form_error('fname'); ?>
                    </div>
                </div>
                <div class="form-group d-flex">
                    <label class="col-md-5">Last Name <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="text" name="lname" value="<?php echo $user_lists['lname']  ?>" class="form-control">
                    <?php echo form_error('lname'); ?>
                    </div>
                </div>
                <div class="form-group d-flex">
                    <label class="col-md-5">Email <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input readonly type="text" value="<?php echo $user_lists['email']  ?>" class="form-control cursor-ban"></div>
                </div>
                <div class="form-group d-flex">
                    <label class="col-md-5">Phone <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="text" name="phone" value="<?php echo $user_lists['phone']  ?>" class="form-control">
                    <?php echo form_error('phone'); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group d-flex">
                    <label class="col-md-5">City <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="text" name="city" value="<?php echo $user_lists['city']  ?>" class="form-control">
                    <?php echo form_error('city'); ?>
                    </div>
                </div>
                <div class="form-group d-flex">
                    <label class="col-md-5">Country <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="text" name="country" value="<?php echo $user_lists['country']  ?>" class="form-control">
                    <?php echo form_error('country'); ?>
                    </div>
                </div>
                <div class="form-group d-flex">
                    <label class="col-md-5">Address <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="text" name="address" value="<?php echo $user_lists['address']  ?>" class="form-control">
                    <?php echo form_error('address'); ?>
                    </div>
                </div>
                <div class="form-group d-flex">
                    <label class="col-md-5">Select Photo <span class="pull-right">:</span></label>
                    <div class="col-md-8"><input type="file" name="userimage" value="" id="profilePic" onchange="previewFile();" class="form-control"></div>
                </div>
            </div>
            <div class="col-md-12 text-center mt-4">
                <button type="submit" class="btn btn-primary">Update Profile</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
<?php echo form_close(); ?>
