<div class="rn-page-title">
    <div class="rn-pt-overlayer"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="rn-page-title-inner">
                    <h1>Choose Your Ride</h1>
                </div>
            </div>
        </div>
    </div>
</div>

<?php //echo "<pre>"; print_r($formvalue); echo "</pre>"; ?>
    <?php if(!empty($formvalue)){ 
        ?>
    <input type="hidden" id="ageSelector" value="<?php echo $formvalue['ageSelector'] ?>">
    <input type="hidden" id="countryrecogida" value="<?php echo $formvalue['countryrecogida'] ?>">
    <input type="hidden" id="recogidaFechaChange" name="recogidaFechaChange" value="<?php echo date('m-d-Y',strtotime($formvalue['recogida']['fecha'])) ?>">
    <input type="hidden" id="recogidaFecha" name="recogida[fecha]" value="<?php echo $formvalue['recogida']['fecha'] ?>">
     <input type="hidden" id="devolucionFechaChange" value="<?php echo date('m-d-Y',strtotime($formvalue['devolucion']['fecha'])) ?>">
    <input type="hidden" id="devolucionFecha" value="<?php echo $formvalue['devolucion']['fecha'] ?>">
    <input id="recogida" type="hidden" value="<?php echo $formvalue['recogida']['lugar'] ?>" />
    <input id="devolucion" type="hidden" value="<?php echo $formvalue['devolucion']['lugar'] ?>" />
    <input id="recogidaHora" type="hidden" value="<?php echo $formvalue['recogida']['hora'] ?>" />
    <input id="devolucionHora" type="hidden" value="<?php echo $formvalue['devolucion']['hora'] ?>" />
    <input id="rec" type="hidden" value="<?php echo $formvalue['selectpickup'] ?>" />
    <input id="dev" type="hidden" value="<?php echo $formvalue['selectpickupdrop'] ?>" />
    
    <?php }else{ ?>
    <script>window.location="<?= base_url('home')?>"</script>
    <?php }  ?>
<?php  if($this->session->userdata('logged_in')){
            if($this->session->userdata('user_data_session')){
                $user_detail = $this->session->userdata('user_data_session');
                $email = $user_detail['email'];
            }
        } ?>
    <?php if(!empty($email)){ ?>
    <input type="hidden" id="operatorid" name="" value="<?php echo $email ?>">
    <?php } ?>
<section class="rn-section rn-car-list">
    <div class="container">
        <div class="row" id="searchSecond">
            <div class="col-md-12 text-right">
                <h4>Need Help ?  <a href="#" data-toggle="modal" data-target="#instructions" class="btn btn-round btn-success">Click Here</a></h4>
            </div>
        </div>
        <div class="row" id="searchSecond">
            <h2 class="text-center col-md-12 mb-4">Select Your Package Rate</h2>
            <div class="col-lg-4 col-md-6">
                <div class="rn-car-item home-details selected">
                    <div class="rn-car-item-info">
                    	<h3>Basic Protection</h3>
                        <div class="rn-car-list-n-price">
                            <ul>
                                <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                            </ul>
                        </div>
			<a onclick="showDetails(this)" class="btn-know-more">Details</a>
                    </div>
                    <div class="radiobtn">
                        <input type="radio" id="radiost2" name="servicetour" value="2" checked/>
                        <label for="radiost2">Select This rate</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="rn-car-item home-details">
                    <div class="rn-car-item-info">
                    	<h3>Inclusive Protection</h3>
                        <div class="rn-car-list-n-price">
                            <ul>
                                <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                                <li><i class="fa fa-user"></i> (AAO) Additional Driver</li>
                            </ul>
                        </div>
			<a onclick="showDetails(this)" class="btn-know-more">Details</a>
                    </div>
                    <div class="radiobtn">
                        <input type="radio" id="radiost4" name="servicetour" value="4" />
                        <label for="radiost4">Select This rate</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="rn-car-item home-details">
                    <div class="rn-car-item-info">
                    	<h3>Full Protection</h3>
                        <div class="rn-car-list-n-price">
                            <ul>
                                <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                                <li><i class="fa fa-user"></i> Additional Driver</li>
                                <li><i class="fa fa-file"></i> Liability Insurance Supplement</li>
                            </ul>
                        </div>
			<a onclick="showDetails(this)" class="btn-know-more">Details</a>
                    </div>
                    <div class="radiobtn">
                        <input type="radio" id="radiost5" name="servicetour" value="5" />
                        <label for="radiost5">Select This rate</label>
                    </div>
                </div>
            </div>
            <!--            <div class="col-lg-3 col-md-6">
                            <div class="rn-car-item">
                                <div class="rn-car-item-info">
                                    <div class="rn-car-list-n-price">
                                        <ul>
                                            <li><i class="fa fa-road"></i> ML/KM Mileage</li>
                                            <li><i class="fa fa-warning"></i> LDW (Loss Damage Waiver)</li>
                                            <li><i class="fa fa-dollar"></i> Taxes and Fees</li>
                                            <li><i class="fa fa-user"></i> Additional Driver</li>
                                            <li><i class="fa fa-file"></i> Liability Insurance Supplement</li>
                                            <li><i class="fa fa-shopping-cart"></i> Fuel Purchase Option</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="radiobtn">
                                    <input type="radio" id="radiost6" name="servicetour" value="6" />
                                    <label for="radiost6">Select This rate</label>
                                </div>
                            </div>
                        </div>-->
        </div>
    </div>
    <div class="container-fluid">
        <div class="col-md-12 text-center padding1 marginTop3">
            <button id="continue" type="button" class="btn btn-main btn-round btn-lg btn-continue text-white pl-4 pr-4">Search Your Ride</button>
        </div>
        <div id="carList" class="row container-fluid oculto">
            <div id="steps" class="col-md-4">
                <div id="sidePanel">
                    <div class="row m-0">
                        <div class="col-md-12 col-sm-12 col-xs-12 p-0 pull-left">
                            <a id="replan" href="<?= base_url('home') ?>" class="btn text-white"><label>Modify<br>Search</label></a>
                            <button id="itinerary" type="button" class="btn text-white"><label>Change Your<br>Package</label></button>
                            <button id="choosecar" type="button" class="btn text-white"><label>Choose Your<br>Ride</label></button>
                        </div>
                    </div>
                    <div class="row m-0">
                        <div class="col-md-12 marginTop1 mb-5 border">
                            <ul class="p-0 m-0">
                                <li class="row p-4">
                                    <div class="col-md-12 p-0">
                                        <h4>Pickup Location</h4>
                                        <p id="recogidaSelected" class="text-mutedr mb-3"></p>
                                        <p id="recogidaFechaHoraSelected" class="text-muted"></p>
                                    </div>
                                    <div class="col-md-12 p-0 mt-4">
                                        <h4 class="my-0">Return Location</h4>
                                        <p id="devolucionSelected" class="text-muted mb-3"></p>
                                        <smapll id="devolucionFechaHoraSelected" class="text-muted"></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 p-0">
            	<div class="col-md-12">
            	    <h2 class="text-center mb-4"><em><b>PICK YOUR BEST BUDGET RIDE</b></em></h2>
            	</div>
                <div class="col-md-12 col-sm-12 col-xs-12 p-0"> 
                    <div id="list" class="col-md-6 pull-left"></div>
                    <div id="list2" class="col-md-6 pull-left"></div>
                    <!-- //////////////////////////////////////////////////////-->
                    <div id="adds" class="oculto row">
                            <div class="col-md-12 col-sm-12 col-xs-12"> 
                                    <section id="extrass" class="col-md-12"></section>
                            </div>
                            <div class="col-md-12 text-center padding1">
                                    <button id="next" type="button" class="btn bacgroundFACF00"><b>Continue</b></button>
                            </div>
                    </div>
                    <!-- //////////////////////////////////////////////////////-->
                    <div id="book">
                        <?php echo form_open('payment'); ?>
                            <div class="row m-0">
                                <div class="col-md-12 p-3 booking-details">
                                    <div class="row bordes1pxDiv bacgroundFFD100degradao">
                                        <div class="col-md-12">
                                            <h4 class="bacgroundFFD100degradao">Driver information</h4>
                                            <input name="formulario" type="hidden" value="OTA_VehResRQCore"/>
                                            <input id="recSelected" type="hidden" name="recogida[lugar]" />
                                            <input id="recFechaSelected" type="hidden" name="recogida[fecha]"/>
                                            <input id="recHoraSelected" type="hidden" name="recogida[hora]" />
                                            <input id="devSelected" type="hidden" name="devolucion[lugar]" />
                                            <input id="devFechaSelected" type="hidden" name="devolucion[fecha]" />
                                            <input id="devHoraSelected" type="hidden" name="devolucion[hora]" />
                                            <input id="compania" type="hidden" name="compania" />
                                            <input id="reference" type="hidden" name="referencia" />
                                            <input id="amount" type="hidden" name="amount" />
                                            <input id="currencycode" type="hidden" name="currencycode" />
                                            <input id="carSelected1" type="hidden" name="model" />
                                            <input id="vehicle" type="hidden" name="vehicle" />
                                            <input id="numerotour1" type="hidden" name="numerotour" />
                                            <input id="ageselector" type="hidden" name="ageselector" />
                                            <input id="preferenciasvehicletype" type="hidden" name="preferenciasvehicletype" />
                                            <input id="voucher" type="hidden" name="voucher" value="casr2go2001" />
                                            <?php 
                                                if($this->session->userdata('logged_in')){
                                                if($this->session->userdata('user_data_session')){
                                                $user_detail = $this->session->userdata('user_data_session');
                                                $name = $user_detail['name'];
                                                $lname = $user_detail['lastname'];
                                                $email = $user_detail['email'];
                                               }
                                            ?>
                                            <div class="row fontsize12 form-group marginTop2">
                                                <div class="col-md-6 mb-3">
                                                    <input type="text" class="form-control bg-white" id="firstName" name="nombre" value="<?php echo $name ?>" placeholder="Your first name" required />
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <input type="text" class="form-control bg-white" id="lastName" name="apellido" value="<?php echo $lname ?>" placeholder="Your last name" required />
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <input type="email" class="form-control bg-white" id="emaila" name="correo" value="<?php echo $email ?>" placeholder="Your E-mail" required />
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <input type="email" class="form-control bg-white" id="verifyemail" value="<?php echo $email ?>" placeholder="Verify your E-mail" required />
                                                </div>
                                            </div>
                                            <?php } else {?>
                                            <div class="row fontsize12 form-group marginTop2">
                                                <div class="col-md-6 mb-3">
                                                    <input type="text" class="form-control bg-white" id="firstName" name="nombre" placeholder="Your first name" value="" required />
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <input type="text" class="form-control bg-white" id="lastName" name="apellido" placeholder="Your last name" value="" required />
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <input type="email" class="form-control bg-white" id="emaila" name="correo" placeholder="Your E-mail"  value="" required />
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <input type="email" class="form-control bg-white" id="verifyemail" placeholder="Verify your E-mail" value="" required />
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <div class="col-md-4">
                                            <img src="#" id="imagenSelected" class="img-fluid darken-blend"/>
                                        </div>
                                        <div class="col-md-6 mb-4">
                                            <h5>YOUR BOOKING INCLUDE</h5>
                                            <div class="col-md-12 p-0">
                                                    <span id="typeSelected"></span>
                                                    <span id="carSelected"></span>
                                                    <p class="mb-1">Driver Age <span id="ageselector"></span></p>
                                                    <span class="toBePaid rate" ></span>
                                            </div>
                                        </div>
                                        <div class="col-md-12 p-2 text-center bg-primary text-white mb-5">
                                                <label class="m-0" id="itincludes"></label>
                                        </div>
                                        <!--<div class="col-md-12 text-center mb-3">
                                                <label><i class="fas fa-exclamation-circle text-danger"></i> <i class="fontsize12">By pressing the payment button we will redirect you to our payment gateway https://www.myvirtualmerchant.com. <br />You will leave our site https://www.cars2gorentals.com/ temporarily.</i></label>
                                        </div>-->
                                        <div class="col-md-12 text-center marginbottom2">
                                                <input type="hidden" name="contador" id="contador" value="0">
                                                <input type="submit" class="btn btn-main btn-lg btn-shadow" value="Pay Now" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                    </div>
                            <!-- //////////////////////////////////////////////////////-->
                    </div>
            </div>
        </div>
    </div>
</section>
<div id="instructions" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Instructions</h4>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <div class="item-page">
                        <h4 class="text-center"> Additional Driver (AAO) </h4>
                        <p><br>Individuals not automatically covered in the rental agreement as the authorized operators noted above can be signed as an "Additional Authorized Driver" (AAO). AAO must be present and the rental agreement can be signed at the time of rental or during rental at any US location. corporate.</p>
                        <p>Lead and AAO driver must both be present to sign the rental agreement, presenting an acceptable credit card or debit card (if the rental city accepts debit cards) in their own name, or cash deposit. valid driver's license, and must be a minimum of 21 years of age. For people from 21 to 24 different from the age location surcharges will apply.</p> 
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="item-page">
                        <h4 class="text-center"> Liability Insurance Supplement - LIS </h4>
                        <p><br>Liability Insurance Supplement (LIS) provides you with up to $1 million of increased protection should bodily injury and property damage claims be made against you by people injured in an accident. LIS safeguards your insurance policy and/or your personal assets for the first $1 million should such claims be made against you. In most states, uninsured/underinsured coverage up to $1,000,000 per occurrence for combined bodily injury and/or property damage claims is available for an additional charge . This is only if you purchase LIS. In CO and NY, LIS includes uninsured/underinsured motorist coverage up to $1,000,000 per occurrence for combined bodily injury and /or property damage claims.</p>
                        <p>At many Hertz locations, you receive secondary liability protection. In a few locations, no liability protection under the terms of the Rental Agreement from claims of injury by others against you resulting from an accident with your rental car. Some locations provide primary protection under the Rental Agreement. However in those situations where protection is provided by Hertz, such protection is generally no more than the minimum limits required by the individual state law. (See chart for these Financial Responsibility Limits). For these reasons, some people feel more comfortable traveling with additional liability protection. That is why Hertz makes the Liability Insurance Supplement (LIS) option available to you.</p>
                        <p><strong>Here are some facts you should know:</strong></p>
                        <ul style="list-style-type: square;">
                            <li>LIS provides coverage for you and other authorized operators of your rental vehicle for third party liability claims.</li>
                            <li>LIS is primary protection to your personal policy and provides for the first $1,000,000** of coverage for combined bodily injury and/or property damage claims per occurrence</li>
                            <li>In most states, Uninsured Motorist Protection (UMP) with coverage up to $1,000,000** per occurrence for combined bodily injury and/or property damage claims is available for an additional charge, but only if LIS is purchased. Uninsured Motorist Protection (UMP) is additional protection available to customers who have purchased LIS</li>
                            <li>In the states of CO and NY, LIS includes Uninsured/Underinsured coverage up to $1,000,000** per occurrence for combined bodily injury/property damage claims.</li>
                        </ul>
                        <p>Detailed information can be found in the Terms and Conditions.</p>
                        <p><strong>PLEASE NOTE:</strong> LIS is included in the Hertz Business + and Hertz Business Lite rate.</p>
                        <div id="faqsection">FAQ</div><table id="article_faq" class="table table-striped"><tbody><tr><td class="faqtitle">Where can you find detailed information regarding insurances?<div class="faqanswer"><p><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;">In the terms & conditions on the Hertz website.</span></span></span></span></span></span></span></span></p>
                        <p><a target="_blank" href="https://www.hertz.de/rentacar/location?processName=rentalQualifications/">https://www.hertz.de/rentacar/location?processName=rentalQualifications/</a> </p>
                        <p><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"></span></span></span></span></span></span></span></span></p></div></td></tr><tr><td class="faqtitle">Can everybody accept the LIS insurance?<div class="faqanswer"><p><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;">Yes, LIS is available for all customers in the US</span></p></div></td></tr><tr><td class="faqtitle">Can LIS be booked upfront? <div class="faqanswer"><p><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;">Yes, LIS can be booked upfront.</span></p></div></td></tr></tbody></table><p></p> 
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="item-page">
                        <h4 class="bacgroundFFD100degradao text-center">
                        Returning the car with an empty fuel tank (FPO)
                        </h4>
                        <p><br><strong>What if I return the car with an empty tank of fuel?</strong></p>
                        <p><br>Hertz rates do not include fuel. All Hertz vehicles are rented with a full tank and must be returned with a full tank, or a local refuelling charge will apply.<br>Fuel Purchase Option (FPO)</p>
                        <p><br>For convenience, you may purchase a tank of fuel from Hertz at the time of rental at a price that is competitive with local fuel stations. This method eliminates the need for you to refill the tank before returning. Please be aware that we are unable to give a refund for unused fuel. Please check the availability of FPO at time of rental.</p>
                        <div id="faqsection">FAQ</div><table id="article_faq" class="table table-striped"><tbody><tr><td class="faqtitle">How will the fuel option be charged?<div class="faqanswer"><p><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;">The fuel fees will be charged, according to the ammouts stated in the renatl contract.</span></span></p></div></td></tr><tr><td class="faqtitle">Why do your customers have to return the car with a full fuel tank?<div class="faqanswer"><p><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;"><span style="font-size: 11pt; line-height: 115%; font-family: Calibri, sans-serif;">The Hertz rates don’t iclude fuel. The cars are provided with a full tank and therefore be returned with a full tank.</span></span></span></span></p></div></td></tr></tbody></table><p></p> 
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<script src="<?= base_url('assets/js/Concurrent.Thread.js'); ?>"></script>
<script>
	var count=1;
	function showDetails(e){
		var div= $(e).parent().find('.rn-car-list-n-price').slideToggle();
		var height = $(e).parent().find('.rn-car-list-n-price').height();
		if(height < 1){
			$(e).parent().find('a').html('Know Less');
		}
		else{
			$(e).parent().find('a').html('Know More');
		}
	}
   
var $Document = $(document);
var $DocumentBody = $(document.body);
var $Window = $(window);
var porcentajehertz = null;
$.ajax({
	data:{
		hertz : 'hertz'
	},
	type:'POST',
	url:'/tarifas_setup.php',
	success:function(data){
		porcentajehertz = data;
	}
});

var porcentajedollar = null;
$.ajax({
	data:{
		dollar : 'dollar'
	},
	type:'POST',
	url:'/tarifas_setup.php',
	success:function(data){
		porcentajedollar = data;
	}
});
var porcentajethrifty = null;
$.ajax({
	data:{
		thrifty : 'thrifty'
	},
	type:'POST',
	url:'/tarifas_setup.php',
	success:function(data){
		porcentajethrifty = data;
	}
});

$(document).ready(function(){
		$('.rn-car-list-n-price').hide();
	$(document).scrollTop(200);
    $('#book').hide();
    $('#carList').hide();
});
var operator='';
var porcentagentoperatorvalue = 1;
var comissionagentoperator = 1;
if(operator == null){
	$.ajax({
		data:{
			operator : operator
		},
		type:'POST',
		url:'<?= base_url('getextras/tarifas_agentopeator') ?>',
		success:function(data){
			porcentagentoperatorvalue = data;
		}
	});
	$.ajax({
		data:{
			operator : operator
		},
		type:'POST',
		url:'<?= base_url('getextras/tarifas_agentopeatorcomission') ?>',
		success:function(data){
			comissionagentoperator = data;
		}
	});
}


var Message = {
	$Message:null,
	$MessageBackground:null,
	$MessageForeground:null,
	$MessageContenido:null,
	$MessageButton1:null,
	$MessageButton2:null,
	$MessageButton3:null,
	canHide:true,
	types:{
            error:{
                css:{
                    backgroundColor:'#ffbaba',
                    color:'#d8000c'
                },
                imageId:'imgError'
            },
            normal:{
                css:{
                    backgroundColor:'#f6f6f6',
                    color:'#333333'
                }
            },
            success:{
                css:{
                    backgroundColor:'#dff2bf',
                    color:'#4f8a10'
                },
                imageId:'imgExito'
            }
	},
center:function(){
    this.init();
    this.$MessageForeground.css({
        left:'',
        top:''
    });
    var top = window.innerHeight/2-this.$MessageForeground.innerHeight()/2;
    var left = window.innerWidth/2-this.$MessageForeground.innerWidth()/2;
    this.$MessageForeground.css({'top':top,'left':left});
},
hide:function(){
    this.init();
    this.$MessageBackground.fadeOut();
    this.$MessageForeground.fadeOut();
},
init:function(){
    if(this.$MessageContenido){
        return;
}
        this.$MessageBackground = $('<div>').addClass('oculto');
        this.$Message = $('<div>');
        this.$MessageForeground = $('<div>').addClass('oculto cerrar');
        this.$MessageContenido = $('<div>').addClass('contenidoMensaje');
        this.$MessageButton1 = $('<button>').addClass('button1 bacgroundFACF00').attr('type','button');
        this.$MessageButton2 = $('<button>').addClass('button2 bacgroundFACF00').attr('type','button');
        this.$MessageButton3 = $('<button>').addClass('button3 bacgroundFACF00').attr('type','button');
        var $Div = $('<div style="position: absolute; z-index: 17; top: -90px; margin-left:-100px;">');
        $Div.append(this.$MessageButton1);
        $Div.append(this.$MessageButton2);
        $Div.append(this.$MessageButton3);
        this.$MessageContenido.append(this.$Message);
        this.$MessageContenido.append($Div);
        this.$MessageForeground.append(this.$MessageContenido);
        this.$MessageForeground.append('<div style="position: absolute; z-index: 17; top: -90px; margin-left:-100px;">'+
        '<!--Click en el fondo para cerrar Mensaje.--></div>');
        $DocumentBody.append(this.$MessageBackground);
        $DocumentBody.append(this.$MessageForeground);
        $Window.resize(function(){
                Message.center();
                setTimeout(function(){Message.center();},1000);
        });
        // this.$MessageBackground.click(function(){
                // if(this.canHide){
                        // Message.hide();	
                // }			
        // });
    },
show:function(message,callback,messageType,button1Callback,button2Callback, button3Callback){
    this.init();
    var type = (messageType?messageType:Message.types.normal);
    this.$MessageContenido.css(type.css);
    this.$MessageBackground.fadeIn();
    this.$MessageForeground.fadeIn();
    this.$Message.html('');
    this.$Message.append((type.imageId?' ':'')+message);
    $('.cerrar').on('click','#imgCerrar',function(){
            $(this).parents().find('.background').click();
    });
    this.$MessageBackground.unbind('click');
    this.$MessageBackground.click(function(){
        Message.hide();
        if(callback){
                callback();
        }
        if(button3Callback){
                button3Callback();
        }else if(button2Callback){
                button2Callback();
        }
    });
    if(button1Callback||button2Callback||button3Callback){
        this.$MessageButton1.show().unbind().click(function(){
            Message.hide();
            if(button1Callback){
                button1Callback();
            }
        });
        if(button2Callback){
            this.$MessageButton2.show().unbind().click(function(){
                Message.hide();
                if(button2Callback){
                        button2Callback();
                }
            });	
        }else{
                this.$MessageButton2.hide();
        }
        if(button3Callback){
            this.$MessageButton1.html('Yes');
            this.$MessageButton2.html('No');
            this.$MessageButton3.html('Cancel').show().unbind().click(function(){
                Message.hide();
                if(button3Callback){
                        button3Callback();
                }
            });
        }else{
                this.$MessageButton1.html('OK');
                this.$MessageButton2.html('Cancel');
                this.$MessageButton3.hide();
        }
    }else{
            this.$MessageButton1.hide();
            this.$MessageButton2.hide();
            this.$MessageButton3.hide();
    }
    this.center();
},
	showConfirmDialog:function(message,button1Callback,button2Callback){
		this.show(message,null,false,button1Callback,button2Callback);
	},
	showError:function(message,callback){
		this.show(message,callback,Message.types.error);
	},
	showSuccess:function(message,callback){
		this.show(message,callback,Message.types.success);
	},
	showYesNoCancel:function(message,button1Callback,button2Callback,button3Callback){
		this.show(message,null,false,button1Callback,button2Callback, button3Callback);
	}
};

function getVehicleType(type){
	var vehType = {1:'car',2:'van',3:'suv',4:'convertible',7:'limousine',8:'station wagon',9:'pickup',10:'motorhome',11:'all-terrain',12:'recreational',13:'sport',14:'special',15:'pickup extended cab',16:'regular cab pickup',17:'special offer',18:'coupe',19:'monospace',20:'2 wheel vehicle',21:'roadster',22:'crossover',23:'commercial van/truck'};
	return vehType[type];
}
function getVehicleClass(vClass){
   
	var vehClass = {1:'mini',2:'subcompact',3:'economy',4:'compact',5:'midsize',6:'intermediate',7:'standard',8:'fullsize',9:'luxury',10:'premium',23:'special',32:'special',33:'minielite',34:'economy elite',35:'compact elite',36:'intermediate elite',37:'standard elite',38:'fullsize elite',39:'premium elite',40:'luxury elite',41:'oversize'};
	return vehClass[vClass];
}
function getExtra(extra) {vehiculo
	var extras = {'CSI':['Infant Child Seat','img/InfantChildSeat.png',true, 7],'CST':['Child Toddler Seat','img/jcm-carrot-car-seat.png',true,8],'BST':['Booster Seat','img/BoosterSeat.png',true,9],'NEV':['NeverLost <br /> Portable GPS','img/hertz_never_lost.png',false,13],'SKV':['Ski-erized','img/logomodalmix.png',false,0],'SNO':[ 'Snow Tyre','img/SnowTyre.png',false,14],'SBR':['Snow Board Rack','img/SnowBoardRack.png',false,4],'SRC':['SRC','img/src.png',false,0],'HMM':['HMM','img/logomodalmix.png',false,0],'LDW':['Loss Damage <br />Waiver','img/LossDamageWaiver.png',false,0],'SDW':['Super collision damage waiver','img/Supercollisiondamagewaiver.png',false,0],'LIS':['Liability insurance supplement','img/Liabilityinsurancesupplement.png',false,0],'PPI':['Personal property insurance','img/Personalpropertyinsurance.png',false,0],'TP':['Theft protection','img/Theftprotection.png',false,0],'PKG':['Renter Protection Package','img/RenterProtectionPackage.png',false,0]};
	return extras[extra];
}
function getLogo(vehicleKey){
	vehicleKey = vehicleKey + '';
	if(vehicleKey.indexOf('ZR') == 0){
		return 'dollarico';
	}else if(vehicleKey.indexOf('ZT') == 0){
		return 'thriftyicono';
	}
	return 'hertzico';
}
function getCompany(vehicleKey){
	vehicleKey = vehicleKey + '';
	if(vehicleKey.indexOf('ZR') == 0){
		return 'ZR';
	}else if(vehicleKey.indexOf('ZT') == 0){
		return 'ZT';
	}
	return '';
}
jQuery(document).ready(function($){
	//if you change this breakpoint in the style.css file (or _layout.scss if you use SASS), don't forget to update this value as well
	var MqL = 1170;
	//move nav element position according to window width
	moveNavigation();
	$(window).on('resize', function(){
		(!window.requestAnimationFrame) ? setTimeout(moveNavigation, 300) : window.requestAnimationFrame(moveNavigation);
	});

	//mobile - open lateral menu clicking on the menu icon
	$('.cd-nav-trigger').on('click', function(event){
		event.preventDefault();
		if( $('.cd-main-content').hasClass('nav-is-visible') ) {
			closeNav();
			$('.cd-overlay').removeClass('is-visible');
		} else {
			$(this).addClass('nav-is-visible');
			$('.cd-main-header').addClass('nav-is-visible');
			$('.cd-main-content').addClass('nav-is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
				$('body').addClass('overflow-hidden');
			});
			toggleSearch('close');
			$('.cd-overlay').addClass('is-visible');
		}
	});

	//open search form
	$('.cd-search-trigger').on('click', function(event){
            event.preventDefault();
            toggleSearch();
            closeNav();
	});
	$('#ageSelector').change(function(){
            
            if($('#ageSelector').children('option').filter(':selected').text().indexOf('*') > 0){
                    $('#continue').hide();
                    return;
            }
            $('#continue').show();
	});
	$('#continue').click(function(){
			$(document).scrollTop(200);
          $("#searchSecond,#continue").hide();
          var age = $('#ageSelector').val();
          document.getElementById('ageselector').value=age; 
        
			if(!$('#ageSelector').val() || !$('#rec').val() || !$('#dev').val()){
                return;
			}
			$('#reserve').hide();
			$('#choosecar').addClass('bacgroundFACF00').removeClass('btn-default');
			$('#extras').removeClass('bacgroundFACF00').addClass('btn-default').attr('disabled');
			$('#finish').removeClass('bacgroundFACF00').addClass('btn-default').attr('disabled');
			$('#itinerary').show();
			fillDefaultVehicles();
			$('#carList').show();
			$('#list').fadeIn();
			$('#list2').fadeIn();
			$('#adds').hide();
			$('#book').hide();
			$('#recogidaSelected').html(document.getElementById('rec').value);
			$('#devolucionSelected').html(document.getElementById('dev').value);

			var options = {weekday:'short', day: '2-digit', month: 'short', year: 'numeric', hour: 'numeric' , minute: 'numeric'};

			var partesFecha =  $('#recogidaFecha').val().split('-');
			var ano = partesFecha.shift();
			partesFecha.push(ano);
			var fecha = new Date(partesFecha.join('/')+' '+$('#recogidaHora').val());
			$('#recogidaFechaHoraSelected').html(fecha.toLocaleDateString('en-US', options));

			var partesFecha =  $('#devolucionFecha').val().split('-');
			var ano = partesFecha.shift();
			partesFecha.push(ano);
			var fecha = new Date(partesFecha.join('/')+' '+$('#devolucionHora').val());
			$('#devolucionFechaHoraSelected').html(fecha.toLocaleDateString('en-US', options));

			$('#ageSelected').html($('#ageselector').children('option').filter(':selected').text().trim());
			$('#recSelected').val($('#recogida').val());
			$('#recFechaSelected').val($('#recogidaFecha').val());
			$('#recHoraSelected').val($('#recogidaHora').val());
			$('#devSelected').val($('#devolucion').val());
			$('#devFechaSelected').val($('#devolucionFecha').val());
			$('#devHoraSelected').val($('#devolucionHora').val());
            });
                $('#itinerary').click(function(){
                    $('#carList').fadeOut();
                    $('#list').html('');
                    $('#list2').html('');
                    $('#searchSecond,#continue').show();
                    $('#reserve').fadeIn();
            });
                    $('#list,#list2').on('click', '.grupo-passo2-lista', function(){
					$(document).scrollTop(200);
                    $('#list').fadeOut();
                    $('#list2').fadeOut();
                    // $('#adds').fadeIn();
                    $('#book').fadeIn();
                    $('#choosecar').removeClass('btn bacgroundFACF00').addClass('btn btn-default');
                    // $('#extras').removeAttr('disabled').removeClass('btn btn-default').addClass('btn bacgroundFACF00');
                    $('#finish').removeAttr('disabled').removeClass('btn btn-default').addClass('btn bacgroundFACF00');
                    var veh = window.vehicles[$(this).data('veh')];
                    var logo = getLogo($(this).data('veh'));
                    var compania = getCompany($(this).data('veh'));
                    $('#compania').val(compania);
                    $('#reference').val(veh.VehAvailCore.Reference['@attributes'].ID);
                    if (compania == 'ZR'){
                        toBePaid = (parseInt(veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount) + parseInt((veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount * porcentajedollar) / 100)) * 1.05;
                                if (porcentagentoperatorvalue > 0){
                        toBePaid = (parseFloat(toBePaid) - parseFloat(toBePaid) / 100 * porcentagentoperatorvalue).toFixed(2);
                        }
                        $('.toBePaid').html('$' + toBePaid + ' <small>' + veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode +'</small>').attr('data-valor', veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount);
                                $('#amount').val(toBePaid);
                                if (comissionagentoperator != 1){
                        $('#amount').val(toBePaid - ((toBePaid / 100) * comissionagentoperator).toFixed(2));
                        }

                    }
                    else if (compania == 'ZT'){
                        toBePaid = (parseInt(veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount) + parseInt((veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount * porcentajethrifty) / 100)) * 1.05;
                                if (porcentagentoperatorvalue > 0){
                        toBePaid = (parseFloat(toBePaid) - parseFloat(toBePaid) / 100 * porcentagentoperatorvalue).toFixed(2);
                        }
                        $('.toBePaid').html('$' + toBePaid + ' ' + veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode).attr('data-valor', veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount);
                                $('#amount').val(toBePaid);
                                if (comissionagentoperator != 1){
                        $('#amount').val(toBePaid - ((toBePaid / 100) * comissionagentoperator).toFixed(2));
                        }
                    }
                    else{
                        toBePaid = (parseInt(veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount) + parseInt((veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount * porcentajehertz) / 100)) * 1.05;
                                if (porcentagentoperatorvalue > 0){
                        toBePaid = (parseFloat(toBePaid) - parseFloat(toBePaid) / 100 * porcentagentoperatorvalue).toFixed(2);
                        }
                        $('.toBePaid').html('$' + toBePaid + ' ' + veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode).attr('data-valor', veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount);
                                $('#amount').val(toBePaid);
                                
                                if (comissionagentoperator != 1){
                        $('#amount').val(toBePaid - ((toBePaid / 100) * comissionagentoperator).toFixed(2));
                        }
                    }

            $('.toBePaidCurrency').html(veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode);
                    $('#currencycode').val(veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode);
                    $('#carSelected1').val(veh.VehAvailCore.Vehicle.VehMakeModel["@attributes"].Name);
                    $('#vehicle').val(veh.VehAvailCore['Vehicle'].PictureURL);
                    $('#typeSelected').html(getVehicleType(veh.VehAvailCore.Vehicle.VehType['@attributes'].VehicleCategory).toUpperCase() + ' - ' + getVehicleClass(veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size).toUpperCase());
                    $('#carSelected').html(veh.VehAvailCore.Vehicle.VehMakeModel["@attributes"].Name);
                    $('#imagenSelected').attr('src','https://images.hertz.com/vehicles/220x128/' + veh.VehAvailCore['Vehicle'].PictureURL);
                    //$('#imagenSelected').html('<img style="text-align:center; width:100%" src=" + '" alt="' + veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name + '">');
                    $('.mb-1 #ageselector').text($('#ageSelector').val());                
                    $.ajax({
                    data:{location:$('#recogida').val(), vendor:!compania?'ZE':compania},
                            dataType:'json',
                            type:'post',
                            url:'<?= base_url('getextras')?>',
                            error:function(arguments){
                            console.log(arguments);
                            },
                            success:function(response){
                            var datos = response.datos['0'];
                                    if (datos){
                            var html = '';
                                    var keys = Object.keys(datos);
                                    for (var i = 0; i <= keys.length; i++){
                            if (datos[keys[i]]){
                            var val = datos[keys[i]];
                                    var extra = getExtra(keys[i].split('DailyRate')[0]);
                                    html += '<div class="grupo-passo2-lista extraextra bacgroundFFF" data-extra="' + extra[0] + '" data-extracode="' + extra[3] + '"><div class="row grupo-automoveis form-group padding2 bordesDivBottom"><div class="col-md-5 text-center"><div id="imagem-carro" class="col-md-12"><img src="' + extra[1] + '" style="width:23% !important"></div></div><div class="col-md-3"><div class="row"><div class="col-md-12 text-center row-grupo-carrossel"><input class="extraSelected" type="checkbox" /></div><div class="col-md-12 row-grupo-carrossel text-center"><label class="grupo-veiculo-janela-detalhes-label">' + extra[0] + '</label>' + (extra[2]?'</div><div class="col-md-6 col-md-offset-3 text-center"><select class="quantity form-control"><option></option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select>':'') + '</div></div></div><div class="col-md-4 ofertas"><div class="row" style="margin-top:1%; background-color:#FACF00 !important;color:#000; padding:1%;"><div class="col-md-12 text-center bacgroundFFF"><i class="glyphicon glyphicon-star bacgroundFACF00 fontsize16 padding2"></i><label class="valor" data-valor="' + val.substr(0, val.length - 2) + '.' + val.substr( - 2) + '">' + val.substr(0, val.length - 2) + '.' + val.substr( - 2) + ' ' + veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode + '</label></div><div class="col-md-12 text-center bacgroundFFF"><label><i>Per Day</i></label></div>/div></div></div>';
                                        }
                                        }
                                        $('#extrass').html(html);
                                        }
                                        }
                                });
                                return false;
                        });
                            $('#extrass').on('change', '.quantity', function(){
                    var $This = $(this);
                            $This.parents('.grupo-automoveis').find('.extraSelected').prop('checked', $(this).val());
                    });
                            $('#extrass').on('change', '.extraSelected', function(){
                    var $This = $(this);
                            $This.parents('.grupo-automoveis').find('.quantity').val(1);
                    });
                            $('#next').click(function(){
                    $('#theextras').hide();
                            $('#extras').removeClass('btn bacgroundFACF00').addClass('btn btn-default');
                            $('#finish').removeAttr('disabled').removeClass('btn btn-default').addClass('btn bacgroundFACF00');
                            $('#adds').fadeOut();
                            $('.masExtras').remove();
                            var total = 0;
                            var count = 0;
                            $('#extrass').find('.extraextra').each(function(){
                    var $This = $(this);
                            if ($This.find('.extraSelected').is(':checked')){
                    $('#theextras').show();
                            var $Ploncito = $('#clonextra').clone(true);
                            $Ploncito.addClass('masExtras');
                            $Ploncito.find('.my-0').html($This.data('extra'));
                            var $Select = $This.find('.quantity');
                            if ($Select.length && $Select.val()){
                    total += parseFloat(parseFloat($This.find('.valor').data('valor')) * $Select.val());
                            $Ploncito.find('.text-muted').html(parseFloat($This.find('.valor').data('valor')) * $Select.val());
                    } else{
                    total += parseFloat($This.find('.valor').data('valor'));
                            $Ploncito.find('.text-muted').html($This.find('.valor').data('valor'));
                    }
                    var extraCode = $This.data('extracode');
                            if (extraCode){
                    var $Campirri = $('<input type="hidden" class="masExtras" name="equipamientoespecial[' + count + '][tipo]" value="' + extraCode + '" />');
                    var $Reference = $('#reference');
                        $Reference.after($Campirri);
                        $Campirri = $('<input type="hidden" class="masExtras" name="equipamientoespecial[' + (count++) + '][cantidad]" value="' + ($Select.val()?$Select.val():1) + '" />');
                        $Reference.after($Campirri);
                            }
                        $('#theextras').after($Ploncito);
                            }
                        });
                                if (total){
                        // total +=parseFloat($('.toBePaid').toFixed(2));
                        $('.toBePaid').each(function(){
                        $(this).html('total<br /> ' + parseFloat(total).toFixed(2) + veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode);
                        });
                        }
                        $('#book').fadeIn();
                        });
                                $('#choosecar').click(function(){
                        $('#adds').fadeOut();
                                $('#list').fadeIn();
                                $('#list2').fadeIn();
                                $('#book').fadeOut();
                                $(this).removeClass('btn btn-default').addClass('btn bacgroundFACF00');
                                $('#extras').removeClass('btn bacgroundFACF00').addClass('btn btn-default').attr('disabled', 'disabled');
                                $('#finish').removeClass('btn bacgroundFACF00').addClass('btn btn-default').attr('disabled', 'disabled');
                        });
                                $('#extras').click(function(){
                        $('#extras').addClass('bacgroundFACF00').removeClass('btn-default');
                                $('#finish').removeClass('bacgroundFACF00').addClass('btn-default');
                                $('#adds').fadeIn();
                                $('#list').fadeOut();
                                $('#list2').fadeOut();
                                $('#book').fadeOut();
                        });
                        $('#booking').submit(function(){
                        if (!$('#firstName').val()){
                        $('#firstName').focus();
                                return false;
                        }
                        if (!$('#lastName').val()){
                        $('#lastName').focus();
                                return false;
                        }
                        if (!$('#emaila').val()){
                        $('#emaila').focus();
                                return false;
                        }
                        if ($('#emaila').val() != $('#verifyemail').val()){
                        $('#verifyemail').focus();
                                return false;
                        }
                        return false;
                        });
                                $('#another').click(function(){
                        $('#resume').hide();
                                $('#reserve').show();
                        });
function loadDefaultValues(){
    var today = new Date();
            var options = {year: 'numeric', month: '2-digit', day: '2-digit'};
            today.setDate(today.getDate() + 1);
           // $('#recogidaFecha').val(today.toLocaleDateString('es-ES', options).split('/').reverse().join('-'));
            today.setDate(today.getDate() + 5);
            //$('#devolucionFecha').val(today.toLocaleDateString('es-ES', options).split('/').reverse().join('-'));
           // $('#recogidaHora').val('11:00');
           // $('#devolucionHora').val('11:00');
            $('#book').hide();
            $('#adds').hide();
            $('#resume').hide();
    }
function getVehicleList(provider){
    var $This = $('.padding6Form');
            var company = 'compania=' + provider.val + '&';
            var numerotour = 'numerotour=&';
            if (document.getElementById('countryrecogida').value == 'united states of america' || document.getElementById('countryrecogida').value == 'US'){

    if ($('#radiost2').prop("checked") == true){

    $('#radiost2').prop("checked", true);
            if (provider.val === 'ZT'){
    numerotour = 'numerotour=&servicetour=2&';
    $('#numerotour1').val('2');
    }
    else if (provider.val === 'ZR'){
    numerotour = 'numerotour=&servicetour=2&';
    $('#numerotour1').val('2');
    }
    else{
    numerotour = 'numerotour=ITULCARS&servicetour=2&';
    $('#numerotour1').val('2');
    }
    $('#itincludes').html('Daily Charge Time Mileage <i class="fas fa-plus-circle" style="color:green"></i> Loss Damage Waiver <i class="fas fa-plus-circle" style="color:green"></i> Taxes and Fees');
        }
        else if ($('#radiost4').prop("checked") == true){

        if (provider.val === 'ZT'){
        numerotour = 'numerotour=&servicetour=4&';
        $('#numerotour1').val('4');
        }
        else if (provider.val === 'ZR'){
        numerotour = 'numerotour=&servicetour=4&';
        $('#numerotour1').val('4');
        }
        else{
        numerotour = 'numerotour=ITUICARS&servicetour=4&';
        $('#numerotour1').val('4');
        }
        $('#itincludes').html('Daily Charge Time Mileage <i class="fas fa-plus-circle" style="color:green"></i> Loss Damage Waiver <i class="fas fa-plus-circle" style="color:green"></i> Taxes and Fees <i class="fas fa-plus-circle" style="color:green"></i> Additional driver');
            }
            else if ($('#radiost5').prop("checked")){

            if (provider.val === 'ZT'){
            numerotour = 'numerotour=&servicetour=5&';
            $('#numerotour1').val('5');
            }
            else if (provider.val === 'ZR'){
            numerotour = 'numerotour=IT1002785LGA&servicetour=5&';
            $('#numerotour1').val('5');
            }
            else{
            numerotour = 'numerotour=ITUFCARS&servicetour=5&';
            $('#numerotour1').val('5');
            }
            $('#itincludes').html('Daily Charge Time Mileage <i class="fas fa-plus-circle" style="color:green"></i> Loss Damage Waiver <i class="fas fa-plus-circle" style="color:green"></i> Taxes and Fees <i class="fas fa-plus-circle" style="color:green"></i> Aditional driver <i class="fas fa-plus-circle" style="color:green"></i> Liability Insurance Supplement ');
            }
            else if ($('#radiost6').prop("checked") == true){

            if (provider.val === 'ZT'){
            numerotour = 'numerotour=&servicetour=6&';
            $('#numerotour1').val('6');
            }
            else if (provider.val === 'ZR'){
            numerotour = 'numerotour=IT1002785MLB&servicetour=6&';
            $('#numerotour1').val('6');
            }
            else{
            numerotour = 'numerotour=&servicetour=6&';
            $('#numerotour1').val('6');
            }
            $('#itincludes').html('Daily Charge Time Mileage <i class="fas fa-plus-circle" style="color:green"></i> Loss Damage Waiver <i class="fas fa-plus-circle" style="color:green"></i> Taxes and Fees <i class="fas fa-plus-circle" style="color:green"></i> Aditional driver <i class="fas fa-plus-circle" style="color:green"></i> Liability Insurance Supplement <i class="fas fa-plus-circle" style="color:green"></i> Fuel purchase option');
}
}

        var voucher = 'voucher=casr2go2001&';
        var  recogidaFechaChange  =  $('#recogidaFechaChange').val();
        var  devolucionFechaChange  =  $('#devolucionFechaChange').val();
      
        $.ajax({
                data:voucher + numerotour + company + '<?php echo http_build_query($formvalue); ?>&recogidaFechaChange=' + recogidaFechaChange + '&devolucionFechaChange=' + devolucionFechaChange,
                dataType:'json',
                type:'post',
                url:'<?= base_url('carslists/getsetup') ?>',
                error:function(){
                console.log(arguments);
                },
                success:function(response){
                //alert(response);
               
            if (response.datos.Errors){
                if (response.datos.Errors.Error['@attributes'].ShortText != 'INCORRECT RENTAL CITY CODE'){
                alert(response.datos.Errors.Error['@attributes'].ShortText);
                        window.location = "<?= base_url('carslists') ?>"
                }
                }
                if (response.datos.VehAvailRSCore){
                var vehicles = response.datos.VehAvailRSCore.VehVendorAvails.VehVendorAvail.VehAvails.VehAvail;
                        for (var j = 0; j < vehicles.length; j++){
                var veh = vehicles[j];
                        window.vehicles[provider.val + j] = veh;
                        window.vehiclesKeys[provider.val + j] = veh.VehAvailCore.TotalCharge['@attributes'].EstimatedTotalAmount;
                }
                }
                },
                complete:function(){
                provider.done = true;
                },
                beforeSend:function(){
                Message.canHide = false;
                        Message.showConfirmDialog('<img class="list-loader" src="img/loading1.gif" />');
                }
        });
}
function finishFillDefault(){
                    var finished = true;
                            for (var i in window.providers){
                    finished &= window.providers[i].done;
                    }
                    if (!finished){
                    return;
                    }
                    // if(!Object.keys(vehicles).length){
                    // return;
                    // }
                    Message.canHide = true;
                            Message.$MessageBackground.click();
                            var html = $('#list').html();
                            var html2 = $('#list2').html();
                            var vendor1 = '';
                            var vendor2 = '';
                            var vendor3 = '';
                            var keysSorted = Object.keys(window.vehiclesKeys).sort(function(a, b){return window.vehiclesKeys[a] - window.vehiclesKeys[b]});
                            var tot = 0;
                            html += '<div class="row marginTop1 padding1" style="background-color:#f8f8f8"><div class="col-md-4" style="text-align: center !important;"><img src="img/hertzico.png"></div><div class="col-md-4" style="text-align: center !important;"><img src="img/dollarico.png"></div><div class="col-md-4" style="text-align: center !important;"><img src="img/thriftyicono.png"></div></div>';
                            
    for (var i = 0; i < keysSorted.length; i++){
                    var veh = window.vehicles[keysSorted[i]];
                            var logo = getLogo(keysSorted[i]);
                            var clase = $('#vehiculoClase').val();
                            tot += (clase && clase != veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size?0:1);
                            if (logo == 'hertzico'){

                    vendor1 += '<div class="col-md-12 p-0 numero1">';
                            var valor1 = (parseInt(veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount) + parseInt((veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount * porcentajehertz) / 100)) * 1.05;
                            if (porcentagentoperatorvalue > 0){
                    valor1 = valor1 - ((valor1 / 100) * porcentagentoperatorvalue);
                    }

                    var recomendado = '';
                            if (i == 0){
                    recomendado = '<div class="bacgroundFACF00 parpadea fontsize12" style="border-radius: 40px 0px 40px 0px;"><i>Recommended!</i></div>';
                    } else{
                    recomendado = '<div><br /></div>';
                    }

                    vendor1 += '<div class="col-md-12 grupo-passo2-lista rn-car-item' + (clase && clase != veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size?' oculto':'') + '" data-veh="' + keysSorted[i] + '"><div class="rn-car-item-review"><img src="img/hertzico1.png" width="50"></div><div class="grupo-automoveis"><div class="rn-car-item-thumb"><img src="https://images.hertz.com/vehicles/220x128/' + veh.VehAvailCore['Vehicle'].PictureURL + '" alt="' + veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name + '"></div><div class="rn-car-item-info ofertas"><h3>' + getVehicleType(veh.VehAvailCore.Vehicle.VehType['@attributes'].VehicleCategory).toUpperCase() + ' - ' + getVehicleClass(veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size).toUpperCase() + '</h3><p class="class=" grupo-veiculo-janela-detalhes-h4 ">' + veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name + '</p><div class="rn-car-list-n-price"><ul><li class="vehPerks">' + veh.VehAvailCore.Vehicle["@attributes"].PassengerQuantity + ' Passengers</li><li>' + veh.VehAvailCore.Vehicle["@attributes"].BaggageQuantity + ' Suitcases</li><li>' + veh.VehAvailCore.Vehicle["@attributes"].TransmissionType + ' Trasmission</li>' + (veh.VehAvailCore.Vehicle["@attributes"].AirConditionInd === 'true'?'<li>Air Conditioning</li>':'') + '</ul><div class="rn-car-price-wrap"><a class="rn-car-price"><span class="rn-car-price-from">Total Rate</span><span class="rn-car-price-format"><span class="rn-car-price-amount valor">' + valor1.toFixed(2) + '</span> <span class="rn-car-price-per">USD</span></span></a></div></div></div></div></div>';
                    vendor1 += '</div>';
                    }

                    }
                    var recomendado = '';
                            var recomendadodiv = 0;
                            for (var i = 0; i < keysSorted.length; i++){

                    var veh = window.vehicles[keysSorted[i]];
                            var logo = getLogo(keysSorted[i]);
                            var clase = $('#vehiculoClase').val();
                            tot += (clase && clase != veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size?0:1);
                            if (logo == 'dollarico'){
                    vendor2 += '<div class="col-md-12 p-0 class' + keysSorted[i] + '">';
                            var valor2 = (parseInt(veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount) + parseInt((veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount * porcentajedollar) / 100)) * 1.05;
                            if (porcentagentoperatorvalue > 0){
                    valor2 = valor2 - ((valor2 / 100) * porcentagentoperatorvalue);
                    }


                    if (recomendadodiv == 0){
                    recomendado = '<div class="bacgroundFACF00 parpadea fontsize12" style="border-radius: 40px 0px 40px 0px;"><i>Recommended!</i></div>';
                            recomendadodiv = 1;
                    } else{
                    recomendado = '<div><br /></div>';
                    }

                    vendor2 += '<div class="col-md-12 grupo-passo2-lista rn-car-item' + (clase && clase != veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size?' oculto':'') + '" data-veh="' + keysSorted[i] + '"><div class="rn-car-item-review"><img src="img/dollarico.png" width="50"></div><div class="grupo-automoveis"><div class="rn-car-item-thumb"><img src="https://images.hertz.com/vehicles/220x128/' + veh.VehAvailCore['Vehicle'].PictureURL + '" alt="' + veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name + '"></div><div class="rn-car-item-info ofertas"><h3>' + getVehicleType(veh.VehAvailCore.Vehicle.VehType['@attributes'].VehicleCategory).toUpperCase() + ' - ' + getVehicleClass(veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size).toUpperCase() + '</h3><p class="class="grupo-veiculo-janela-detalhes-h4">' + veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name + '</p><div class="rn-car-list-n-price"><ul><li class="vehPerks">' + veh.VehAvailCore.Vehicle["@attributes"].PassengerQuantity + ' Passengers</li><li>' + veh.VehAvailCore.Vehicle["@attributes"].BaggageQuantity + ' Suitcases</li><li>' + veh.VehAvailCore.Vehicle["@attributes"].TransmissionType + ' Trasmission</li>' + (veh.VehAvailCore.Vehicle["@attributes"].AirConditionInd === 'true'?'<li>Air Conditioning</li>':'') + '</ul><div class="rn-car-price-wrap"><a class="rn-car-price"><span class="rn-car-price-from">Total Rate</span><span class="rn-car-price-format"><span class="rn-car-price-amount valor">' + valor2.toFixed(2) + '</span> <span class="rn-car-price-per">USD</span></span></a></div></div></div></div></div>';
                            vendor2 += '</div>';
                    }

                    }
//                     for(var i = 0; i<keysSorted.length;i++){
//
//                     var veh = window.vehicles[keysSorted[i]];
//                     var logo = getLogo(keysSorted[i]);
//                     var clase = $('#vehiculoClase').val();
//
//                     tot += (clase && clase != veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size?0:1);
//
//                     var recomendado = '';
//                     if(i == 0){
//                     recomendado = '<div class="bacgroundFACF00 Dreamwood parpadea" style="border-radius: 40px 0px 40px 0px;"><i>Recommended rate for THRIFTY!</i></div>';
//                     }
//
//                     if(logo == 'thriftyicono'){
//                     vendor3 +='<div class="col-md-4 numero3">';
//                     var valor3 = (parseInt(veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount) + parseInt((veh.VehAvailCore.TotalCharge["@attributes"].EstimatedTotalAmount * porcentajethrifty) / 100)) * 1.05;
//
//                     if(porcentagentoperatorvalue > 0){
//                     valor3 = valor3 - ((valor3 /100 ) * porcentagentoperatorvalue);
//                     }
//
//                     vendor3 +=' 				 			 				 			 			 				 				<div class="bacgroundFFF bordesDivBottom text-center padding2 grupo-passo2-lista'+ 					(clase && clase != veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size?' oculto':'')+ 					'" data-veh="'+ 					keysSorted[i]+ 					'"> 				 			 					<div class="row grupo-automoveis"> 						 					 					 						<div class="col-md-12 col-sm-12 col-xs-12"> 							 						 						 							<img src="https://images.hertz.com/vehicles/220x128/'+ 						veh.VehAvailCore['Vehicle'].PictureURL+ 						'" alt="'+ 						veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name+ 						'"> 		<img src="img/thriftyicono.png" style="width:12%;">	 						</div>		 						 					 					 						<div class="col-md-12 col-sm-12 col-xs-12 ofertas text-center" style="border-radius: 124px 0px 204px 0px; margin-top:1%; background-color:#FACF00 !important;	color:#000; padding:1%;"> 							<div class="bacgroundFFF padding2" style="border-radius: 124px 0px 204px 0px;"> 							 							 								<p><h4>Total Rate</h4></p> 	 				 								<p> 								 									<h3> 									 										<i> 										 											<label class="valor">Total '+ 								valor3.toFixed(2) +' '+veh.VehAvailCore.TotalCharge["@attributes"].CurrencyCode+ 							' 										 								</label> 									 										</i> 								 								 									</h3> 							 							 								</p> 							 												 						 						 						 							</div> 	 	 					 					 						</div> 					 					 					 						<div class="col-md-12 col-sm-12 col-xs-12 informacoes-carro text-center" style="font-size:11px; margin-top:1%;"> 						 		 							<label class="grupo-veiculo-janela-detalhes-label">'+ 						getVehicleType(veh.VehAvailCore.Vehicle.VehType['@attributes'].VehicleCategory).toUpperCase()+ 						' - '+ 						getVehicleClass(veh.VehAvailCore.Vehicle.VehClass["@attributes"].Size).toUpperCase()+ 						' 						 						 							</label> 						 							 						 						 							<p class="class="grupo-veiculo-janela-detalhes-h4">'+ 							veh.VehAvailCore.Vehicle.VehMakeModel['@attributes'].Name+ 						' 						 							</p> 						 							 						 							<p class="vehPerks">'+ 							veh.VehAvailCore.Vehicle["@attributes"].PassengerQuantity+ 							' Passengers 						 							</p> 							<p>'+ 							veh.VehAvailCore.Vehicle["@attributes"].BaggageQuantity+ 							' Suitcases 	 						 	 							</p> 							<p>'+ 							veh.VehAvailCore.Vehicle["@attributes"].TransmissionType+ 							' Trasmission 							</p>  							'+ 							(veh.VehAvailCore.Vehicle["@attributes"].AirConditionInd==='true'?' 	 						 						 							<p>Air Conditioning</p>':'')+ 					' 						 					 					 						</div> 				 					</div> 	 		'+recomendado+'	 				</div>	 			 				';
//                         vendor3 +='</div>';
//                 }
//         }

        // html +='<div class="row"><div class="col-md-4">'+vendor1+'</div><div class="col-md-4">'+vendor2+'</div><div class="col-md-4">'+vendor3+'</div></div>';
        if($("#radiost2").is(':checked')) {  
                //html =vendor1 +vendor2 +vendor3;
                html =vendor1;
                html2 = vendor2;
        }
        else if($("#radiost4").is(':checked')) { 
                //html =vendor1 +vendor2 +vendor3;
                html =vendor1;
                html2 = vendor2;
        }
        else if($("#radiost5").is(':checked')) {
                //html = vendor1 +vendor2 +vendor3;
                html =vendor1;
                html2 = vendor2;
        }
        else if($("#radiost6").is(':checked')) { 
                //html =vendor1 +vendor2 +vendor3;
                html =vendor1;
                html2 = vendor2;
        }

        $('#list').html(html);
        $('#list2').html(html2);
        if(tot==0){
                $('#list>.oculto,#list2>.oculto').each(function(){
                        $(this).removeClass('oculto');
                });
        }
        clearInterval(window.finish);
        $('#footer').show('fast');
}
	function fillDefaultVehicles(){
		window.providers = {hertz:{val:'',done:false}, dollar:{val:'ZR',done:false}, thrifty:{val:'ZT',done:false}};
		window.vehicles = {};
		window.vehiclesKeys = {};
		window.done = true;
		for(var i in window.providers){
                    
			Concurrent.Thread.create(getVehicleList, window.providers[i]);
		}
		//$('#footer').hide('fast');
		window.finish = setInterval(finishFillDefault, 1000);		
	}
	loadDefaultValues();

	//submenu items - go back link
	$('.go-back').on('click', function(){
		$(this).parent('ul').addClass('is-hidden').parent('.has-children').parent('ul').removeClass('moves-out');
	});

	function closeNav() {
		$('.cd-nav-trigger').removeClass('nav-is-visible');
		$('.cd-main-header').removeClass('nav-is-visible');
		$('.cd-primary-nav').removeClass('nav-is-visible');
		$('.has-children ul').addClass('is-hidden');
		$('.has-children a').removeClass('selected');
		$('.moves-out').removeClass('moves-out');
		$('.cd-main-content').removeClass('nav-is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
			$('body').removeClass('overflow-hidden');
		});
	}

	function toggleSearch(type) {
		if(type=="close") {
			//close serach 
			$('.cd-search').removeClass('is-visible');
			$('.cd-search-trigger').removeClass('search-is-visible');
			$('.cd-ovrlay').removeClass('search-is-visible');
		} else {
			//toggle search visibility
			$('.cd-search').toggleClass('is-visible');
			$('.cd-search-trigger').toggleClass('search-is-visible');
			$('.cd-overlay').toggleClass('search-is-visible');
			if($(window).width() > MqL && $('.cd-search').hasClass('is-visible')) $('.cd-search').find('input[type="search"]').focus();
			($('.cd-search').hasClass('is-visible')) ? $('.cd-overlay').addClass('is-visible') : $('.cd-overlay').removeClass('is-visible') ;
		}
	}

	function checkWindowWidth() {
		//check window width (scrollbar included)
		var e = window, 
            a = 'inner';
        if (!('innerWidth' in window )) {
            a = 'client';
            e = document.documentElement || document.body;
        }
        if ( e[ a+'Width' ] >= MqL ) {
			return true;
		} else {
			return false;
		}
	}

	function moveNavigation(){
		var navigation = $('.cd-nav');
  		var desktop = checkWindowWidth();
        if ( desktop ) {
			navigation.detach();
			navigation.insertBefore('.cd-header-buttons');
		} else {
			navigation.detach();
			navigation.insertAfter('.cd-main-content');
		}
	}
});
</script>