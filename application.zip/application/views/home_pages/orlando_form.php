<div class="rn-carousel carousel slide" id="carouselExampleControls" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item beactive">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">#1 Car Rent Service<br> In Your City</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
<img class="d-block w-100" src="<?php base_url() ?>assets/images/slide1.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">Quality Cars with<br> Unlimited Miles</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
<img class="d-block w-100" src="<?php base_url() ?>assets/images/slide2.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">24/7 Customer<br> Support</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
                 <a class="btn btn-main btn-lg rn-fade-bottom rn-caption-item-3" href="#">Book Now</a> 
            </div>-->
            <!-- <div class="rn-slider-overlayer"></div> -->
            <img class="d-block w-100" src="<?php base_url() ?>assets/images/slide3.jpg" alt="slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="lnr lnr-chevron-left" aria-hidden="true"></span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="lnr lnr-chevron-right" aria-hidden="true"></span>
    </a>
    <div class="rn-small-search-form">
        <div class="rn-small-search-form-title">
            <h2>Book Now</h2>
        </div>
            <?php echo form_open('carslists','class="padding6Form" autocomplete="off"'); ?>
        <?php if(!$this->session->userdata('logged_in')){ ?>
        <div class="rn-icon-input row">
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                <?php }else{ ?>
            <div class="rn-icon-input row" style="display: none">
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                 <?php } ?>
            <div class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input name="formulario" type="hidden" value="OTA_VehAvailRQCore"/>
                <input type="text" id="rec" name="selectpickup" placeholder="Pickup Location" required="required">
                <?php echo form_error('selectpickup') ?>
                <div id="selectpickupShow"></div>
                <input id="recogida" type="hidden" name="recogida[lugar]" />
                <input id="recogida_vendor" type="hidden" name="recogidavendor" />
            </div>
            <div class="col-md-12 text-white p-0" id="returnInAnother">
                <input type="checkbox" id="drop-select">
                <label for="drop-select" value="1" id="checkreturnLotation">I want to return my car in other location </label>
            </div>
            <div id="drop-location" class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input type="text" name="selectpickupdrop" id="dev" placeholder="Drop Location" required="required">
                <div id="selectDevShow"></div>
                 <input id="devolucion" type="hidden" name="devolucion[lugar]" />
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="recogida[fecha]" placeholder="Pickup Date" readonly id="pickup-date" class="flatpickr-input datepicker pickupdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>
                            <input type="text" name="recogida[hora]" placeholder="Time" id="pickup-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="recogidaHora" name="recogida[hora]" id="pickup-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                         
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="devolucion[fecha]" placeholder="Drop Date" readonly id="drop-date" class="flatpickr-input dropdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>-->
    <!--                        <input type="text" name="devolucion[hora]" placeholder="Time" id="drop-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="devolucionHora" name="devolucion[hora]" id="drop-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="countryrecogida" id="countryrecogida">
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-md-6 p-0">
                        <div class="rn-icon-input">
                            <select class="flatpickr-input bg-white" id="ageSelector" name="ageSelector" required="required">
                                <option value="">Select Age</option>
                                <option value="30-69">30-69</option>
                                <option value="29">29</option>
                                <option value="28">28</option>
                                <option value="27">27</option>
                                <option value="26">26</option>
                                <option value="25">25</option>
                                <option value="24">24</option>
                                <option value="23">23</option>
                                <option value="22">22</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 p-0">
                        <select class="flatpickr-input bg-white" name="preferencias[0][vehiculo][categoria]" class="form-control cursorPointer" id="preferenciasVehicleType" required="required">
                            <option value="">Vehicle Type</option>
                            <option value="">no-preference</option>
                            <option value="1">car-economy</option>
                            <option value="2">car-compact</option>
                            <option value="3">car-intermediate</option>
                            <option value="4">car-standard</option>
                            <option value="5">car-fullsize</option>
                            <option value="6">suv-intermediate</option>
                            <option value="7">van-mini</option>
                            <option value="8">convertible-standard</option>
                            <option value="9">suv-standard</option>
                            <option value="10">van-fullsize</option>
                            <option value="11">car-premium</option>
                            <option value="12">car-luxury</option>
                            <option value="13">suv-fullsize</option>
                        </select>
                    </div>
                </div>
            </div>
            <button id="continue" class="btn btn-main btn-lg btn-shadow btn-block" type="submit">
            <i class="fas fa-search"></i> Check Now</button>
            <button id="popup" type="button" data-toggle="modal" data-target="#login" class="btn btn-main btn-lg btn-shadow btn-block m-0 hidden">
            <i class="fas fa-search"></i> Check Now</button>
        <?php echo form_close(); ?>
    </div> 
</div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <div class="rn-section-title mb-4 left-contant">
                        <h6 class="rn-title">Car rental in Orlando: everything you need to know</h6>
                        <p>You need a great car to get around Orlando, whether you are traveling for business or pleasure. See the famous sites in the region and stop in front of the popular restaurants in Orlando. cars2gorentals.com has compiled your most popular questions about car rental in Orlando. Learn how to get the best prices on your ideal car.</p>
                        <br><h6 class="rn-title">Where can I find a car rental offer in Orlando?</h6>
                        <p>Cars2gorentals.com makes it easy to get cheap rates. Simply enter the dates of your trip and scroll through the variety of car rental providers, choose the main rental locations and find the cheapest packages Orlando has to offer. You should also:</p>

                    <p>Take the time to compare the price of the vehicle</p>
                    <p>Avoid pickups or returns at the airport, which generally cost more</p>
                    <p>Determine in advance the amount of mileage / fuel you can use</p>
                    <p>Search and book in advance</p>
                    <p>Just following some of these tips can help you save a lot on your rental car in Orlando.</p>
                    <br>
                      <h6 class="rn-title">Which rental companies have outlets in Orlando?</h6>
                      <p> We have around 80 car rental providers from which you can choose. We have economic names like Budget and Thrifty and global names like Ace and Enterprise. Explore the reviews to help you determine which one meets your needs.</p>
                       <br>
                      <h6 class="rn-title">What kind of rental car should I get for my trip to Orlando?</h6>
                      <p> It all depends on your needs and the activities you want to do in Orlando. If you have trouble choosing, be sure to check our chart below. We have compared the most popular car categories for you.</p>
                           <br>
                      <h6 class="rn-title">How old must you be to rent a car in Orlando?</h6>
                      <p>Generally, to rent a car in Orlando you must be at least 21 years old. However, you may find that there is an additional charge if you are under 25 or for cars of a higher category in particular. Read the terms of the provider to find out what the exact rate is before booking your rental.</p>
                      <br>
                      <h6 class="rn-title">Does Orlando require rental car insurance?</h6>
                      <p>Insurance is always required wherever you rent a Car. However, your current car insurance may cover it. In addition, if you pay with your credit card, the benefits of the card can also secure it. Keep in mind that your policies may not fully cover your rental, and you should add it to your reservation for Orlando. Check in advance and, if necessary, you can add it conveniently on the payment page of cars2gorentals.com.</p>
                      <br>
                       <h6 class="rn-title">What is the fuel policy for car rental in Orlando?</h6>
                       <p>Most suppliers offering you a choice of fuel policies. Below is a list of the most common.</p>

                        <br>
                       <h6 class="rn-title">What fuel policy do you recommend?</h6>
                       <p>We suggest a full tank policy. You should receive your car at most. But, if you return your rent with less than the amount you received it, most companies will charge a premium and sometimes up to triple the amount of current fuel prices to recharge. To get a cheaper rate, fill your tank before returning the rent. Stations near airports or car rental locations tend to have higher prices.</p>
                       <br>
                       <h6 class="rn-title">Do I have to get unlimited miles when renting a car in Orlando?</h6>
                       <p>Unlimited miles are an excellent option if you plan to do some sightseeing or visit many clients throughout Orlando. You can drive anywhere you want without incurring additional costs. Check your rental agreement to find out if there are mileage limitations.</p>
                        <br>
                       <h6 class="rn-title">Before you leave the lot</h6>
                       <p>Before starting your vacation in Orlando, check some items before leaving the rental lot. It is important:</p>
                        <p>Check the vehicle and make sure there are no dents or scratches. Be sure to write it down on paperwork, or you can be charged for it</p>
                        <p>Have a spare tire, a wrench and a jack in the trunk properly inflated</p>
                        <p>Become familiar with the controls of your car. Adjust the mirrors and seats, and observe how to turn on the lights and windshield wipers.</p>
                        <p>Discover how radio or entertainment functions work. You don't want unnecessary distractions in a new city</p>
                       <br>
                       <h6 class="rn-title">Book your rental car in Orlando today</h6>
                       <p>When you book your rental car in Orlando with cars2gorentals.com, you will know that you can count on a wonderful vehicle that will give you more money to spare. Take advantage of the cheap deals on your car rental in Orlando when you book with cars2gorentals.com. We will look here.</p>
                       <br>
                       <h6 class="rn-title">Some popular Queries for Car Rental in Miami</h6>
                       <ul>
                            <li>best car rental Orlando airport</li>
                            <li>cheap car rental Orlando airport</li>
                            <li> airport car rental Orlando Florida</li>
                            <li> car rental Orlando Sanford airport</li>
                            <li> car rental Orlando Florida airport</li>
                            <li> car rentals Orlando airport</li>
                            <li> car rental from Orlando airport</li>
                            <li> Orlando Minivan Rental</li>
                            <li> Orlando airport minivan rental</li>
                            <li> airport car rental Orlando Florida</li>
                            <li> last minute car rental Orlando</li>
                            <li> last minute car hire Orlando</li>
                            <li> Orlando last minute car rental deals</li>
                       </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>