<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>Terms and Conditions</h1>
                        <!--<p>Cras eros lorem, rhoncus ac risus sit amet, fringilla ultrices purus.</p>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="text-center mb-30">Program Terms and Conditions</h3>
                </div>
                <p class="col-md-12"><strong>Changes/Modifications to "Pay Now" rentals are subject to the terms and conditions below.</strong></p>
                <ol>
                    <li>Discount will vary depending on location, length and date of rental; discount will not apply in all cases.</li>
                    <li>No refunds or credits for unused rental days.</li>
                    <li>Prepaid rates cannot be combined with any promotional offer, voucher or certificate.</li>
                    <li>Rates exclude vehicle licensing recovery fee, airport facility use fee/customer facility charge, hotel concession fees, other cost recovery fees, governmental surcharges, taxes or other optional items such as child seats, luggage racks, refueling items, insurance, NeverLost® or optional refueling, or one-way charges for which the renter may be responsible. Excluded services cannot be prepaid; if accepted, must be paid locally at time of rental.</li>
                    <li>Changes to a reservation must be done at cars2gorentals.com using the "Modify/Cancel" option. Any changes to the reservation may impact the rental charges. If a prepaid reservation is cancelled more than 24 hours before the pickup time, a $50 cancellation fee will be assessed. If the prepaid reservation is cancelled within 24 hours before the pickup time, a $100 fee will be assessed.  If the customer does not cancel the reservation prior to the time of pick-up and the rental vehicle is not picked up on the rental date, the entire prepaid amount will be forfeited.</li>
                    <li>Approximate rental charges are based on available information at the time of reservation for renters age 25 and older. For minimum age requirements please see "Rental Qualifications and Requirements" link below for details. Please note that for renters under age 25 an additional daily age differential charge may apply. Additional fees or surcharges may be applied at time of rental. </li>
                    <li>The customer will be asked to enter a valid credit card number at the end of a change to a prepaid reservation. This must not be the same credit card that was used for the original reservation. If the customer wishes to change the credit card, then the original reservation must be cancelled (see terms and conditions for Cancellations) and a new reservation made. Debit cards and Hertz Credit Cards are valid forms of payment for prepaid rates.</li>
                    <li>When renting the vehicle at the counter, you must produce the same or different credit card with which you paid online and a valid driver's license. The credit card used must be in your name and presented at the time of rental. </li>
                    <li>Standard rental qualifications and rental period restrictions apply.</li>
                    <li>A valid drivers license and credit card must be presented at the time of rental to cover any reasonably anticipated charges which have not been included in the prepaid voucher.</li>
                    <li>All rentals are subject to Hertz, Dollar and Thrifty  standard terms and conditions of the  Rental Agreement in effect at time and place of rental.</li>
                    <li>Rental days are based on 24 hour periods commencing at time of pickup. Additional days will apply if the rental is kept longer than specified (additional days begin after a 29 minute grace period and will be billed at a higher rate).</li>
                    <li>This program is available at participating cities/locations and blackouts may apply.</li>
                    <li>Voluntary upgrades will be charged at locally applicable rates.</li>
                    <li>Please print your prepay confirmation and present at the counter.</li>
                    <li>Prepaid rates are subject to availability. </li>
                    <li>LIS cannot be provided for rentals in excess of 30 days in certain states, including CA, NY, FL, TX, NC and RI.</li>
                    <li>Please note that due to the nature of the prepaid rates, Hertz, Dollar and Thrifty cannot provide a single receipt for a prepaid rental.  Two receipts will be provided - one receipt for the prepaid amount and one receipt for the remainder of charges payable at the counter.</li>
                    <li>Your cars2gorentals.com  Prepaid Rental will appear on your credit card statement as "Cars2gorentals".</li>
                </ol>
            </div>
        </div>
    </section>