<div class="rn-page-title">
       <div class="rn-pt-overlayer"></div>
       <div class="container">
           <div class="row">
               <div class="col-lg-12">
                   <div class="rn-page-title-inner">
                       <h1>FAQs</h1>
                       <p>General FAQs</p>
                   </div>
               </div>
           </div>
       </div>
   </div>
   <section class="rn-section">
       <div class="container">
           <div class="row">
               <div class="col-lg-12">
                   <h2><a data-toggle="#tab1" class="tabLink active">Rental Car Protection <i class="fa fa-angle-down fa-pull-right"></i></a></h2>
                   <div id="tab1" class="sliding-tabs">
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <ul>
                                   <li>Liability Insurance Supplement</li>
                                   <li>Limited Loss Damage Waiver</li>
                                   <li>Loss Damage Waiver</li>
                                   <li>Partial Damage Waiver</li>
                                   <li>Personal Accident Insurance</li>
                                   <li>Personal Effects Coverage</li>
                               </ul>
                           </div>
                       </div>
                   </div>
                   <h2><a data-toggle="#tab2" class="tabLink">Optional Protection Plans <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                   <div id="tab2" class="sliding-tabs">
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Liability Insurance Supplement*</h2>
                               <p>Liability Insurance Supplement (LIS) provides you with up to $1 million of increased protection should bodily injury and property damage claims be made against you by people injured in an accident. LIS safeguards your insurance policy and/or your personal assets for the first $1 million should such claims be made against you. LIS also provides uninsured/underinsured motorist coverage up to $1,000,000 per occurrence for combined bodily injury and/or property damage claims.</p>
                               <p>Where permitted by law, no liability protection is provided under the terms of the Rental Agreement from claims of injury by others against you resulting from an accident with the rental car. Some locations provide primary protection under the Rental Agreement. However, in those situations where protection is provided by Hertz, such protection is generally no more than the minimum limits required by individual state law. (See chart for these Financial Responsibility Limits). For these reasons, some people feel more comfortable traveling with additional liability protection. That is why Hertz makes the Liability Insurance Supplement (LIS) option available to you. Here are some facts you should know:</p>
                               <ul>
                                   <li>LIS provides coverage for you and other authorized operators of your rental vehicle for third party liability claims.</li>
                                   <li>LIS is primary protection to your personal policy and provides for the first $1,000,000** of coverage for combined bodily injury and/or property damage claims per occurrence in all states but California and Florida where the coverage is $2,000,000.</li>
                                   <li>LIS also provides uninsured and underinsured motorist coverage for bodily injury up to $1,000,000 per accident</li>
                               </ul>
                               <h6>*LIS includes an excess third party insurance policy issued by ACE American Insurance Company.</h6>
                               <h6>** Represents a combined total of the state limit where the accident occurred, plus LIS.</h6>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Does LIS Coverage Apply Everywhere?</h2>
                               <p>You and authorized drivers are covered while driving the rental car within the United States and Canada, but only if the car is rented in the U.S. Coverage does not apply in Mexico.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Does My Personal Policy Provide Liability Coverage?</h2>
                               <p>You may not need the automobile insurance offered by Hertz. Your personal automobile insurance policy may provide coverage for your liability while operating a rental vehicle. The purchase of automobile rental liability insurance is not required as a condition of renting an automobile.</p>
                               <p>The terms of different automobile and umbrella policies vary greatly. Because LIS may provide a duplication of coverage already provided by your personal policy, it is recommended that you check your policy or consult your insurance agent or insurer. But remember that in most cases, before any coverage by your own policy would be applied to a claim, the protection provided under the Rental Agreement and LIS, if you accept it, would first have to be exhausted. Keep in mind that claims against your personal policy can often result in premium increases or even lead to cancellation.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What About Credit Card Coverage?</h2>
                               <p>We suggest you check as to the types and extent of coverage being offered. Credit card insurance may not cover third party liability claims or may be supplemental and only reimburse you for amounts not covered by any other insurance.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What Happens if I Damage Someone Else's Property with a Hertz Rental Car?</h2>
                               <p>The Liability Insurance Supplement, will provide primary coverage for third party liability claims, up to a limit of $1 million per accident.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Exclusions</h2>
                               <p>There are some exclusions to this coverage which we feel you should know. Under LIS, in the event of an accident, you will not be protected for third party liability:</p>
                               <ul>
                                   <li>If LIS is not accepted at commencement of the rental or if you fail to pay the charges for LIS.</li>
                                   <li>If you or an authorized driver operated the rental car in violation of the Rental Agreement. Including, but not limited to, operating the car while legally intoxicated or under the influence of alcohol, drugs or other absorbed elements.</li>
                                   <li>If the car or LIS coverage was obtained by fraud or misrepresentation. LIS is third party liability coverage only.</li>
                                   <li>Except where permitted by law, LIS does not cover personal injury to you or any authorized operator of the rental car or to your or their family members who are related by blood, marriage or adoption and reside in your or their household.</li>
                               </ul>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">How to File an LIS Claim</h2>
                               <p>LIS coverage will automatically attach to the claim once you have properly reported the accident in accordance with the Rental Agreement.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Financial Responsibility Limits by State</h2>
                               <p>The following chart lists the Automobile Financial Responsibility Limits of the various states. Hertz is not required to provide such minimum protection in all states. However, the purchase of LIS will include primary protection which combines these minimum limits of protection with an excess insurance policy to provide the first $1,000,000 of combined bodily injury and/or property damage for each occurrence.</p>
                               <div class="col-md-6 fa-pull-left">
                                   <ul>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Alabama<span class="fa-pull-right">:</span></label>  <label class="col-md-8 m-0">25/50/25</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Alaska<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">50/100/25</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Arizona<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">15/30/10</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Arkansas<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/15</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">California<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">15/30/5</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Colorado<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/15</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Connecticut<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">20/40/10</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Delaware<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">10/20/5</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Dist. of Columbia<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Florida<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">10/20/10</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Georgia<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Hawaii<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">20/40/10</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Idaho<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/15</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Illinois<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">50/100</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Indiana<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Iowa<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">20/40/15</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Kansas<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10          </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Kentucky<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Louisiana<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">15/30/25       </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Maine<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">50/100/25          </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Maryland<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">30/60/15        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Massachusetts<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">20/40/5    </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Michigan<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">20/40/10        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Minnesota<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">30/60/10       </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Mississippi<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25     </label></li>
                                   </ul>
                               </div>
                               <div class="col-md-6 fa-pull-left">
                                   <ul>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Missouri<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Montana<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10         </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Nebraska<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Nevada<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">15/30/10          </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">New Hampshire<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25   </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">New Jersey<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">15/30/5       </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">New Mexico<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10      </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">New York<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25*/50*/10 *Death 50/100</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">North Carolina<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">30/60/25      </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">North Dakota<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Ohio<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">12.5/25/7.5 (Rental Car)</label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Oklahoma<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25            </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Pennsylvania<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">15/30/5         </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Rhode Island<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">South Carolina<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25      </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">South Dakota<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/25        </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Tennessee<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10           </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Texas<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">30/60/25               </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Utah<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/65/15                </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Vermont<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10             </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Virginia<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/20            </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Washington<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10          </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">West Virginia<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">20/40/10       </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Wisconsin<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/10           </label></li>
                                       <li><label class="col-md-4 m-0 fa-pull-left">Wyoming<span class="fa-pull-right">:</span></label>   <label class="col-md-8 m-0">25/50/20             </label></li>

                                   </ul>
                               </div>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Limited Loss Damage Waiver (LLDW)</h2>
                               <p>Limited Loss Damage Waiver (LLDW) is offered at select locations. When you purchase LLDW, which is not insurance, you will not be held responsible for loss or damage to the Hertz car up to a maximum waiver of $1,000, provided the loss or damage was not a result of any prohibited use of the car. You will be responsible for all damages in excess of $1,000.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Loss Damage Waiver (LDW)</h2>
                               <p>When you purchase Loss Damage Waiver (LDW), which is not insurance, you will not be held responsible for damage to the Hertz car in the event that any damage should occur, provided the loss or damage was not the result of any prohibited use of the car.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What is Your Responsibility?</h2>
                               <p>In most states, when you rent a car from Hertz, you are responsible for any and all loss or damage to the car resulting from any cause, including but not limited to, collision, rollover, theft, vandalism, seizure, fire, flood, hail or other acts of nature or God, regardless of fault.</p>
                               <p>In most states, in the event of any loss or damage to the car, regardless of fault, your financial responsibility extends to the full value of the car at the time of rental, less its salvage value, plus expenses for towing, storage and impound fees, diminution of value of the car as determined by Hertz, an administrative charge and a reasonable charge for loss of use. If your responsibility differs in the state in which you rent, it will be stated in paragraph 4. of the Rental Agreement. In California and Nevada, your responsibility for loss or damage to the car from vandalism unrelated to theft will not exceed $500 and you are not responsible for theft, regardless of purchasing LDW, unless the theft results from your fault. In Illinois, your responsibility for loss or damage related to theft is limited to $2000, unless the theft results from your fault.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What Protection Does LDW Offer?</h2>
                               <p>By accepting LDW, you will be relieved of all financial responsibility for loss or damage to the rental car, whether or not you have insurance to cover such damage. In order for LDW to be applied to any damage claims, you must properly report the related incident in accordance with the Rental Agreement.</p>
                               <p>However, if the vehicle is obtained through fraud or you have an accident resulting from use of the car in a manner prohibited by paragraph 5. of the Rental Agreement, LDW is void and you will be responsible for all loss or damage to the car.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Will My Own Car Insurance Cover Damage to the Rental Car?</h2>
                               <p>This is the question we are asked most often. The answer depends on the state in which you live and the type of policy you have. Each policy should be thoroughly checked for the specific terms and conditions associated with rental vehicles. You may indeed have sufficient coverage under your own auto policy. However, you may be responsible for a deductible and possibly be subject to premium increases or even policy cancellation, in the event of a claim involving a rental car. If you are not sure of the extent of your policy's coverage, ask your insurance agent or your insurer.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What Happens if Damage Occurs to a Hertz Rental Car During My Rental Period?</h2>
                               <p>Many of our customers are concerned about the cost of damages to the Hertz car during the rental. Hertz understands that accidents happen, whether it is a collision, act of nature, or damage that occurs while away from the vehicle, you can have peace of mind that you are covered.</p>
                               <p>We offer the Loss Damage Waiver so you don't have to worry or stress about driving our vehicles. The LDW isn't insurance, but it can protect you from the cost of damage to the Hertz’ car. By purchasing the LDW, you will not be responsible for any loss or damage that occurs to the car so long as you weren't using the car in a prohibited manner. However, without LDW, you'll be responsible for any loss or damage to the car including, but not limited to, theft, vandalism, collision, fire, and acts of nature, regardless of fault.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Hertz and Your Insurer</h2>
                               <p>Should you choose to rely on your own insurance, if the rental car is damaged, Hertz will work with your insurer to reach a settlement. However, you are still responsible for any balance or damages which your insurer does not pay.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What About Credit Card Coverage?</h2>
                               <p>As with any policy, you should check the extent of the coverage carefully with the card issuer. Remember, most credit card insurance is supplemental, which means it will only reimburse you for loss or damages over and above what is covered by any other insurance you may have and will not cover you for any damage, regardless of cause, if you accept LDW.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Should You Accept LDW?</h2>
                               <p>Only you can make that choice. By accepting LDW, you are relieved from all financial responsibility in the event of loss or damage to the rental car. Moreover, it eliminates the worry about policy limits and extended costs often associated in filing a claim with your own carrier. Hertz offers Loss Damage Waiver as an option to help protect you, should you need it. However, the choice is entirely yours.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Partial Damage Waiver (PDW)</h2>
                               <p>In most states, when you rent a car from Hertz, you are responsible for any and all loss or damage to the car resulting from any cause, regardless of fault. By accepting Partial Damage Waiver (PDW), which is available at select locations, Hertz will not hold you responsible for damage to the car in an amount equal to the applicable deductible on your personal automobile insurance, up to a maximum waiver of $1,000. In order for PDW to apply you must properly report the accident in accordance with the terms and conditions of the Rental Agreement.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Personal Accident Insurance (PAI)</h2>
                               <p>To help take the hassle out of traveling, Hertz makes a broad insurance protection package available to you that includes both Personal Accident Insurance and Personal Effects Coverage. Called PAI and PEC respectively, the benefits of each are outlined below. Please note that PAI and PEC are not available separately and must be taken in combination.</p>
                               <p>Personal Accident Insurance allows you to elect accidental death and accidental medical expense coverage for yourself and your passengers during the rental period of the vehicle.</p>
                               <p>Insurance that provides Accidental Death Benefits for an additional charge. Only one like coverage per rental.</p>
                               <h4>PAI Coverage</h4>
                               <table class="table table-bordered">
                                   <thead>
                                       <tr>
                                           <th>Benefits Schedule</th>
                                           <th>Renter</th>
                                           <th>Each Passenger</th>
                                       </tr>
                                   </thead>
                                   <tbody>
                                       <tr>
                                           <td>Accidental Death</td>
                                           <td>$175,000</td>
                                           <td>$17,500</td>
                                       </tr>
                                       <tr>
                                           <td>Accidental Medical Expenses Not to Exceed</td>
                                           <td>$2,500</td>
                                           <td>$2,500</td>
                                       </tr>
                                       <tr>
                                           <td>Ambulance Expenses Not to Exceed</td>
                                           <td>$250</td>
                                           <td>$250</td>
                                       </tr>
                                   </tbody>
                               </table>
                               <p>*Benefits referred to in this synopsis are not applicable for vehicles rented in the State of New York. In New York, the medical expenses limit is $3,500 for the renter and each passenger. The ambulance expense limit is $150 for the renter and each passenger**.</p>
                               <p>** Passengers are defined as all additional occupants including additional authorized operators of the Hertz vehicle.</p>
                               <p>Total benefits for any one accident are limited to $225,000 and are payable in addition to any other coverage for which you or your passengers are eligible. However, your benefits provided by other coverage may be affected by the PAI benefits. Rentals originating in the State of Mississippi do not have a single accident limit of $225,000.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Accidental Death Benefit</h2>
                               <p>We will provide benefits according to the Benefit Schedule, for accidental death which is independent of all other causes of death, which occurs during a period of car rental.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">Accidental Medical Expenses and Ambulance Expense Benefit</h2>
                               <p>We will provide benefits according to the Benefit Schedule, for Reasonable and Customary Charges associated with confinement to a hospital; treatment by a physician; transportation to or from a hospital by a professional ambulance service; and/or services rendered by a registered nurse within 90 days of an accident and upon recommendation of a physician.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">When are You Covered?</h2>
                               <p>If this coverage is accepted, the benefits for you apply to all accidental injuries during your rental period, regardless of whether you are actually in the car. Your passengers are also covered, but only for incidents occurring while they occupy the Hertz rental car. The first renter to sign the Rental Agreement shall be considered the renter.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">What if I'm Injured During an Accident while Driving a Hertz Rental Car?</h2>
                               <p>Your safety is important to us. Personal Accident Insurance will provide the renter up to $2,500 in coverage for accidental medical expenses. PAI covers accidental medical expense benefits for treatment of injuries sustained while driving your Hertz rental vehicle, and it must be rendered within 90 days. Additionally, PAI will provide up to $175,000 for your beneficiary in the event of your accidental death.</p>
                               <h4>Exclusions:</h4>
                               <p>Benefits are not paid for any loss caused directly or indirectly by or charges for:</p>
                               <ul>
                                   <li>Intentional self-inflicted injury, suicide, or any attempted suicide, while insane or sane;</li>
                                   <li>Aircraft travel;</li>
                                   <li>Committing or attempting to commit an assault or a felony;</li>
                                   <li>An accident which occurs while under the influence of alcohol or narcotics, unless prescribed and taken at the advice of a physician**;</li>
                                   <li>An accident which occurs while participating in a prearranged or organized race or testing of a vehicle;</li>
                                   <li>War or any act of war;</li>
                                   <li>Engagement in an illegal occupation;</li>
                                   <li>Pregnancy or complications thereof or resulting childbirth;</li>
                                   <li>Eyeglass replacement or eye examination unless injury causes impairment of sight;</li>
                                   <li>Insurance will not be in effect if the Renter converts the rental vehicle or during any period while the
                                       insured Renter is in violation of the Rental Agreement.The renter shall be deemed to have converted
                                       the rental vehicle whenever the rental vehicle is not returned to the Lessor by the return date or by the
                                       extended return date. This is a summary only and other restrictions may apply. See the Policy for
                                       additional exclusions, limitations and exceptions.</li>
                               </ul>
                               <p>**In Connecticut, the voluntary use of any controlled substance as defined in Title II of the Comprehensive Drug Abuse Prevention & Control Act of 1970, unless prescribed by a physician.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h2 class="rn-faq-title">How to File a PAI Claim</h2>
                               <p>You may <a href="https://images.hertz.com/pdfs/0217_PAI.pdf" target="_blank">download the PAI Claim Form here</a> or obtain a copy from any Hertz rental counter and
                                   submit it with a copy of the Rental Agreement to: Hertz Claim Management Corporation P.O. Box 716
                                   Park Ridge, NJ 07656.</p>
                               <p><strong>Claims must be submitted to the above address within twenty (20)*** days of the date of loss.</strong></p>
                               <p>***In Mississippi, 30 days of the date of loss.</p>
                           </div>
                       </div>
                   </div>
                   <h2><a data-toggle="#tab3" class="tabLink">Personal Effects Coverage (PEC) <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                   <div id="tab3" class="sliding-tabs">
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>What PEC Covers</h4>
                               <p>PEC is an option that insures against risk of loss or damage to help protect your personal belongings
                                   while renting from Hertz. By electing PEC, you will be insured throughout the entire rental period. PEC
                                   is insurance protection and pays in addition to any other policy you may have (such as a
                                   Homeowner's policy). However, your benefits provided by other coverage may be affected by the PEC
                                   benefit. PEC insurance coverage includes those personal effects owned by you and those members
                                   of your immediate family traveling with you during the rental period who are permanent residents of
                                   your household. PEC does not extend to non-family members traveling with you.</p>
                               <p>Insurance that insures personal possessions for an additional daily charge. Only one like coverage per rental.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>Coverage Limits</h4>
                               <ul>
                                   <li>Up to $600 per person, with the maximum coverage for all claims during any rental limited to $1,800*.</li>
                                   <li>In the event any claims are made under the Policy, coverage for succeeding claims during the same rental will be reduced by the amount of the claim paid.</li>
                               </ul>
                               <p>* Benefits referred to in this synopsis are not applicable for vehicles rented in the State of New York. In New York, the coverage
                                   limits are $500 per person, with the maximum coverage for all claims during any rental limited to $1,500. Rental originating in
                                   the State of Mississippi are not subject to the $1,800 per rental maximum.</p>
                               <h4>Exclusions</h4>
                               <p>Personal effects not covered for loss or damage include:</p>
                               <ul>
                                   <li>Automobiles and their equipment, motorcycles, boats, motors or other conveyances or their appurtenances;</li>
                                   <li>Household furniture, currency, coins, stamps, deeds, securities, bullion, tickets, or documents;</li>
                                   <li>CB radios, radar detectors, GPS equipment, guns, merchandise for sale or fine art;</li>
                                   <li>Contact lenses, artificial teeth and limbs;</li>
                                   <li>Perishables or animals.</li>
                               </ul>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>PEC does not cover loss by mysterious disappearance, nor does it cover:</h4>
                               <ul>
                                   <li>Loss or damage caused by wear and tear, gradual deterioration, moths, vermin, inherent vice or
                                       damage sustained due to any process or while actually being worked upon and resulting therefrom, or
                                       while in the care, custody or control of any common carrier.</li>
                                   <li>Loss caused by war or any act of war;</li>
                                   <li>Transporting contraband or illegal trade;</li>
                                   <li>Loss by nuclear reaction, radiation or radioactive contamination;</li>
                                   <li>Loss or damage due to theft unless reported to Police.</li>
                               </ul>
                               <p><strong>All losses by theft must be reported to appropriate law enforcement authorities or they will not
                                           be covered. Coverage is excluded if the renter is in violation of the Rental Agreement.</strong></p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>How to File a PEC Claim</h4>
                               <p>You may <a href="https://images.hertz.com/pdfs/0217_PEC.pdf" target="_blank">download the PEC Claim Form here</a> or obtain a copy from any Hertz rental counter and
                                   submit it with a copy of the Rental Agreement to: Hertz Claim Management Corporation P.O. Box 716
                                   Park Ridge, NJ 07656.</p>
                               <p><strong>Claims must be submitted to the above address within thirty (30)*** days of the date of loss.</strong></p>
                               <p>PAI and PEC coverage underwritten by ACE American Insurance Company with principal place of business in Philadelphia, PA .</p>
                               <ul>
                                   <li>This information is only a brief summary of LIS, PAI and PEC coverages. These coverages may
                                       provide a duplication of coverage provided by your personal insurance or other source of
                                       coverage. Neither Hertz nor the counter representatives are qualified or authorized to evaluate
                                       the adequacy of your existing insurance coverage. The specific terms and conditions are
                                       subject to all the provisions, limitations and exclusions contained in the LIS policy issued by
                                       ACE American Insurance Company through Willis of New Jersey, Inc., Insurance Brokers or, as
                                       applicable, the PAI/PEC policy issued by Ace American Insurance Company If you purchase
                                       any of the Optional Insurance Plans available, upon request a copy of the Policy will be
                                       available for review for further costs and details.</li>
                                   <li>CA Rental License No. 0D25322</li>
                                   <li>CA Department of Insurance Consumer Hotline: (800) 927-4357</li>
                                   <li>OH Rental Car Agent License No. 27202</li>
                               </ul>
                           </div>
                       </div>
                   </div>
                   <h2><a data-toggle="#tab4" class="tabLink">Personal Coverage <i class="fa fa-angle-right fa-pull-right"></i></a></h2>
                   <div id="tab4" class="sliding-tabs">
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>Credit Card Coverage</h4>
                               <p>If you have an accident with a Hertz car and you've declined the Hertz Optional Protection Plans because you thought your credit card insurance covered you, consider these facts:</p>
                               <ul>
                                   <li>You must pay for your rental using the card providing coverage or the coverage will not apply.</li>
                                   <li>Most cards only reimburse you for your deductible after your own insurance pays.</li>
                                   <li>Some cards don't pay unless you submit documented, "paid by you first" repair bills within a specified time.</li>
                                   <li>Some don't cover rentals that last longer than a certain period.</li>
                                   <li>Some don't cover certain car types or classes, e.g. large Sport Utility Vehicles or certain luxury cars.</li>
                                   <li>Some only cover you if you purchase separate, additional, one-time rental car coverage before each rental or enroll in advance and pay an additional fee for each rental.</li>
                                   <li>Some don't cover rentals on cards issued outside the USA.</li>
                                   <li>Credit card rental car coverage is for damage to the car, not for liability claims against you by people injured in an accident.</li>
                               </ul>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>Personal Automobile Insurance Coverage</h4>
                               <p>And if you think your own car insurance covers you for damage to the Hertz car, consider these facts:</p>
                               <ul>
                                   <li>Insurance coverage varies depending on the state in which it is issued.</li>
                                   <li>Insurance coverage can also vary from insurer to insurer.</li>
                                   <li>Your coverage may be limited to the value of the car you own, not the one you're renting, or the limits of your property damage coverage.</li>
                                   <li>Some policies don't cover rental cars, or cover them only when your car is being repaired.</li>
                                   <li>If your insurance doesn't pay Hertz in full, you're still responsible for the remainder.</li>
                                   <li>Your insurance premium could be raised because of this claim.</li>
                                   <li>Your insurance could be cancelled if that claim makes you too high of a risk.</li>
                               </ul>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>Will My Own Insurance Cover Damage to the Rental Car?</h4>
                               <p>The answer to this question depends on your insurance policy and what state you live. If you're not
                                   covered for rental car protection, you may have to pay a deductible and experience changes with your
                                   policy if an accident occurs. Hertz recommends speaking to your insurance agent about your own
                                   coverage. Your agent can provide a better understanding of your own coverage and whether you will
                                   benefit from any of our coverage options.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>What Should You Do?</h4>
                               <p>If you've carefully checked with your own insurance agent or insurer and the charge card company
                                   you use to rent and are fully satisfied with the coverage they provide, you may choose to decline the
                                   Hertz Optional Protection Plans. But if you are not sure about your coverage, or if you have
                                   determined you are not adequately covered, accepting the Hertz Optional Protection Plan that suits
                                   your needs may be a good choice for you.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>Options Available to You*</h4>
                               <p>Hertz offers optional services individually and in a variety of protection packages which contain useful
                                   combinations of the optional services. When describing these services, we've tried to eliminate the
                                   confusing legal terms in order to give you a clearer understanding of the options available to you and
                                   to help you determine which, if any, you may need.</p>
                               <p>*These Optional Services are available for an additional daily charge for each full or partial rental day
                               for each Optional Service selected.</p>
                           </div>
                       </div>
                       <div class="rn-faq-item">
                           <div class="rn-faq-icon">
                               <i class="fas fa-question"></i>
                           </div>
                           <div class="rn-faq-content">
                               <h4>How Do I Accept These Options?</h4>
                               <p>If you've carefully checked with your own insurance agent or insurer and the charge card company
                                   you use to rent and are fully satisfied with the coverage they provide, you may choose to decline the
                                   Hertz Optional Protection Plans. But if you are not sure about your coverage, or if you have
                                   determined you are not adequately covered, accepting the Hertz Optional Protection Plan that suits
                                   your needs may be a good choice for you.</p>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   </section>