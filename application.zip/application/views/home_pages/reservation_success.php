<form id="reservar" name="reservar">
    <?php
    foreach ($approved_list as $approved_lists): ?>
<?php
if($approved_lists->responsepasarella == 'APPROVED' OR $approved_lists->responsepasarella == 'APPROVAL'){
			if($approved_lists->vendor == 'ZT' AND $approved_lists->numerotour == 1){
				$numerotour= '';
			}
			elseif($approved_lists->vendor === 'ZR' AND $approved_lists->numerotour == 1){
				$numerotour= 'IT1002785LTY';
			}
			elseif($approved_lists->vendor === '' AND $approved_lists->numerotour == 1){
				$numerotour= 'ITULCARS';
			}
			if($approved_lists->vendor == 'ZT' AND $approved_lists->numerotour == 2){
				$numerotour= '';
			}
			elseif($approved_lists->vendor === 'ZR' AND $approved_lists->numerotour == 2){
				$numerotour= 'IT1002785LTY';
			}
			elseif($approved_lists->vendor === '' AND $approved_lists->numerotour == 2){
				$numerotour= 'ITUICARS';
			}
			if($approved_lists->vendor == 'ZT' AND $approved_lists->numerotour == 3){
				$numerotour= '';
			}
			elseif($approved_lists->vendor === 'ZR' AND $approved_lists->numerotour == 3){
				$numerotour= 'IT1002785LTY';
			}
			elseif($approved_lists->vendor === '' AND $approved_lists->numerotour == 3){
				$numerotour='ITUFCARS';
			}
                        if($approved_lists->vendor == 'ZT' AND $approved_lists->numerotour == 4){
				$numerotour= '';
			}
			elseif($approved_lists->vendor === 'ZR' AND $approved_lists->numerotour == 4){
				$numerotour= 'IT1002785LTY';
			}
			elseif($approved_lists->vendor === '' AND $approved_lists->numerotour == 4){
				$numerotour='ITUFCARS';
			}
                        if($approved_lists->vendor == 'ZT' AND $approved_lists->numerotour == 5){
				$numerotour= '';
			}
			elseif($approved_lists->vendor === 'ZR' AND $approved_lists->numerotour == 5){
				$numerotour= 'IT1002785LTY';
			}
			elseif($approved_lists->vendor === '' AND $approved_lists->numerotour == 5){
				$numerotour='ITUFCARS';
			}
                        if($approved_lists->vendor == 'ZT' AND $approved_lists->numerotour == 6){
				$numerotour= '';
			}
			elseif($approved_lists->vendor === 'ZR' AND $approved_lists->numerotour == 6){
				$numerotour= 'IT1002785LTY';
			}
			elseif($approved_lists->vendor === '' AND $approved_lists->numerotour == 6){
				$numerotour='ITUFCARS';
			}
		?>

        <input type="hidden" name="formulario" value="OTA_VehResRQCore" />
        <input type="hidden" name="compania" value="<?php echo $approved_lists->vendor;?>" />
        <input type="hidden" name="recogida[lugar]" value="<?php echo $plocatio[0];?>" />
        <input type="hidden" name="recogida[fecha]" value="<?php echo $plocatio[1];?>" />
        <input type="hidden" name="recogida[hora]" value="<?php echo $plocatio[2];?>" />
        <input type="hidden" name="devolucion[lugar]" value="<?php echo $droplocatio[0];?>" />
        <input type="hidden" name="devolucion[fecha]" value="<?php echo $droplocatio[1];?>" />
        <input type="hidden" name="devolucion[hora]" value="<?php echo $droplocatio[2];?>" />
        <input type="hidden" name="nombre" value="<?php echo $approved_lists->nombre;?>" />
        <input type="hidden" name="apellido" value="<?php echo $approved_lists->apellido;?>" />
        <input type="hidden" name="telefono" value="<?php echo $approved_lists->phone1;?>" />
        <input type="hidden" name="correo" value="<?php echo $approved_lists->correo;?>" />
        <input type="hidden" name="numerotour" value="<?php echo $numerotour ?>" />
        <input type="hidden" name="voucher" value="cars2go<?php echo $approved_lists->id;?>" />
        <input type="hidden" name="referencia" value="<?php echo $approved_lists->referencia;?>" />
       
</form>
<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<script>
    var dataform = $('#reservar').serializeArray();
    $.ajax({
            data: dataform,
            dataType:'json',
            type:'post',
            url:'<?= base_url('paymentresult/getreservation')?>',
            error:function(){
                    console.log(arguments);
            },
            success:function(response){
                window.location = '<?= base_url('/paymentsuccess?rf=') ?><?php echo base64_encode($approved_lists->referencia);?>&rid='+btoa(response.datos.VehResRSCore.VehReservation.VehSegmentCore.ConfID['@attributes'].ID)+'&id=<?php echo $approved_lists->id;?>';
            }
    });
    
</script>
<?php } else { ?>
 <script>
    window.location = '<?= base_url('paymentresult/cancelpayment?rf=') ?><?php echo base64_encode($approved_lists->referencia);?>&rid='+btoa(0)+'&id=<?php echo $approved_lists->id;?>';
</script>
<?php } endforeach; ?>