<div class="rn-carousel carousel slide" id="carouselExampleControls" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item beactive">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">#1 Car Rent Service<br> In Your City</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
<img class="d-block w-100" src="<?php base_url() ?>assets/images/slide1.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">Quality Cars with<br> Unlimited Miles</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
<img class="d-block w-100" src="<?php base_url() ?>assets/images/slide2.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">24/7 Customer<br> Support</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
                 <a class="btn btn-main btn-lg rn-fade-bottom rn-caption-item-3" href="#">Book Now</a> 
            </div>-->
            <!-- <div class="rn-slider-overlayer"></div> -->
            <img class="d-block w-100" src="<?php base_url() ?>assets/images/slide3.jpg" alt="slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="lnr lnr-chevron-left" aria-hidden="true"></span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="lnr lnr-chevron-right" aria-hidden="true"></span>
    </a>
    <div class="rn-small-search-form">
        <div class="rn-small-search-form-title">
            <h2>Book Now</h2>
        </div>
            <?php echo form_open('carslists','class="padding6Form" autocomplete="off"'); ?>
        <?php if(!$this->session->userdata('logged_in')){ ?>
        <div class="rn-icon-input row">
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                <?php }else{ ?>
            <div class="rn-icon-input row" style="display: none">
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                 <?php } ?>
            <div class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input name="formulario" type="hidden" value="OTA_VehAvailRQCore"/>
                <input type="text" id="rec" name="selectpickup" placeholder="Pickup Location" required="required">
                <?php echo form_error('selectpickup') ?>
                <div id="selectpickupShow"></div>
                <input id="recogida" type="hidden" name="recogida[lugar]" />
                <input id="recogida_vendor" type="hidden" name="recogidavendor" />
            </div>
            <div class="col-md-12 text-white p-0" id="returnInAnother">
                <input type="checkbox" id="drop-select">
                <label for="drop-select" value="1" id="checkreturnLotation">I want to return my car in other location </label>
            </div>
            <div id="drop-location" class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input type="text" name="selectpickupdrop" id="dev" placeholder="Drop Location" required="required">
                <div id="selectDevShow"></div>
                 <input id="devolucion" type="hidden" name="devolucion[lugar]" />
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="recogida[fecha]" placeholder="Pickup Date" readonly id="pickup-date" class="flatpickr-input datepicker pickupdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>
                            <input type="text" name="recogida[hora]" placeholder="Time" id="pickup-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="recogidaHora" name="recogida[hora]" id="pickup-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                         
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="devolucion[fecha]" placeholder="Drop Date" readonly id="drop-date" class="flatpickr-input dropdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>-->
    <!--                        <input type="text" name="devolucion[hora]" placeholder="Time" id="drop-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="devolucionHora" name="devolucion[hora]" id="drop-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="countryrecogida" id="countryrecogida">
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-md-6 p-0">
                        <div class="rn-icon-input">
                            <select class="flatpickr-input bg-white" id="ageSelector" name="ageSelector" required="required">
                                <option value="">Select Age</option>
                                <option value="30-69">30-69</option>
                                <option value="29">29</option>
                                <option value="28">28</option>
                                <option value="27">27</option>
                                <option value="26">26</option>
                                <option value="25">25</option>
                                <option value="24">24</option>
                                <option value="23">23</option>
                                <option value="22">22</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 p-0">
                        <select class="flatpickr-input bg-white" name="preferencias[0][vehiculo][categoria]" class="form-control cursorPointer" id="preferenciasVehicleType" required="required">
                            <option value="">Vehicle Type</option>
                            <option value="">no-preference</option>
                            <option value="1">car-economy</option>
                            <option value="2">car-compact</option>
                            <option value="3">car-intermediate</option>
                            <option value="4">car-standard</option>
                            <option value="5">car-fullsize</option>
                            <option value="6">suv-intermediate</option>
                            <option value="7">van-mini</option>
                            <option value="8">convertible-standard</option>
                            <option value="9">suv-standard</option>
                            <option value="10">van-fullsize</option>
                            <option value="11">car-premium</option>
                            <option value="12">car-luxury</option>
                            <option value="13">suv-fullsize</option>
                        </select>
                    </div>
                </div>
            </div>
            <button id="continue" class="btn btn-main btn-lg btn-shadow btn-block" type="submit">
            <i class="fas fa-search"></i> Check Now</button>
            <button id="popup" type="button" data-toggle="modal" data-target="#login" class="btn btn-main btn-lg btn-shadow btn-block m-0 hidden">
            <i class="fas fa-search"></i> Check Now</button>
        <?php echo form_close(); ?>
    </div> 
</div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <div class="rn-section-title mb-4 left-contant">
                        <h6 class="rn-title">Car rental in Miami: everything you need to know</h6>
                        <p>A car rental in Miami gives you the opportunity to go wherever you want, whenever you want. You can explore all the sights and even discover what else the rest of Florida can offer. We have answered your most popular questions about car rental in Miami. Find out what to do and what not to do when booking a rental car.</p>
                        <br>
                        <h6 class="rn-title">How do I get a great deal on a rental car in Miami?</h6>
                        <p>We always strive to get the best rate. However, there are ways to get an even cheaper price on your next rental. Make sure that:</p>
                    <p>Compare the rates of some suppliers on the type of car you want</p>
                    <p>Book as early as possible. Usually, you will save more and get the car you choose</p>
                    <p>See fuel and mileage policies. You don't want to be surprised with additional costs</p>
                    <p>Do not get more vehicle than you need. Commonly, the smaller the class, the lower the rate</p>
                    <p>Just following some of these tips can help you save on your rental car in Miami.</p>
                    <br>
                      <h6 class="rn-title">What rental companies have agencies in Miami?</h6>
                      <p> There are about 60 car rental providers from which you can choose. We have economic names like Dollar and Thrifty and global names like Avis and SIXT. Look at the reviews to get an idea of   which ones meet your needs.</p>
                       <br>
                      <h6 class="rn-title">What types and brands of rental cars are offered in Miami?</h6>
                      <p>That depends on how many people travel with you and what activities you want to do in Miami. If you have trouble choosing, be sure to check the chart below. We have compared the most popular car categories for you</p>
                           <br>
                      <h6 class="rn-title">How old must you be to rent a car in Miami?</h6>
                      <p>In general, the age limit for car rental in Miami is 21. But, there may be an additional fee if you are under 25 years of age or for rentals of major or major category. Review the terms to determine the exact rate before booking your car.</p>
                      <br>
                      <h6 class="rn-title">Do I need vehicle insurance to rent a car in Miami?</h6>
                      <p>Most countries require driving insurance. You may be able to purchase provisional coverage through the car rental provider. Otherwise, as a citizen of the United States, you can also add collision damage coverage through CarRentals.com at the end of the purchase. Several credit cards will provide some coverage. However, many of them have restrictions, such as not covering larger cars such as trucks or SUVs. It is better to find out exactly what your credit card will cover and how much before traveling to Miami.</p>
                      <br>
                       <h6 class="rn-title">What are the different fuel policies?</h6>
                       <p>Most providers allow you to choose the policy you want. Below is a list of the most common.</p>

                        <br>
                       <h6 class="rn-title">What type of fuel policy should I choose?</h6>
                       <p>Many suppliers offer a variety of fuel policies. However, the outstanding winner is usually complete. It simply means returning the car with the same level of gasoline with which it was obtained, so you will never pay for anybody else's road trips through Miami.</p>
                       <br>
                       <h6 class="rn-title">Do I have to get unlimited miles when renting a car in Miami?</h6>
                       <p>If you want to see everything Miami offers and maybe even the rest of Florida, you will need unlimited miles. You won't have to worry about additional charges if you decide to drive all over Miami. Check out the fine print to make sure your mileage is really "unlimited".</p>
                        <br>
                       <h6 class="rn-title">Why is Miami famous?</h6>
                       <p>There are tons to see and do in this city. Miami has about 14 attractions it is known for. Some of the most popular are:</p>
                        <p>Miami Beach</p>
                        <p>Little Havana</p>
                        <p>Museum of Contemporary Art, North Miami</p>
                        <p>Fairchild Tropical Botanical Garden</p>
                        <p>Luckily for you, you can drive to the one you want or visit them all.</p>
                       <br>
                       <h6 class="rn-title">Know before you go</h6>
                       <p>Before starting your trip to Miami, review some things before leaving the rental lot. You should:</p>
                       <p>Look over the car and make sure there are no damages or scratches. If so, write it down in the documentation</p>
                       <p>Have a spare tire, a wrench and a jack in the trunk properly inflated</p>
                       <p>Become familiar with the controls of your car. Adjust the mirrors and seats, and observe how to turn on the lights and windshield wipers.</p>
                       <p>Get comfortable working in navigation and entertainment. You don't want unnecessary distractions in a new city</p>
                       <br>
                       <h6 class="rn-title">Reserve your rental car in Miami today</h6>
                       <p>Maybe you are traveling alone, maybe you bring your partner or children, or maybe you are sharing trips with coworkers to and from the hotel to the conference center. No matter the situation, Cars2GoRentals.com has a vehicle that can meet your requirements and not break the bank.</p>
                       <br>
                       <h6 class="rn-title">Some popular Queries for Car Rental in Miami</h6>
                       <ul>
                            <li>Miami minivan car rental airport</li>
                            <li>minivan rental Miami international airport</li>
                            <li> minivan rental Miami Florida</li>
                            <li> cheap minivan rental Miami</li>
                            <li> Miami car rental deals</li>
                            <li> best car rental Miami airport</li>
                            <li> budget car rental Miami cruise port</li>
                            <li> budget car rental Miami beach</li>
                            <li> budget car rental Miami international mall</li>
                            <li> cheap car rental Miami Florida airport</li>
                            <li> cheap car rental Miami beach</li>
                            <li> cheap car rental Miami south beach</li>
                            <li> cheap car rental Miami port</li>
                            <li>car rental Miami lakes</li>
                             <li>budget car rental Miami lakes</li>
                            <li>budget car rental Miami locations</li>
                            <li>budget car rental Miami downtown</li>
                            <li>Miami cheap luxury car rental</li>
                            <li>best exotic car rental Miami</li>
                       </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<script type="text/javascript"> 
$(document).ready(function(){  
        $("#login").on('click','#submit',function(){  
        var userid = $('#usuario').val();
        var password = $('#pass').val(); 
        
        // Returns error message when submitted without req fields.  
        if(userid==''||password=='')  
        {  
        jQuery("div#err_msg").show();  
        jQuery("div#msg").html("All fields are required");  
        }  
        else  
        {  
        // AJAX Code To Submit Form.  
        $.ajax({  
        type: "POST",  
        url:  '<?= base_url('user_auth/ajax_login'); ?>',
        data: {email: userid, pass: password},  
        cache: false,  
        success: function(result){  
            if(result!=0){  
                // On success redirect.  
            window.location.replace('<?= base_url('home') ?>');  
            }  
            else  
                jQuery("div#err_msg").show();  
                jQuery("div#msg").html("Login Failed");  
        }  
        });  
        }  
        return false;  
        });  
        });  
</script>