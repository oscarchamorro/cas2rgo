<p>Payment is in processing please wait don't click back and refresh button</p>
<form action="https://www.myvirtualmerchant.com/VirtualMerchant/process.do" name="merchant" method="GET" id="frm1">
	<input type="hidden" name="ssl_amount" value="<?php echo $amount;?>" />
	<input type="hidden" name="ssl_merchant_id" value="950246" />
	<input type="hidden" name="ssl_user_id" value="web1">
<!--        <input type="hidden" name="referencia" value="<?//php echo $referencia?>">-->
	<input type="hidden" name="ssl_pin" value="B4381AC5BIV463E10N8275IGFJIHFE7EXM60CJKJ6VHAK6PR0TDB02BROLPGPJJ9" />
	<input type="hidden" name="ssl_transaction_type" value="ccsale" />
	<input type="hidden" name="ssl_show_form" value="true" />
	<input type="hidden" name="ssl_cvv2cvc2_indicator" value="1" /> 
	<input type="hidden" name="ssl_email" value="<?php echo $mail?>" />
        <?php foreach ($mantenimiento as $rowresultmantenimientopagos): ?>
        <?php if($rowresultmantenimientopagos->estado==0){ ?>
        <input type="hidden" name="ssl_test_mode" value="false">
        <?php }else{ ?>
        <input type="hidden" name="ssl_test_mode" value="true">
        <?php } ?>
        <?php endforeach; ?>
	<input type="hidden" name="ssl_result_format" value="HTML" />
	<input type="hidden" name="ssl_receipt_decl_method" value="REDG" />
	<input type="hidden" name="ssl_receipt_decl_get_url" value="<?php echo base_url('paymentresult'); ?>" />
	<input type="hidden" name="ssl_receipt_apprvl_method" value="REDG" />
	<input type="hidden" name="ssl_receipt_apprvl_get_url" value="<?php echo base_url('paymentresult'); ?>" />
</form>
<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<script>
$(document).ready(function(){
	 $("#frm1").submit();
});
</script>
