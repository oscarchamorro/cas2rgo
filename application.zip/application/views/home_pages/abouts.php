<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>About Us</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-section-title mb-4">
                        <h2 class="rn-title">Our Vision</h2>
                        <span class="rn-title-bg">Our Vision</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <!--<h2 class="rn-image-section-title">
                        <span>Make Beauty Things</span> With Passion
                    </h2>-->
                    <p>Cars2Go, general sales agent of Hertz International, Dollar and Thrifty, has been operating for more than 10 years with a large structure focused mainly on serving the market of Tourism Agencies, Operators and Consumers. We specialize in clients traveling to the United States, Canada and Europe. Through this site, you will find a wide variety of cars and rates to facilitate your quotes, reservations and Issue vouchers. We know that making the booking process easy, offering the lowest prices and providing the best service, make our customers happy.</p>
                </div>
                <div class="col-md-12 text-center mb-30">
                    <img class="img-fluid" src="assets/images/about.png" alt="">
                </div>
            </div>
        </div>
    </section>