<script src="<?= base_url('assets/js/jquery-3.3.1.js'); ?>"></script>
<?php 
echo $html_form;



?>
<script type="text/javascript">
$(document).ready(function(){
	 $("#authorize_payment_form").submit();
});
</script>
               </script>