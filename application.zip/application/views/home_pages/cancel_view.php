 <form>
    <input name="formulario" type="hidden" value="OTA_VehCancelRQCore"/>
    <input type="hidden" name="numeroreserva" value="<?php echo $numeroreserva ?>">
    <input type="hidden" name="apellido" value="<?php echo $apellido ?>">
</form>
