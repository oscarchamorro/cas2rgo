<section class="rn-section pt-35">
    <div class="container"> 
        <?php foreach ($invoiceshow as $invoiceshows): ?>
        
        <div class="row p-3 pt-4 pb-4">
            <div class="col-md-8 p-0 mb-4 position-center">
                <a href="<?= base_url('home') ?>" class="btn btn-warning btn-flat pull-right ml-4"><span>&#171;</span> Home</a>
                <button type="button" id="printButton" class="btn btn-warning btn-flat pull-right"><i class="fa fa-print"></i> Invoice Print</button>
            </div>
            <div class="col-md-8 invoice-details">
                <div id="printElement">
                    <h3 class="invoice-title m-3"><img src="<?= base_url('assets/images/logo.png')?>" class="img-fluid mb-3" width="100"/><br>FINAL INVOICE GENERATED</h3>
                    <div class="col-md-12 row m-0 invoice-img pull-left">
                        <div class="col-md-3">
                            <img src="https://images.hertz.com/vehicles/220x128/<?php echo $invoiceshows->vehicle;?>" />
                        </div>
                        <div class="col-3">
                            <?php
                                if($invoiceshows->vendor == 'ZR'){
                                    echo '<img src="img/dollarico.png" class="marginTop3" alt="dollar rent a cars">';
                                }elseif($invoiceshows->vendor == 'ZT'){
                                    echo '<img src="img/thriftyicono.png" class="marginTop3" alt="thrifty rent a cars">';
                                }elseif($invoiceshows->vendor == 'ZE'){
                                    echo '<img src="img/hertzico.png" class="marginTop3" alt="hertz rent a cars">';
                                }
                            ?>
                        </div>
                        <div class="col-md-6">
                            <p><i> Your payment was approved. Your reservation number is</i></p>
                            <h3><label class="invoice-number"><?php echo $invoiceshows->reservaid;?></label></h3>
                        </div>
                    </div>
                    <div class="col-md-12 pull-left">
                        <h5 class="mb-4 mt-3 col-md-12">
                            <i>Thanks for booking with cars2gorentals. Please check your email with the confirmation number.</i>
                        </h5>
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th><label for="emaila">Pickup Location</label></th>
                                <td><?php echo $pickuplocation ;?></td>
                            </tr>
                            <tr>
                                <th><label for="emaila">Pickup Time</label></th>
                                <td><?php echo $pktimedate ;?></td>
                            </tr>
                            <tr>
                                <th><label for="verifyemail">Return Location</label></th>
                                <td><?php echo $droplocation;?></td>
                            </tr>
                            <tr>
                                <th><label for="verifyemail">Return Time</label></th>
                                <td><?php echo $drptimedate;?></td>
                            </tr>
                            <tr>
                                <th><label for="emaila">Names</label></th>
                                <td><?php echo ucwords($invoiceshows->nombre.' '.$invoiceshows->apellido);?></td>
                            </tr>
                            <tr>
                                <th><label for="verifyemail">Amount</label></th>
                                <td><?php echo $invoiceshows->amount.' '.$invoiceshows->currencycode;?></td>
                            </tr>
                            <tr>
                                <th><label for="verifyemail">Vehicle</label></th>
                                <td><?php echo ucwords(strtolower($invoiceshows->model));?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-12 mt-2 pull-left">
                        <h4>Note:</h4>
                        <ul>
                            <li>Changes to a reservation must be done at Hertz.com using the "Modify/Cancel" option.</li>
                            <li>Any changes to the reservation may impact the rental charges.</li>
                            <li>prepaid reservation, this reservation can cancel to the 24 hours before the pickup time.</li>
                        </ul> 
                    </div>
                </div>
                
                <div class="clearfix mb-4"></div>
                <h4 class="invoice-title col-md-12 mb-0 position-center"><i> This rate is non-refundable. <a href="<?= base_url('termsandconditions') ?>" target="_blank">Check our return policies here</a></i></h4>
           </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>