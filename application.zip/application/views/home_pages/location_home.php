<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>Locations</h1>
                        <p>Hertz Ultimate Choice</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-section-title   ">
                        <h2 class="rn-title">Our Top Locations</h2>
                        <p>Available Nationwide At the Following Locations</p>
                        <span class="rn-title-bg">Our Top Locations</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Atlanta</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Austin</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Boston</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Charlotte</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Chicago O’Hare</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Cleveland</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Dallas/Fort Worth</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Denver</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Detroit</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Fort Lauderdale</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Houston Hobby</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Houston Intcntl</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Kansas City</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Las Vegas</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Los Angeles</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Miami</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Minneapolis-St. Paul</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Nashville</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Newark</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Philadelphia</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Phoenix</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Portland</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Raleigh-Durham</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">San Diego</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">San Francisco</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">San Jose</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Seattle-Tacoma</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">St. Louis</div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="rn-service-item">
                        <i class="lnr lnr-map-marker"></i>
                        <div class="rn-service-title">Washington Reagan</div>
                    </div>
                </div>
            </div>
        </div>
    </section>