<section class="rn-section pt-35">
    <div class="container">
        <?php foreach ($invoiceshow as $invoiceshows): ?>
            <div class="col-md-12 mb-5">
                <h4 class="text-center mb-4">
                    <span class="text-danger"><i class="fa fa-warning fa-lg"></i> <?php echo $invoiceshows->responsepasarella ?></span><br />
                    Please check your Payment Details. 
                </h4>
            </div>
            <div class="row p-3 pt-4 pb-4 border border-semi-light">
                <div class="col-md-3 d-flex text-center">
                    <div class="col-md-6">
                        <img src="https://images.hertz.com/vehicles/220x128/<?php echo $invoiceshows->vehicle;?>" />
                    </div>
                    <div class="col-md-6">
                        <?php
                            if($invoiceshows->vendor == 'ZR'){
                                echo '<img src="img/dollarico.png" class="marginTop3" alt="dollar rent a cars">';
                            }elseif($invoiceshows->vendor == 'ZT'){
                                echo '<img src="img/thriftyicono.png" class="marginTop3" alt="thrifty rent a cars">';
                            }elseif($invoiceshows->vendor == 'ZE'){
                                echo '<img src="img/hertzico.png" class="marginTop3" alt="hertz rent a cars">';
                            }
                        ?>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="col-md-12 pull-left">
                        <div class="col-md-3 pull-left">
                            <label for="emaila">Pickup </label>
                            <span class="pull-right">:</span>
                        </div>	
                        <div class="col-md-6 pull-left">
                            <?php echo $pickuplocation ;?>
                        </div>
                    </div>
                    <div class="col-md-12 pull-left">
                        <div class="col-md-3 pull-left">
                            <label for="verifyemail">Return </label>
                            <span class="pull-right">:</span>
                        </div>
                        <div class="col-md-6 pull-left">
                            <?php echo $droplocation;?>
                        </div>
                    </div>
                    <div class="col-md-12 pull-left">
                        <div class="col-md-3 pull-left">
                            <label for="emaila">Names</label>
                            <span class="pull-right">:</span>
                        </div>
                        <div class="col-md-6 pull-left">
                            <?php echo ucwords($invoiceshows->nombre.' '.$invoiceshows->apellido);?>
                        </div>
                    </div>
                    <div class="col-md-12 pull-left">
                        <div class="col-md-3 pull-left">
                            <label for="verifyemail">Amount</label>
                            <span class="pull-right">:</span>
                        </div>
                        <div class="col-md-6 pull-left">
                            <?php echo $invoiceshows->amount.' '.$invoiceshows->currencycode;?>
                        </div>	
                    </div>
                    <div class="col-md-12 pull-left">
                        <div class="col-md-3 pull-left">
                            <label for="verifyemail">Vehicle</label>
                            <span class="pull-right">:</span>
                        </div>
                        <div class="col-md-6 pull-left">
                            <?php echo ucwords(strtolower($invoiceshows->model));?>
                        </div>
                    </div>
                </div>
                <div class="col-md-1">
                    <span class="cancel-watermark"></span>
                </div>
           </div>
            
        <?php endforeach; ?>
    </div>
</section>