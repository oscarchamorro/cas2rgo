<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>Contact</h1>
                        <!--<p>Cras eros lorem, rhoncus ac risus sit amet, fringilla ultrices purus.</p>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php if($this->session->flashdata('save_message')){ ?>
        <script>
            Swal.fire('<?php echo $this->session->flashdata('save_message'); ?>')
        </script>
<?php  } ?>
<section class="rn-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h2 class="rn-simple-title">Send Message</h2>
                <div class="rn-contact-form">
                   <?php echo form_open() ?>
                        <div class="row mb-30">
                            <div class="col-12 mb-30">
                                <div class="rn-icon-input">
                                    <i class="far fa-user"></i>
                                    <input type="text" name="names" placeholder="Full name" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="rn-icon-input">
                                    <i class="far fa-envelope"></i>
                                    <input type="text" name="email" placeholder="Your Email" required>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="rn-icon-input">
                                    <i class="far fa-envelope"></i>
                                    <input type="text" name="phone" placeholder="Your Phone" required>
                                </div>
                            </div>
                        </div>
                        <div class="rn-icon-input rn-icon-top mb-30">
                            <i class="far fa-comment"></i>
                            <textarea placeholder="Your Message" name="comments" rows="5" required></textarea>
                        </div>
                        <div class="text-right">
                            <input class="btn btn-main btn-lg btn-block btn-shadow" type="submit" value="Send Message">
                        </div>
                   <?php form_close() ?>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-12">
                        <h2 class="rn-simple-title">Customer Service</h2>
                    </div>
                    <div class="col-sm-6">
                        <div class="rn-contact-info">
                            <div class="rn-info-icon">
                                <i class="lnr lnr-envelope"></i>
                            </div>
                            <div class="rn-info-content">
                                <h2 class="rn-contact-title">By E-mail</h2>
                                <address>info@cars2gorentals.com</address>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>