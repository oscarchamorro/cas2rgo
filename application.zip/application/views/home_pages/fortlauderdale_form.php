<div class="rn-carousel carousel slide" id="carouselExampleControls" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item beactive">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">#1 Car Rent Service<br> In Your City</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
<img class="d-block w-100" src="<?php base_url() ?>assets/images/slide1.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">Quality Cars with<br> Unlimited Miles</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
            </div>-->
<img class="d-block w-100" src="<?php base_url() ?>assets/images/slide2.jpg" alt="slide">
        </div>
        <div class="carousel-item">
<!--            <div class="carousel-caption text-left">
                <h2 class="rn-fade-bottom mb-25">24/7 Customer<br> Support</h2>
                <p class="rn-fade-bottom rn-caption-item-2 mb-35 fa-pull-left">Maecenas viverra porta eros, id tincidunt lorem rhoncus eget. Aliquam erat volutpat. Sed ultricies elementum egestas.</p>
                 <a class="btn btn-main btn-lg rn-fade-bottom rn-caption-item-3" href="#">Book Now</a> 
            </div>-->
            <!-- <div class="rn-slider-overlayer"></div> -->
            <img class="d-block w-100" src="<?php base_url() ?>assets/images/slide3.jpg" alt="slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="lnr lnr-chevron-left" aria-hidden="true"></span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="lnr lnr-chevron-right" aria-hidden="true"></span>
    </a>
    <div class="rn-small-search-form">
        <div class="rn-small-search-form-title">
            <h2>Book Now</h2>
        </div>
            <?php echo form_open('carslists','class="padding6Form" autocomplete="off"'); ?>
        <?php if(!$this->session->userdata('logged_in')){ ?>
        <div class="rn-icon-input row">
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                <?php }else{ ?>
            <div class="rn-icon-input row" style="display: none">
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-guest" checked="checked">
                    <label for="book-guest" value="1">Book As a Guest </label>
                </div>
                <div class="col-md-6 text-white pull-left">
                    <input type="radio" onclick="bookValidate()" name="book-type" id="book-user">
                    <label for="book-user" value="1">Book As a User </label>
                </div>
            </div>
                 <?php } ?>
            <div class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input name="formulario" type="hidden" value="OTA_VehAvailRQCore"/>
                <input type="text" id="rec" name="selectpickup" placeholder="Pickup Location" required="required">
                <?php echo form_error('selectpickup') ?>
                <div id="selectpickupShow"></div>
                <input id="recogida" type="hidden" name="recogida[lugar]" />
                <input id="recogida_vendor" type="hidden" name="recogidavendor" />
            </div>
            <div class="col-md-12 text-white p-0" id="returnInAnother">
                <input type="checkbox" id="drop-select">
                <label for="drop-select" value="1" id="checkreturnLotation">I want to return my car in other location </label>
            </div>
            <div id="drop-location" class="rn-icon-input">
                <i class="fas fa-map-marker-alt"></i>
                <input type="text" name="selectpickupdrop" id="dev" placeholder="Drop Location" required="required">
                <div id="selectDevShow"></div>
                 <input id="devolucion" type="hidden" name="devolucion[lugar]" />
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="recogida[fecha]" placeholder="Pickup Date" readonly id="pickup-date" class="flatpickr-input datepicker pickupdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>
                            <input type="text" name="recogida[hora]" placeholder="Time" id="pickup-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="recogidaHora" name="recogida[hora]" id="pickup-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                         
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-7">
                        <div class="rn-icon-input">
                            <i class="far fa-calendar-alt"></i>
                            <input type="text" name="devolucion[fecha]" placeholder="Drop Date" readonly id="drop-date" class="flatpickr-input dropdates" required>
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="rn-icon-input">
    <!--                        <i class="far fa-clock"></i>-->
    <!--                        <input type="text" name="devolucion[hora]" placeholder="Time" id="drop-time" class="flatpickr-input" readonly="readonly">-->
                            <select id="devolucionHora" name="devolucion[hora]" id="drop-time" class="flatpickr-input" required="required">
                            <?php
                            echo '<option value="11:00">11:00</option>';
                                for($i=0;$i<24;$i++){
                                    for($j=0;$j<60;$j=$j+30){
                                        if($i<10){$cero='0';}else{$cero='';}
                                        if($j<10){$cero1='0';}else{$cero1='';}
                                        echo '<option value="'.$cero.$i.':'.$cero1.$j.'">'.$cero.$i.':'.$cero1.$j.'</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="countryrecogida" id="countryrecogida">
            <div class="rn-date-time-input">
                <div class="row">
                    <div class="col-md-6 p-0">
                        <div class="rn-icon-input">
                            <select class="flatpickr-input bg-white" id="ageSelector" name="ageSelector" required="required">
                                <option value="">Select Age</option>
                                <option value="30-69">30-69</option>
                                <option value="29">29</option>
                                <option value="28">28</option>
                                <option value="27">27</option>
                                <option value="26">26</option>
                                <option value="25">25</option>
                                <option value="24">24</option>
                                <option value="23">23</option>
                                <option value="22">22</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6 p-0">
                        <select class="flatpickr-input bg-white" name="preferencias[0][vehiculo][categoria]" class="form-control cursorPointer" id="preferenciasVehicleType" required="required">
                            <option value="">Vehicle Type</option>
                            <option value="">no-preference</option>
                            <option value="1">car-economy</option>
                            <option value="2">car-compact</option>
                            <option value="3">car-intermediate</option>
                            <option value="4">car-standard</option>
                            <option value="5">car-fullsize</option>
                            <option value="6">suv-intermediate</option>
                            <option value="7">van-mini</option>
                            <option value="8">convertible-standard</option>
                            <option value="9">suv-standard</option>
                            <option value="10">van-fullsize</option>
                            <option value="11">car-premium</option>
                            <option value="12">car-luxury</option>
                            <option value="13">suv-fullsize</option>
                        </select>
                    </div>
                </div>
            </div>
            <button id="continue" class="btn btn-main btn-lg btn-shadow btn-block" type="submit">
            <i class="fas fa-search"></i> Check Now</button>
            <button id="popup" type="button" data-toggle="modal" data-target="#login" class="btn btn-main btn-lg btn-shadow btn-block m-0 hidden">
            <i class="fas fa-search"></i> Check Now</button>
        <?php echo form_close(); ?>
    </div> 
</div>
    <section class="rn-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-section-title mb-4 left-contant">
                        <h6 class="rn-title">Car rental in Fort Lauderdale: everything you need to know</h6>
                        <p>For sunshine, beautiful beaches, and a touch of magic, head straight to sunny Fort Lauderdale, Florida. If you want to visit some of the best golf courses and museums in the country, as well as thousands of restaurants, you can meander through American Venice with a cheap car rental.</p>
                        <br><h6 class="rn-title">How do I get a cheap car rental in Fort Lauderdale?</h6>
                        <p>You can buy a lot more on a rental car if:</p>

                    <p>Search and compare rates for many suppliers.</p>
                    <p>Do not pick up your car from the airport location, as this may be more expensive.</p>
                    <p>You have an idea of   how much fuel you might need throughout the rental period;</p>
                    <p>Book early!
                    </p> <br>
                      <h6 class="rn-title">What car rental companies are in Fort Lauderdale?</h6>
                      <p> Among the well-known big rental companies, such as SIXT, Hertz and Alamo, and the smallest companies in the area, you'll be spoiled for choice when looking for a rental car in this city.</p>
                       <br>
                      <h6 class="rn-title">What kind of car should I take in Fort Lauderdale, Florida?</h6>
                      <p> With so many types of cars available, you can choose from a selection! But the car that is best for you will depend on what your vacation plans are, as well as the size of your travel party.</p>
                      <p> Do you attend children? Do you have a lot of luggage or camping gear? In these cases, a large SUV or minibus would be perfect for you. If you have a limited budget but do not want to miss all the sights on offer, you can rent a compact and comfortable budget car.</p>
                        <p> How old should I be to rent a car in Fort Lauderdale? </p>
                          <p>The legal age to rent a car is 21 years old, and anyone less than 25 years of age can be required to pay an additional fee for the young driver. </p>
                           <br>
                      <h6 class="rn-title">Do I need insurance to rent a car in Fort Lauderdale, Florida?</h6>
                      <p> Yes. U.S. citizens can get their insurance through CarRentals.com, but it is advisable to check if your car or credit card insurance covers you first.</p>
                      <br>
                      <h6 class="rn-title">What fuel policy is available in Fort Lauderdale?</h6>
                      <p> The standard policy is completely full, which means that you receive your car with a full tank and you will need to return it completely full, too. Check first and don't forget to fill in to avoid facing extra charges. </p>
                      <br>
                       <h6 class="rn-title">Can I reserve unlimited mileage when renting a car in Fort Lauderdale, Florida?</h6>
                       <p> It's easy to reach unlimited miles, which is great for discovering new places without worrying about your use. If you have a limited number of miles, plan your trips carefully to avoid facing the extra mileage costs used.</p>

                        <br>
                       <h6 class="rn-title">Is it possible to rent a one-way car in Fort Lauderdale?</h6>
                       <p>Yes, sometimes for an additional fee. Ask your rental company about their rates and restrictions.</p>
                       <br>
                       <h6 class="rn-title">3 scenes you can't miss in Fort Lauderdale</h6>
                       <p>With your rental car, you will never have to waste time waiting on public transport or paying for an expensive taxi ride. Rent a car in Fort Lauderdale, FL and take a cruise to Discovery and Science Museum to see an exhibition during the day. </p>
                        <p> During your stay, head about 5 miles east of the city center to find calm among the water lilies in the Bonnet House Museum and Gardens. Of course, you cannot visit Florida without visiting one of its wonderful beaches, so you can drive 2 to 3 miles east of downtown Fort Lauderdale to Las Olas Beach for a fun day in the Atlantic Ocean.</p>

                        <br>
                       <h6 class="rn-title">3 superb land trips from Fort Lauderdale, Florida</h6>
                       <p>Car rental opens all kinds of new ways to explore. Once you have the keys in your hand, consider enjoying the beauty of Florida by crossing the state for two days. Cape Coral is located 140 miles east, and is filled with new adventures for the bold traveler. The famous city of Miami is closer - a short 30-minute trip to I-95 will put you in the heart of "Magic City". Beach lovers can take a two-hour car ride via I-75 to Naples for sunset and relaxation.</p>

                       <br>
                       <h6 class="rn-title"> How is parking at Fort Lauderdale?</h6>
                       <p> There are public parking facilities in different locations around the city where you can pay to leave your car. Take a look around to compare the different rates and restrictions. Many hotels have on-site parking where you can park your car safely.</p>

                       <p> Don't blow your vacation budget into an expensive car. Alternatively, you can book Fort Lauderdale car rental through us here at CarRentals.com today. We offer cheap deals on car rental in Sunshine State, which means that you spend your hard-earned money on admission to the Art Museum, and Fort Lauderdale instead of rented transportation.</p>
                       <br>
                       <h6 class="rn-title">Popular Queries for Car Rental in Fort Lauderdale</h6>
                       <ul>
                            <li> Ft Lauderdale Minivan Rental</li>
                             <li> Rent a Car in Fort Lauderdale</li>
                              <li> Car Rental Fort Lauderdale from $16/day</li>
                               <li> Fort Lauderdale airport minivan rental</li>
                                <li> fort Lauderdale airport car rental</li>
                                 <li> fort Lauderdale airport van rental</li>
                                  <li> fort Lauderdale van rental</li>
                                  <li> car rental fort Lauderdale airport terminal</li>
                                  <li> best car rental fort Lauderdale airport</li>
                                  <li> budget car rental fort Lauderdale</li>
                                  <li> budget car rental fort Lauderdale cruise terminal</li>
                                  <li> cheapest car rental fort Lauderdale airport</li>
                                  <li> cheap cars fort Lauderdale</li>
                                  <li> cheap rental cars fort Lauderdale fl airport</li>
                                   <li> budget car rental fort Lauderdale cruise port</li>
                                    <li> budget car rental fort Lauderdale locations</li>
                                     <li> minivan rental fort Lauderdale</li>
                       </ul>
                    </div>
                </div>
            </div>
            </div>
    </section>