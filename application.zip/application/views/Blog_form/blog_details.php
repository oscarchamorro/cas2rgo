<!-- Blog Single Post-->
<main class="rn-blog-single">
 <?php foreach ($blog_detail as $blog_details): ?>
<article>
    <!-- Single Post Header-->
    <header style="background-image: url(<?= base_url('admin/assets/blog_image/').$blog_details['image'] ?>)">
        <h1 class="rn-single-post-title"><?php echo $blog_details['title_name']  ?></h1>
        <div class="rn-single-post-meta">
            <span>By 
                <a href="#">Admin</a>
            </span>
            <span>At 
                <a href="#"><?php echo $blog_details['m_date']  ?></a>
            </span>
        </div>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Single Post Content-->
                <div class="rn-single-post-content">
                    <?php echo $blog_details['discription']  ?>
                </div>
            </div>
        </div>
    </div>
</article>
    <?php endforeach; ?>
</main>