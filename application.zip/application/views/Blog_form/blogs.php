<div class="rn-page-title">
        <div class="rn-pt-overlayer"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="rn-page-title-inner">
                        <h1>Latest Blog</h1>
                        <!--<p>Cras eros lorem, rhoncus ac risus sit amet, fringilla ultrices purus.</p>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="rn-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="slider blog">
                    <?php if(!empty($blog_list)) { foreach ($blog_list as $blog_lists){ ?>
                        <div>
                            <div class="col-lg-12">
                                <article class="rn-post-item rn-post-size-lg">
                                    <div class="rn-post-item-thumb">
                                        <a href="<?= base_url('blogdetails?blogid=').$blog_lists['id'] ?>">
                                            <img class="img-fluid" src="<?= base_url('admin/assets/blog_image/').$blog_lists['image'] ?>" alt="A standard blog post with image">
                                        </a>
                                    </div>
                                    <div class="rn-post-item-header">
                                        <div class="rn-post-date">
                                            <div class="rn-post-date-inner">
                                                <div class="rn-post-date-d"><?php echo $blog_lists['d_date'] ?></div>
                                                <div class="rn-post-date-m-y"><?php echo $blog_lists['m_date'] ?></div>
                                            </div>
                                        </div>
                                        <div class="rn-post-item-title-meta">
                                            <div class="rn-post-item-title-meta-inner">
                                                <div class="rn-post-item-meta">
                                                    <span class="rn-post-item-author">By 
                                                        <a href="#">Admin</a>
                                                    </span>
                                                </div>
                                                <h3 class="rn-post-item-title">
                                                    <a href="<?= base_url('blogdetails?blogid=').$blog_lists['id'] ?>"><?php echo $blog_lists['title_name'] ?></a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                        <div class="rn-post-item-body">
                                                <p><?php echo $blog_lists['discription'] ?>....</p>
                                        </div>
                                        <div class="rn-post-item-footer">
                                            <div class="rn-post-read-more">
                                                <a class="btn btn-dark" href="<?= base_url('blogdetails?blogid=').$blog_lists['id'] ?>">Read more</a>
                                            </div>
                                        </div>
                                </article>
                            </div>
                        </div>
                    <?php }} else { ?>
                    <p>No Blog Available!</p>
                    <?php } ?>
                </div>
            </div>
<!--            <div class="col-lg-4">
                    <aside class="rn-widget-area sidebar-ad" id="secondary">
                            <div class="rn-widget">
                                    <div class="rn-widget-content">
                                            <a href="index.php">
                                                    <img class="img-fluid" src="assets/images/banner.png" alt="banner" srcset="assets/images/banner.png 1x, assets/images/banner@2x.png 2x">
                                            </a>
                                    </div>
                            </div>
                    </aside>
            </div>-->
        </div>
    </div>
</div>
