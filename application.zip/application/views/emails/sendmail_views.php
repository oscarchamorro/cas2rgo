<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Mail</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
    <div style="width:800px;">
        <b><h3 style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">INFORMATION - REGISTER CARS2GO RENTALS</h3></b>
        <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Hey <?php echo $name;?> <?php echo $lname;?>,</p>
        <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Thanks for joining Cars2GoRentals.Your account is being forwarded to administration for approval. We will inform you once your account gets approved.</p>
        <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Please do not reply to this e-mail.</p>
        <!--<table style="border:1px solid lightgray;border-collapse:collapse;width:100%;max-width:600px;font-family: Georgia,serif;font-size: 16px;">
            <tr>
                <th style="border:1px solid lightgray;padding:4px;width:220px" class="pull-left">Email ID</th>
                <td style="border:1px solid lightgray;padding:4px;"><?php echo $emails;?></td>
            </tr>
            <tr>
                <th style="border:1px solid lightgray;padding:4px;width:220px" class="pull-left">Phone</th>
                <td style="border:1px solid lightgray;padding:4px"><?php echo $phone;?></td>
            </tr>
            <tr>
                <th style="border:1px solid lightgray;padding:4px;width:220px" class="pull-left">Password</th>
                <td style="border:1px solid lightgray;padding:4px"><?php echo $password;?></td>
            </tr>
            <tr>
                <th style="border:1px solid lightgray;padding:4px;width:220px" class="pull-left">Company</th>
                <td style="border:1px solid lightgray;padding:4px">
                    <?php if($company){ ?>
                     <?php echo $company;  ?></td>
                    <?php } ?>
            </tr>
            <tr>
                <th style="border:1px solid lightgray;padding:4px;width:220px" class="pull-left">SSN/TIN</th>
                <td style="border:1px solid lightgray;padding:4px">
                    <?php if($ssn_tin){ ?>
                     <?php echo $ssn_tin;  ?></td>
                    <?php } ?>
            </tr>
        </table>-->
        <br><br>
        <img src="<?= base_url('assets/images/logo.png')?>" width="150">
        <p>Cars2GoRentals Team</p>
        <p><a href="https://www.cars2gorentals.com" target="_blank">www.cars2gorentals.com/</a></p>
    </div>
</body>
</html>