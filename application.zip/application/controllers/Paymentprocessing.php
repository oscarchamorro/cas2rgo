<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paymentprocessing extends CI_Controller{
     function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Paynow_Model', 'paynow');
    }
    public function index(){
        $amountmail = $this->session->userdata('bookgetamount');
        $data['amount'] = $amountmail['amount'];
        $data['mail'] = $amountmail['correo'];
        $data['referencia'] = $amountmail['referencia'];
        
        $data['mantenimiento'] = $this->paynow->mantenimientopagos();
        $this->load->view('templates/header');
        $this->load->view('home_pages/payment_process',$data);
        $this->load->view('templates/footer');
    }
}
