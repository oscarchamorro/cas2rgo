<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PickupandDropLocation extends CI_Controller{
    
    function __construct() {
        parent::__construct();
//        if(!$this->session->userdata('logged_in')){
//            redirect('user_auth/login');
//        }
        $this->load->model('PickupandDropLocation_model','location_model');
    }


    public function get_pickuplocation(){
      
        $pickuplocations = $this->location_model->getpickuplocation($this->input->post('selectpickup'));
        $vendor='';
        
        foreach ($pickuplocations as $rowadd1){
            
            $locationtype = '<i class="fa fa-plane-departure"></i>';
                if(strpos($rowadd1->description, 'AIRPORT') !== FALSE){
                        $locationtype = '<i class="fa fa-plane"></i>';
                }else{
                        $locationtype = '<i class="fa fa-building"></i>';
                }

       echo '<div value="'.$rowadd1->oag_code.'" id="add1_'.$rowadd1->oag_code.$rowadd1->vendor.'" class="padding3px cityhover" style="cursor:pointer">
                '.$locationtype.' '.ucwords(strtolower($rowadd1->description.' - '.$rowadd1->state1.' - '.$rowadd1->city.' - '.$rowadd1->Country)).' '.$vendor.'
        </div>
        <script>
                $("#add1_'.$rowadd1->oag_code.$rowadd1->vendor.'").click(function(e){
                        $("#recogida_vendor").val("'.$rowadd1->vendor.'");
                        $("#rec").val("'.ucwords(strtolower($rowadd1->description.' - '.$rowadd1->state1.' - '.$rowadd1->city.' - '.$rowadd1->Country)).'");
                        $("#recogida").val("'.$rowadd1->oag_code.'");
                        $("#dev").val("'.ucwords(strtolower($rowadd1->description.' - '.$rowadd1->state1.' - '.$rowadd1->city.' - '.$rowadd1->Country)).'");
                        $("#devolucion").val("'.$rowadd1->oag_code.'");
                        $("#selectpickupShow").hide("fast");
                        $("#countryrecogida").val("'.$rowadd1->Country.'");
                        if(document.getElementById("countryrecogida").value == "united states of america"){
                                $("#countryrecogidasection").show("fast");
                        }else{
                                $("#countryrecogidasection").hide("fast");
                        }
                });
        </script>
			
        ';
    }
    }
    public function get_droplocation(){
        $pickuplocations = $this->location_model->getdroplocation($this->input->post('selectpickup'));
        $vendor='';
        foreach ($pickuplocations as $rowadd1){
            $locationtype = '<i class="fa fa-plane-departure"></i>';
            if(strpos($rowadd1->description, 'AIRPORT') !== FALSE){
                    $locationtype = '<i class="fa fa-plane fontsize16"></i>';
            }else{
                    $locationtype = '<i class="fas fa-building fontsize16"></i>';
            }
            echo '<div value="'.$rowadd1->oag_code.'" id="add1dev_'.$rowadd1->oag_code.$rowadd1->vendor.'" class="padding3px cityhover" style="cursor:pointer">
                            '.$locationtype.' '.ucwords(strtolower($rowadd1->description.' - '.$rowadd1->state1.' - '.$rowadd1->city.' - '.$rowadd1->Country)).' '.$vendor.'
                    </div>
                    <script>
                            $("#add1dev_'.$rowadd1->oag_code.$rowadd1->vendor.'").click(function(e){
                                    $("#dev").val("'.ucwords(strtolower($rowadd1->description.' - '.$rowadd1->state1.' - '.$rowadd1->city.' - '.$rowadd1->Country)).'");
                                    $("#devolucion").val("'.$rowadd1->oag_code.'");
                                    $("#selectDevShow").hide("fast");
                            });
                    </script>

            ';
            }   
    }
}
