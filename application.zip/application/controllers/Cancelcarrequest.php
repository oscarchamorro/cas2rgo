<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cancelcarrequest extends CI_Controller{
    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('UserBookinglisting_model','booking_list');
    }
    public function index(){
        $result = $this->booking_list->getcars_byid($this->input->post('id'));
        echo json_encode($result);
        $data['numeroreserva'] = $result[0]->reservaid;
        $data['apellido'] = $result[0]->nombre.' '.$result[0]->apellido;
    }
    public function setcancel($data = array(),$postvalue) {
        $this->security->xss_clean($this->input->post());
        if (empty($this->requestpost())) {
            $this->apperror('A request was not received');
        }
        $formulario = strtolower($this->requestpost('formulario'));
        
        if (empty($formulario)) {
            $this->apperror('The form parameter is required.');
        }
        if (!preg_match('/^[a-z_]+$/i', $formulario)) {
            $this->apperror(
		'The form parameter can only have letters and scratches to the floor'
	);
        }
       
        $rutaArchivoFormulario = $this->ota_vehcancelrqcore($postvalue);
        if (empty($rutaArchivoFormulario)) {
            $this->apperror(
		'The definition for the form is not found "' .$formulario. '"'
	);
        }

        if (empty($rutaArchivoFormulario)) {
            $this->apperror(
		'Could not generate code for form "' .$formulario. '"'
	);
        }

        $details = $data['detail'];
        $urldata = $data['urllink'];
        $request = (
                '<?xml version="1.0" encoding="UTF-8"?>' .
                str_replace(
                        '<POS/>', (
                        '<POS>' .
                        '<Source' .
                        ' ISOCountry="BS"' .
                        ' AgentDutyCode="' . $details['validationCode'] . '"' .
                        '>' .
                        '<RequestorID' .
                        ' Type="4"' .
                        ' ID="' . $details['vendorNumber'] . '"' .
                        '>' .
                        '<CompanyName' .
                        ' Code="CP"' .
                        ' CodeContext="' . $details['consumerProductCode'] . '"' .
                        '/>' .
                        '</RequestorID>' .
                        '</Source><Source><RequestorID Type="5" ID="00203711"/></Source>' .
                        $this->wrapContent(
                                'Source', (
                                $this->postWrap(
                                        ['compania'], ['<RequestorID Type="8" ID="', '"/>']
                                )
                                )
                        ) .
                        '</POS>'
                        ), $rutaArchivoFormulario
                )
                );
        $response = file_get_contents(
                $urldata['test'], false, stream_context_create(
                        [
                            'http' => [
                                'header' => (
                                "Content-type: application/x-www-form-urlencoded\r\n"
                                ),
                                'method' => 'POST',
                                'content' => 'xmldata=' . $request,
                            ],
                        ]
                )
        );
        file_put_contents($formulario . '_' . $this->input->post('compania') . '_request.xml', $request);
        file_put_contents($formulario . '_' .$this->input->post('compania') . '_response.xml', $response);
        $this->appreply(simplexml_load_string($response));
    }
    public function updatecancelreservation(){
        $result = $this->booking_list->reservation_cancel_update($this->input->post('cid'));
        $msg['success'] = false;
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
    }

    public function getcancel() {
        $this->load->model('Carlist_model', 'carlist_model');
        $rowresultmantenimiento = $this->carlist_model->get_mantenimiento();
        $mantenimiento = $rowresultmantenimiento[0]->estado;
        if ($mantenimiento == 0) {
            $data['detail'] = array(
                'consumerProductCode' => 'TT2G',
                'validationCode' => 'D3C23R7G15O',
                'vendorNumber' => 'T303',
            );
            $data['urllink'] = array(
                'test' => 'https://vv.xnet.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a',
            );
        } else {
            $data['detail'] = array(
                'consumerProductCode' => 'TT2G',
                'validationCode' => 'D3C23R7G15O',
                'vendorNumber' => 'T303',
            );
            $data['urllink'] = array(
                'test' => 'https://vv.xnet.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a',
            );
        }
        //print_r($this->input->post());
        $this->setcancel($data,$this->input->post());

    }

    public function clean(&$text) {
        $text = htmlspecialchars($text);
    }

    public function wrap($label, $attributes, $content = '', $requireContent = false) {
        $attributes = trim($attributes);
        if ((!$attributes && !$content) || ($requireContent && !$content)) {
            return '';
        }
        if ($content) {
            return (
                    '<' . $label . ($attributes ? ' ' . $attributes : '') . '>' .
                    $content .
                    '</' . $label . '>'
                    );
        }
        return '<' . $label . ' ' . $attributes . '/>';
    }

    public function wrapContent($label, $content) {
        return $this->wrap($label, '', $content);
    }

    public function wrapIfContent($label, $attributes, $content) {
        return $this->wrap($label, $attributes, $content, true);
    }
    
    public function requestpost($keys=[]){
		$return = $this->input->post();
		if(empty($keys)){
			return $return;
		}
		if(!is_array($keys)){
			$keys = [$keys];
		}
		for($i=0; $i<count($keys); $i++){
			if(isset($return[$keys[$i]])){
				if($i === count($keys)-1){
					return $return[$keys[$i]];
				}else{
					$return = $return[$keys[$i]];
				}
			}else{
				break;
			}
		}
		return '';
	}
	public function postWrap($keys, $wraps=''){
		return $this->textwrap($wraps, $this->requestpost($keys));
	}
        
        public function textwrap($wraps, $text){
		if(empty($text)){
			return '';
		}
		if(is_array($wraps)){
			$return = $wraps[0].$text;
			if(isset($wraps[1])){
				return $return.$wraps[1];
			}
			return $return;
		}
		return $wraps;
	}
        
        public function append($data, $error){
		die(
                    json_encode([
                            'datos' => $data,
                            'error' => $error,
                    ])
		);
	}
	public function apperror($error){
		$this->append('', $error);
	}
	public function appreply($data){
                //$this->updatecancelreservation($data,'');
		$this->append($data, '');
	}
    public function ota_vehcancelrqcore($data = array()){
      // print_r($data);die;
        $xml = (
                '<OTA_VehCancelRQ' .
                ' xmlns="http://www.opentravel.org/OTA/2003/05"' .
                ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' .
                ' xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_VehCancelRQ.xsd"' .
                ' Version="1.008"' .
                '>' .
                        '<POS/>' .
                        '<VehCancelRQCore CancelType="Book">' .
                                '<UniqueID Type="14" ID="' .$this->requestpost('numeroreserva'). '"/>' .
                                '<PersonName>' .
                                        '<Surname>' .$this->requestpost('apellido'). '</Surname>' .
                                '</PersonName>' .
                        '</VehCancelRQCore>' .
                '</OTA_VehCancelRQ>'
                    );
       return $xml;
                } 

//    public function cancelcar(){
//        $result = $this->booking_list->cancel_cars();
//        $msg['success'] = false;
//		if($result){
//			$msg['success'] = true;
//		}
//		echo json_encode($msg);
//    }
}
