<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogs extends CI_Controller{
    public function __construct() {
        parent::__construct();
//         if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
       $this->load->model('Blogs_model','blogs_model');
    }
    public function index(){
        $data['blog_list'] = array();
        $get_blogList = $this->blogs_model->get_bloglit();
        foreach ($get_blogList as $get_blogLists){
            $data['blog_list'][] = array(
                'id' => $get_blogLists->id,
                'title_name' => $get_blogLists->title_name,
                'image' => $get_blogLists->img,
                //'discription' => $get_blogLists->discription,
                'discription' => html_entity_decode(substr($get_blogLists->discription, 0, 90), ENT_QUOTES, 'UTF-8'),
                'd_date' => date('d', strtotime($get_blogLists->created_date)),
                'm_date' => date('M, Y', strtotime($get_blogLists->created_date)),
            );
        }
        //print_r($get_blogList);
        $this->load->view('templates/header');
        $this->load->view('Blog_form/blogs',$data);
        $this->load->view('templates/footer');
    }
}
