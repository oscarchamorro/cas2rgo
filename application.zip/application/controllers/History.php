<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class History extends CI_Controller{
    function __construct() {
        parent::__construct();
        if(!$this->session->userdata('logged_in')){
            redirect('user_auth/login');
        }
        $this->load->model('History_model','history_model');
    }

    public function index(){
        $id = $this->input->get('historyid');
        print_r($id);
        $data['historyAppdetail'] = array();
        $historyApproved = $this->history_model->get_history_Approved();
        foreach ($historyApproved as $historyApproveds){
            $historyPic = $this->history_model->get_history_locationbyID($historyApproveds->recogida);
            $data['historyAppdetail'][] = array(
                'pickuplocation' => $historyApproveds->recogida,
                'droplocation' => $historyApproveds->devolucion,
                'id' => $historyApproveds->id,
                'name1' => $historyApproveds->nombre,
                'name2' => $historyApproveds->apellido,
                'email' => $historyApproveds->correo,
                'phone' => $historyApproveds->phone1,
                'reservID' => $historyApproveds->reservaid,
                'amount' => $historyApproveds->amount,
                'model' => $historyApproveds->model,
                'currencycode' => $historyApproveds->currencycode,
                'image' => $historyApproveds->vehicle,
                'vendor' => $historyApproveds->vendor,
                'date' => $historyApproveds->fechadesolicitud,
                'image' => $historyApproveds->vehicle
            );
        }
        //print_r($data['historyAppdetail']);die;
            $this->load->view('templates/header');
            $this->load->view('history_form/history',$data);
            $this->load->view('templates/footer');
    }
    public function viewdetails(){
        $result = $this->history_model->get_history_locationbyID();
		echo json_encode($result);
    }
}
