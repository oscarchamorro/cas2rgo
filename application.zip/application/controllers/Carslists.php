<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Carslists extends CI_Controller {

    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        //$this->load->library('Xml');
        $this->load->model('Carlist_model', 'carlist_model');

        //$this->load->model('Request');
    }

    public function index() {
       
        $data['formvalue'] = $this->input->post();
        $data['bookdata'] = $this->session->userdata('book_now_data');
        $this->load->view('templates/header');
        $this->load->view('home_pages/cars_listing',$data);
        $this->load->view('templates/footer');
    }

    public function setsetup($data = array(),$postvalue) {
        //print_r($this->session->userdata('datas'));
        //array_walk_recursive($this->input->post(),$this->clean($this->input->post()));
        $this->security->xss_clean($this->input->post());
        if (empty($this->requestpost())) {
            $this->apperror('A request was not received');
        }
       
        //$formulario = $this->input->get('formulario');
        $formulario = strtolower($this->requestpost('formulario'));
        
        if (empty($formulario)) {
            $this->apperror('The form parameter is required.');
        }
        if (!preg_match('/^[a-z_]+$/i', $formulario)) {
            $this->apperror(
		'The form parameter can only have letters and scratches to the floor'
	);
        }
        $rutaArchivoFormulario = $this->ota_vehavailrqcore($postvalue);
        //echo $rutaArchivoFormulario = APPPATH.'controller/corefile/' .$formulario. '.php';
       //print_r($rutaArchivoFormulario);
        if (empty($rutaArchivoFormulario)) {
            $this->apperror(
		'The definition for the form is not found "' .$formulario. '"'
	);
        }

        if (empty($rutaArchivoFormulario)) {
            $this->apperror(
		'Could not generate code for form "' .$formulario. '"'
	);
        }

        $details = $data['detail'];
        $urldata = $data['urllink'];
        $request = (
                '<?xml version="1.0" encoding="UTF-8"?>' .
                str_replace(
                        '<POS/>', (
                        '<POS>' .
                        '<Source' .
                        ' ISOCountry="BS"' .
                        ' AgentDutyCode="' . $details['validationCode'] . '"' .
                        '>' .
                        '<RequestorID' .
                        ' Type="4"' .
                        ' ID="' . $details['vendorNumber'] . '"' .
                        '>' .
                        '<CompanyName' .
                        ' Code="CP"' .
                        ' CodeContext="' . $details['consumerProductCode'] . '"' .
                        '/>' .
                        '</RequestorID>' .
                        '</Source><Source><RequestorID Type="5" ID="00203711"/></Source>' .
                        $this->wrapContent(
                                'Source', (
                                $this->postWrap(
                                        ['compania'], ['<RequestorID Type="8" ID="', '"/>']
                                )
                                )
                        ) .
                        '</POS>'
                        ), $rutaArchivoFormulario
                )
                );
        $response = file_get_contents(
                $urldata['test'], false, stream_context_create(
                        [
                            'http' => [
                                'header' => (
                                "Content-type: application/x-www-form-urlencoded\r\n"
                                ),
                                'method' => 'POST',
                                'content' => 'xmldata=' . $request,
                            ],
                        ]
                )
        );
        file_put_contents($formulario . '_' . $this->input->post('compania') . '_request.xml', $request);
        file_put_contents($formulario . '_' .$this->input->post('compania') . '_response.xml', $response);
        $this->appreply(simplexml_load_string($response));
    }

    public function getsetup() {
        $rowresultmantenimiento = $this->carlist_model->get_mantenimiento();
        $mantenimiento = $rowresultmantenimiento[0]->estado;
        if ($mantenimiento == 0) {
            $data['detail'] = array(
                'consumerProductCode' => 'TT2G',
                'validationCode' => 'D3C23R7G15O',
                'vendorNumber' => 'T303',
            );
            $data['urllink'] = array(
                'test' => 'https://vv.xnet.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a',
            );
        } else {
            $data['detail'] = array(
                'consumerProductCode' => 'TT2G',
                'validationCode' => 'D3C23R7G15O',
                'vendorNumber' => 'T303',
            );
            $data['urllink'] = array(
                'test' => 'https://vv.xnet.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a',
            );
        }
        
        $this->setsetup($data,$this->input->post());
//       
//        $this->load->view('templates/header');
//        $this->load->view('home_pages/cars_listing');
//        $this->load->view('templates/footer');
    }

    public function clean(&$text) {
        $text = htmlspecialchars($text);
    }

    public function wrap($label, $attributes, $content = '', $requireContent = false) {
        $attributes = trim($attributes);
        if ((!$attributes && !$content) || ($requireContent && !$content)) {
            return '';
        }
        if ($content) {
            return (
                    '<' . $label . ($attributes ? ' ' . $attributes : '') . '>' .
                    $content .
                    '</' . $label . '>'
                    );
        }
        return '<' . $label . ' ' . $attributes . '/>';
    }

    public function wrapContent($label, $content) {
        return $this->wrap($label, '', $content);
    }

    public function wrapIfContent($label, $attributes, $content) {
        return $this->wrap($label, $attributes, $content, true);
    }
    
    public function requestpost($keys=[]){
		$return = $this->input->post();
		if(empty($keys)){
			return $return;
		}
		if(!is_array($keys)){
			$keys = [$keys];
		}
		for($i=0; $i<count($keys); $i++){
			if(isset($return[$keys[$i]])){
				if($i === count($keys)-1){
					return $return[$keys[$i]];
				}else{
					$return = $return[$keys[$i]];
				}
			}else{
				break;
			}
		}
		return '';
	}
	public function postWrap($keys, $wraps=''){
		return $this->textwrap($wraps, $this->requestpost($keys));
	}
        
        public function textwrap($wraps, $text){
		if(empty($text)){
			return '';
		}
		if(is_array($wraps)){
			$return = $wraps[0].$text;
			if(isset($wraps[1])){
				return $return.$wraps[1];
			}
			return $return;
		}
		return $wraps;
	}
        
        public function append($data, $error){
		die(
                    json_encode([
                            'datos' => $data,
                            'error' => $error,
                    ])
		);
	}
	public function apperror($error){
		$this->append('', $error);
	}
	public function appreply($data){
            //print_r($data);die;
		$this->append($data, '');
	}
        
public function ota_vehavailrqcore($data = array()){
  // print_r($this->requestpost());die;
            $preferencias = '';
            $indice = 0;
            $codeVhType ='';
if($data['preferencias'][0]['vehiculo']['categoria'] == '' OR $data['preferencias'][0]['vehiculo']['categoria'] >= 1 AND $data['preferencias'][0]['vehiculo']['categoria'] <= 5 ){
	$codeVhType = '';
}
elseif($data['preferencias'][0]['vehiculo']['categoria'] >= 6 AND $data['preferencias'][0]['vehiculo']['categoria'] <= 10){
	$codeVhType = ' Code="MVAR" CodeContext="SIPP"';
}
elseif($data['preferencias'][0]['vehiculo']['categoria'] > 10){
	$codeVhType = ' Code="PCAR" CodeContext="SIPP"';
}

while($this->requestpost(['preferencias',$indice])){
   
	$preferencias .= $this->wrap(
		'VehPref',
		(
			$this->postWrap(
				['preferencias',$indice,'aireacondicionado', 'incluido'],
				' AirConditionInd="true"'
			) .
			$this->postWrap(
				['preferencias', $indice, 'aireacondicionado', 'requerido'],
				' AirConditionPref="Only"'
			) .
			$this->postWrap(
				['preferencias', $indice, 'transmision', 'tipo'],
				[' TransmissionType="', '"']
			) .
			$this->postWrap(
				['preferencias', $indice, 'transmision', 'requerido'],
				' TransmissionPref="Only"'
			) .
			$this->postWrap(
				['preferencias', $indice, 'combustible'],
				[' FuelType="', '"']
			) .
			$this->postWrap(
				['preferencias', $indice, 'manejo'],
				[' DriveType="', '"']
			) .
			$this->postWrap(
				['preferencias', $indice, 'elite'],
				' UpSellInd="True"'
			) . $codeVhType 
		),
		(
			$this->wrap(
				'VehType',
				(
					$this->postWrap(
						['preferencias', $indice, 'vehiculo', 'categoria'],
						[' VehicleCategory="', '"']
					) .
					$this->postWrap(
						['preferencias', $indice, 'vehiculo', 'puertas'],
						[' DoorCount="', '"']
					)
				)
			) .
			$this->wrap(
				'VehClass',
				$this->postWrap(
					['preferencias', $indice, 'vehiculo', 'tamano'],
					[' Size="', '"']
				)
			)
		)
	);
	$indice++;
}
$preferenciasEspeciales = '';
$indice = 0;
while($this->requestpost(['equipamientoespecial',$indice])){
	$preferenciasEspeciales .= $this->wrap(
		'SpecialEquipPref',
		(
			$this->postWrap(
				['equipamientoespecial', $indice, 'tipo'],
				[' EquipType="', '"']
			) .
			$this->postWrap(
				['equipamientoespecial', $indice, 'cantidad'],
				[' Quantity="', '"']
			)
		)
	);
	$indice++;
}
$documentos = '';
$indice = 0;
while($this->requestpost(['documento',$indice])){
	$documentos .= $this->wrap(
		'Document',
		(
			$this->postWrap(
				['documento', $indice, 'tipo'],
				[' DocType="', '"']
			) .
			$this->postWrap(
				['documento', $indice, 'numero'],
				[' DocID="', '"']
			) .
			$this->postWrap(
				['documento', $indice, 'ubicacion'],
				[' DocIssueLocation="', '"']
			) .
			$this->postWrap(
				['documento', $indice, 'pais'],
				[' DocIssueCountry="', '"']
			) .
			$this->postWrap(
				['documento', $indice, 'vencimiento'],
				[' ExpireDate="', '"']
			)
		)
	);
	$indice++;
}
$membresias = '';
$indice = 0;
while($this->requestpost(['membresia',$indice])){
	$membresias .= $this->wrap(
		'CustLoyalty',
		(
			$this->postWrap(
				['membresia', $indice, 'numero'],
				[' MembershipID="', '"']
			) .
			$this->postWrap(
				['membresia', $indice, 'programa'],
				[' ProgramID="', '"']
			) .
			$this->postWrap(
				['membresia', $indice, 'sector'],
				[' TravelSector="', '"']
			)
		)
	);
	$indice++;
}
$serviciosOtraUbicacion = '';
$indice = 0;
while($this->requestpost(['serviciootraubicacion',$indice])){
	$membresias .= $this->wrap(
		'OffLocService',
		(
			$this->postWrap(
				['serviciootraubicacion', $indice, 'tipo'],
				[' Type="', '"']
			) .
			$this->postWrap(
				['serviciootraubicacion', $indice, 'instrucciones'],
				[' SpecInstructions="', '"']
			)
		),
		(
			$this->wrapContent(
				'Address',
				(
					$this->postWrap(
						['serviciootraubicacion', $indice, 'direccion'],
						['<AddressLine>', '</AddressLine>']
					) .
					$this->postWrap(
						['serviciootraubicacion', $indice, 'direccioncomplemento'],
						['<AddressLine>', '</AddressLine>']
					) .
					$this->postWrap(
						['serviciootraubicacion', $indice, 'ciudad'],
						['<CityName>', '</CityName>']
					) .
					$this->postWrap(
						['serviciootraubicacion', $indice, 'codigopostal'],
						['<PostalCode>', '</PostalCode>']
					) .
					$this->postWrap(
						['serviciootraubicacion', $indice, 'departamento'],
						['<StateProv StateCode="', '"/>']
					) .
					$this->postWrap(
						['serviciootraubicacion', $indice, 'pais'],
						['<CountryName Code="', '"/>']
					)
				)
			) .
			$this->wrap(
				'Telephone',
				$this->postWrap(
					['serviciootraubicacion', $indice, 'telefono'],
					[' PhoneNumber="', '"']
				)
			)
		)
	);
	$indice++;
}
$xml = (
	'<OTA_VehAvailRateRQ' .
	' xmlns="http://www.opentravel.org/OTA/2003/05"' .
	' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' .
	' xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_VehAvailRateRQ.xsd"' .
	' Version="1.008"' .
	' MaxResponses="20"' .
	'>' .
		'<POS/>' .
		'<VehAvailRQCore Status="All">' .
			'<VehRentalCore' .
			' PickUpDateTime="' .
				$this->requestpost(['recogida','fecha']) .
				'T' .
				$this->requestpost(['recogida','hora']). ':00' .
				'"' .
			' ReturnDateTime="' .
				$this->requestpost(['devolucion','fecha']) .
				'T' .
				$this->requestpost(['devolucion','hora']). ':00' .
				'"' .
			'>' .
				'<PickUpLocation' .
				' LocationCode="' .$this->requestpost(['recogida','lugar']). '"' .
				' CodeContext="IATA"' .
				'/>' .
				'<ReturnLocation' .
				' LocationCode="' .$this->requestpost(['devolucion','lugar']). '"' .
				' CodeContext="IATA"' .
				'/>' .
			'</VehRentalCore>' .
			$this->wrapContent(
				'VehPrefs',
				$preferencias
			) .
			$this->wrap(
				'RateQualifier',
				(
					' RateQualifier="BEST"' .
					$this->postWrap(
						'uso',
						[' TravelPurpose="1"']
					) .
					$this->postWrap(
						['descuentos', 'compania'],
						[' CorpDiscountNmbr="', '"']
					) .
					$this->postWrap(
						['descuentos', 'promocion'],
						[' PromotionCode="', '"']
					)
				)
			) .
			$this->wrapContent(
				'SpecialEquipPrefs',
				$preferenciasEspeciales
			) .
		'</VehAvailRQCore>' .
		$this->wrapContent(
			'VehAvailRQInfo',
			$this->wrapContent(
				'Customer',
                            $this->wrap(
					'Primary',
					$this->postWrap(
						'fechanacimiento',
						[' BirthDate="', '"']
					),
					(
						$this->postWrap(
							'correo',
							['<Email>', '</Email>']
						) .
						$this->wrapContent(
							'Address',
							(
								$this->postWrap(
									'direccion',
									['<AddressLine>', '</AddressLine>']
								) .
								$this->postWrap(
									'direccioncomplemento',
									['<AddressLine>', '</AddressLine>']
								) .
								$this->postWrap(
									'ciudad',
									['<CityName>', '</CityName>']
								) .
								$this->postWrap(
									'codigopostal',
									['<PostalCode>', '</PostalCode>']
								) .
								$this->postWrap(
									'departamento',
									['<StateProv StateCode="', '"/>']
								) .
								$this->postWrap(
									'pais',
									['<CountryName Code="', '"/>']
								)
							)
						) .
						$documentos .
						$membresias
					)
				)
			) .
			$this->postWrap(
				'requerimientoespecial',
				['<SpecialReqPref>', '</SpecialReqPref>']
			) .
			$serviciosOtraUbicacion .
			$this->wrap(
				'ArrivalDetails',
				(
					$this->postWrap(
						['detallesllegada', 'trasnporte'],
						[' TransportationCode="', '"']
					) .
					$this->postWrap(
						['detallesllegada', 'numerovuelo'],
						[' Number="', '"']
					)
				),
				$this->postWrap(
					['detallesllegada', 'aerolinea'],
					['<OperatingCompany Code="', '"/>']
				)
			) .
			$this->wrap(
				'TourInfo',
				$this->postWrap(
					'numerotour',
					[' TourNumber="', '"']
				)
			)
		) .
	'</OTA_VehAvailRateRQ>'
        );
return $xml;
        }

}
