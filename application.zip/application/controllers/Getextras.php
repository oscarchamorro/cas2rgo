<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Getextras extends CI_Controller{
    function __construct() {
        parent::__construct();
        $this->load->model('Getextras_model', 'getextras_model');
    }
    public function index(){
       $getdata = $this->getextras_model->getextras_location();
       echo $getdata;
    }
    public function tarifas_agentopeator(){
        $getdata = $this->getextras_model->tarifas_agentopeators();
        $dates = $getdata[0]['discount'];
        echo $dates;
    }
    public function tarifas_agentopeatorcomission(){
        $getdatas = $this->getextras_model->tarifas_agentopeatorcomissions();
        $dates = $getdatas[0]['payment'];
       if($dates == 0){
	echo $dates[0]['commission'];
        }
        else{
            echo 1;
        }
            }
}
