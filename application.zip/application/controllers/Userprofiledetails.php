<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Userprofiledetails extends CI_Controller{
    function __construct() {
        parent::__construct();
        if(!$this->session->userdata('logged_in')){
            redirect('user_auth/login');
        }
        $this->load->model('User_model');
    }

    public function index(){
        $userdetail=$this->session->userdata('user_data_session');
        $id = $userdetail['user_id'];
        $data['user_list'] = array();
        $userdetails = $this->User_model->getcurrentuserdata($id);
        foreach ($userdetails as $userdetail){
            $data['user_list'][] = array(
                'uid' => $userdetail->id,
                'fname' => $userdetail->names1,
                'lname' => $userdetail->lastname1,
                'image' => $userdetail->image,
                'country' => $userdetail->country,
                'city' => $userdetail->city,
                'address' => $userdetail->address,
                'phone' => $userdetail->phone,
                'email' => $userdetail->email,
            );
        }
        if($this->input->post()){
            $this->form_validation->set_rules('fname', 'First name', 'required');
            $this->form_validation->set_rules('lname', 'First name', 'required');
            $this->form_validation->set_rules('country', 'Country name', 'required');
            $this->form_validation->set_rules('city', 'City name', 'required');
            $this->form_validation->set_rules('address', 'Address name', 'required');
            $this->form_validation->set_rules('phone', 'Phone No.', 'required');
            if($this->form_validation->run() == FALSE){
                  
                    $this->load->view('templates/header');
                    $this->load->view('user_booking_pages/user_profile',$data);
                    $this->load->view('templates/footer');
            } else{
                $this->updateuserprofile();
            }
        }
        //print_r($userdetails);
        $this->load->view('templates/header');
        $this->load->view('user_booking_pages/user_profile',$data);
        $this->load->view('templates/footer');
    }
    public function updateuserprofile(){
        $config['upload_path'] = './assets/user_image';
                     $config['allowed_types'] = 'gif|jpg|png|jpeg';
//                     $config['max_size'] = '2048';
//                     $config['max_width'] = '2000';
//                     $config['max_height'] = '2000';
                      $config['overwrite'] = true;

                     $this->load->library('upload', $config);
                     $post_image = '';
                     if(!$this->upload->do_upload('userimage')){
                          // print_r($this->upload);die;
                             $errors = array('error' => $this->upload->display_errors());
                             $post_image = $this->input->post('old_image');
                     } else {
                              array('upload_data' => $this->upload->data());
                             $post_image = $_FILES['userimage']['name'];
                     }
                    
                    $userdetail=$this->session->userdata('user_data_session');
                    $userid = $userdetail['user_id'];
                    $password =$userdetail['password'];
                    $email =$userdetail['email'];
                 
                   $data = array(
                                'names1' => $this->input->post('fname'),
                                'lastname1' => $this->input->post('lname'),
                                'phone' => $this->input->post('phone'),
                                'city' => $this->input->post('city'),
                                'country' => $this->input->post('country'),
                                'address' => $this->input->post('address'),
                                'image' => $post_image,
                                'password' => $password,
                                'email' => $email,
                               
			);
                    $data = $this->security->xss_clean($data);
                    $result =   $this->User_model->update_userprofile($data,$userid);
            if($result){
                echo '<script>alert("Region already added");</script>';
                
                    $this->session->set_flashdata('updateprofile', 'You are Updated Successfully!');
                    $this->session->flashdata('updateprofile');
                    redirect('userprofiledetails?userid='.$result);
                }
            }
}
