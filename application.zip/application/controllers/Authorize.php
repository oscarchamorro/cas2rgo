<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authorize extends CI_Controller{
     function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Paynow_Model', 'paynow');
         $mode = $this->paynow->mantenimientopagos();
         $test = $mode[0]->estado;
         if($test==1){
             $modes = 'true';
         }else{
             $modes = 'false';
         }
         $this->login             = '678LzG7kzE6';
         $this->transaction_key  = '4yUd8383KZd3Q8N9';
         $this->signature_key    = 'D304F65EA9FADB1265999FEB30D4B4AFA8612337E90BD766F40DD97F6D502730C6AB8215518EC53938D3495D908E0ADDD3853E80592E7425663F569D4B02D363';
         //$this->login             = '3X2hyM6bkxp';
         //$this->transaction_key  = '4Q5nWeQ683Nv356G';
         //$this->signature_key    = '5346FF5516F8B107DC0E4C5C2AEA557E4B044175FBCB1BB6D537168D5EC6AE1E1E8F9D08162741F22AAF3FC4F7FF703D6991656E42C23E10A74C81D2CB79081F';
         //$this->login            = '9vRf9F6D';
         //$this->transaction_key  = '7767fnAePJ275BeD';
         //$this->signature_key    = 'B3CA9F83E438E7BDD23013C61DD3338D98C29E0C3306D7F73184B52A8F057D1998572A077B228624F41EFE8C968409FDF5F1C773D4F71986CCEA75523758D7DE';
         $this->mode             = $modes;
         $this->transaction_mode = 'transaction_mode';
         $this->working_mode    =   'false';
         $this->success_message  = 'success_message';
         $this->failed_message   = 'failed_message';
         $this->liveurl          = 'https://secure2.authorize.net/gateway/transact.dll';
         //$this->liveurl          = 'https://secure.authorize.net/gateway/transact.dll';
         $this->testurl			= 'https://sandbox.authorize.net/gateway/transact.dll';
         //$this->testurl          = 'https://test.authorize.net/gateway/transact.dll';
    }
    public function index(){
        $amountmail = $this->session->userdata('bookgetamount');
        $fname = $amountmail['nombre'];
        $lname = $amountmail['apellido'];
        $amount = $amountmail['amount'];
        $mail = $amountmail['correo'];
        $referencia = $amountmail['referencia'];
         $order    = '123456';
         $order_id = $referencia;
         $timeStamp     = time();
         $order_total   = $amount;
         $signatureKey  = ($this->signature_key != '') ? $this->signature_key : '';
         
      
         $hash_d        = hash_hmac('sha512', sprintf('%s^%s^%s^%s^',
                           $this->login,      
                           $order_id,  
                           $timeStamp, 
                           $order_total      
                           ),hex2bin($signatureKey));
         
         
         $relay_url = base_url('paymentresult');
         $cancel_url = base_url();
         $authorize_args = array(
            
            'x_login'                  => $this->login,
            'x_amount'                 => $order_total,
            'x_invoice_num'            => $referencia,
            'x_relay_response'         => "false",
            //'x_relay_url'              => $relay_url,
            'x_fp_sequence'            => $order_id,
            'x_fp_hash'                => $hash_d,
            'x_show_form'              => 'PAYMENT_FORM',
            'x_version'                => '3.1',
            'x_fp_timestamp'           => $timeStamp,
            'x_first_name'             => $fname ,
            'x_last_name'              => $lname ,
            'x_company'                => '' ,
            'x_address'                => '',
            'x_country'                => '',
            'x_state'                  => '',
            'x_city'                   => '',
            'x_zip'                    => '',
            'x_phone'                  => '',
            'x_email'                  => $mail,
            'x_ship_to_first_name'     => $fname ,
            'x_ship_to_last_name'      => $lname ,
            'x_ship_to_company'        => '',
            'x_ship_to_address'        => '',
            'x_ship_to_country'        => '',
            'x_ship_to_state'          => '',
            'x_ship_to_city'           => '',
            'x_ship_to_zip'            => '',
            'x_cancel_url'             => $cancel_url,
            'x_freight'                => '',
            'x_cancel_url_text'        => 'Cancel Payment'
            );
         
            
         if( $this->transaction_mode == 'authorize' ){
            $authorize_args['x_type'] = 'AUTH_ONLY';
         }else{
            $authorize_args['x_type'] = 'AUTH_CAPTURE';
         
         }
         
         /*if( $this->mode == 'false' ){
            $authorize_args['x_test_request'] = 'TRUE';
         }else{
            $authorize_args['x_test_request'] = 'FALSE';
         
         }*/
         
         if( $this->working_mode == 'false' ){
            $authorize_args['x_solution_id'] = '';
         }
         
         
         $authorize_args_array = array();
         
         foreach($authorize_args as $key => $value){
           $authorize_args_array[] = "<input type='hidden' name='$key' value='$value'/>";
         }
         
        if($this->mode == 'true'){
           $processURI = $this->testurl;
         }
         else{
            $processURI = $this->liveurl;
         }
         
         $data['html_form'] = '<form action="'.$processURI.'" method="post" id="authorize_payment_form">' 
               . implode('', $authorize_args_array) 
               . '<input type="submit" class="button" id="submit_authorize_payment_form" value="Pay Now" /><a class="button cancel" href=""></a>'
               . '</form>';

         //return $html_form;
        
        $this->load->view('templates/header');
        $this->load->view('home_pages/authorize_process',$data);
        $this->load->view('templates/footer');
    }
}
