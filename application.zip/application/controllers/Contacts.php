<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contacts extends CI_Controller{
    public function __construct() {
        parent::__construct();
//       if(!$this->session->userdata('logged_in')){
//            redirect('user_auth/login');
//        }
        $this->load->model('Contact_model','contact_model');
    }
    public function index(){
        
        if($this->input->post()){
            $data = array(
                'names' => $this->input->post('names'),
                'email' => $this->input->post('email'),
                'phone' => $this->input->post('phone'),
                'comments' => $this->input->post('comments'),
                'date' => date('Y-m-d H:m:s')
            );
            $data = $this->security->xss_clean($data);
                $result = $this->contact_model->save_contacts($data);
                if($result){
                    $this->sendmail($result);
                }
                    $this->session->set_flashdata('save_message','Send Message succcessfully');
                    $this->session->flashdata('save_message');
                    redirect('contacts');
        }
        $this->load->view('templates/header');
        $this->load->view('home_pages/contacts');
        $this->load->view('templates/footer');
    }
    public function sendmail($result){
        $logocars2go='<img src="img/logomodalmix.png" alt="car hire, cheap, rental miami, cars rentals, florida, bahamas, usa, carrentals">';
        $cuerpo='
		<b><h3>INFORMATION - CONTACT CARS2GO RENTALS</h3></b><br />
		<b>Names: </b> '.ucfirst($result['names']).'<br />
		<b>E-Mail: </b> '.$result['email'].'<br />
		<b>Phone: </b> '.$result['phone'].'<br />
		<b>Comments: </b> '.$result['comments'].' <br /><br />
		'.$logocars2go.'<br /><br /><br />
		';
        $config = Array(    
              'protocol' => 'sendmail',
              'smtp_host' => 'mail.cars2gorentals.com',
              'smtp_port' => 587,
              'smtp_user' => 'no-reply@cars2gorentals.com',
              'smtp_pass' => 'Colombia.2018',
              'smtp_timeout' => '4',
              'mailtype' => 'html',
              'charset' => 'iso-8859-1'
            );
            //print_r($cuerpo);die;
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->from($result['email']);
            $this->email->to('info@cars2gorentals.com'); 
            $this->email->subject('contact cars2go rentals', $result['email']); 
            $this->email->message($cuerpo); 
            $this->email->send();
    }
}
