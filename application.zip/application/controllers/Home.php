<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('PickupandDropLocation_model', 'location_model');
    }

    public function index() {
        $formulario = $this->input->post('formulario');
        $this->session->set_userdata('formulario_data', $formulario);
        //print_r($formulario);die;
        if ($this->input->post()) {
            $this->form_validation->set_rules('selectpickup', 'Pick Location', 'required');
            //$this->form_validation->set_rules('devolucion', 'Drop Location', 'required');
            if($this->form_validation->run()==false){
             
                $this->load->view('templates/header');
                $this->load->view('templates/home');
                $this->load->view('templates/footer');
            } else {
                $userdetail = $this->session->userdata('user_data_session');
                $email = $userdetail['email'];
                $name = $userdetail['name'];
                $lname = $userdetail['lastname'];
                $phone = $userdetail['phone'];
                //print_r($userdetail);die;
                $data = array(
                    'recogida' => $this->input->post('recogida', true),
                    'devolucion' => $this->input->post('devolucion', true),
                    'nombre' => $name,
                    'apellido' => $lname,
                    'correo' => $email,
                    'phone1' => $phone
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
//                                'recogida' => $this->input->post('recogida', true),
                );
                $this->session->set_userdata('book_now_data', $data);
               // print_r($data);die;
               redirect('carslists');
            }
        } else {
            $this->load->view('templates/header');
            $this->load->view('templates/home');
            $this->load->view('templates/footer');
        }
    }

}
