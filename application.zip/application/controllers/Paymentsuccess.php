<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paymentsuccess extends CI_Controller{
     function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Paynow_Model', 'paynow');
    }
    public function index(){
        if($this->input->get()){
            $data =array(
                'referencia' => base64_decode($this->input->get('rf')),
                'reservaid' => base64_decode($this->input->get('rid')),
            );
            $id = $this->input->get('id');
            $referencia = base64_decode($this->input->get('rf'));
            $restult = $this->paynow->getfinal_update($id,$data);
        }
        $data['invoiceshow'] = $this->paynow->getdata_invoice($id,$referencia);
       
        $plocatio = $data['invoiceshow'][0]->recogida;
        $picktimenew = explode(',',$plocatio);
        $data['pktimedate'] = $picktimenew[1].', '.$picktimenew[2];
        $dlocatio = $data['invoiceshow'][0]->devolucion;
        $drptimenew = explode(',',$dlocatio);
        $data['drptimedate'] = $drptimenew[1].', '.$drptimenew[2];
        
        $pickuplocation = $this->paynow->get_pickup($plocatio);
        $data['pickuplocation'] = ucwords(strtolower($pickuplocation[0]->description.' - '.$pickuplocation[0]->state1.' - '.$pickuplocation[0]->city.' - '.$pickuplocation[0]->Country));
        $droplocation = $this->paynow->get_drop($dlocatio);
        $data['droplocation']= ucwords(strtolower($droplocation[0]->description.' - '.$droplocation[0]->state1.' - '.$droplocation[0]->city.' - '.$droplocation[0]->Country));
        //print_r($data['invoiceshow']);die;
        $this->load->view('templates/header');
        $this->load->view('home_pages/invoiceinfomation_view',$data);
        $this->load->view('templates/footer');
    }
}
