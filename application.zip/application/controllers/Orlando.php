<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orlando extends CI_Controller{
    
    public function index(){
        $data['pagetitle'] = 'Best Orlando Car Rental | Cheap Minivan Car Rental Orlando Florida';
        $data['discription'] = "Cars2Go Rental Offers budget minivan car rental in Orlando Florida to international airport,lakes,south beach,cruise port,international mall at affordable price in best exotic and luxury car Orlando Florida.";
            $this->load->view('templates/header',$data);
            $this->load->view('home_pages/orlando_form');
            $this->load->view('templates/footer');
    }
}
