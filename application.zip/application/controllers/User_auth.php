<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_auth extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('User_model');
    }
   
    // Register user
    public function userregister(){
        $data['title'] = 'Create Account';
        
            $this->form_validation->set_rules('email', 'Email', 'required|callback_check_email_exists');

            if($this->form_validation->run() === FALSE){
                    $this->load->view('templates/header');
                    $this->load->view('auth/register');
                    $this->load->view('templates/footer');
            } else {
                $this->load->library('email');
                    // Encrypt password
                   $pass = 'cars2go@123';
                    $password = md5($pass);
                    $status = 0;
                    $result = $this->User_model->register_user($status,$password);
                    if($result){
                        $this->htmlmail($result);
                    }
                    // Set message
                    $this->session->set_flashdata('user_registered', '<h3 class="mb-3">Thank You!</h3><br>You are successfully registered with Cars2GoRentals. Please check your inbox.');
                    redirect('user_auth/userregister');
                    $this->session->flashdata('user_registered');
            }
    }
    public function ajax_login(){
        
        $email = $this->input->post('email');
        $password = md5($this->input->post('pass'));
        $user_id = $this->User_model->login($email, $password);
        if($user_id){
                        $user_data = $this->User_model->get_user_data($user_id);
                            // Create session
                            //print_r($user_data);
                            $user_detail = array(
                                    'user_id' => $user_data['user_id'],
                                    'name' => $user_data['name'],
                                    'lastname' => $user_data['lastname'],
                                    'email' => $user_data['email'],
                                    'phone' => $user_data['phone'],
                                    'password' => $user_data['password'],
                                    'logged_in' => true
                            );
                           $this->session->set_userdata('user_data_session', $user_detail);
                           $this->session->set_userdata('logged_in', true);
                           $this->session->set_flashdata('user_loggedin', 'You are now logged in');
                           echo base_url()."home/";
                            //redirect('home');
                    } else {
                            // Set message
                            $this->session->set_flashdata('login_failed', 'Login is invalid');
                            redirect('user_auth/ajax_login');
                            $this->session->flashdata('login_failed');
                    }
    }

    // Log in user
    public function login(){
            $data['title'] = 'Sign In';
            
            $this->form_validation->set_rules('usuario', 'Email', 'required');
            $this->form_validation->set_rules('pass', 'Password', 'required');

            if($this->form_validation->run() === FALSE){
                    $this->load->view('templates/header');
                    $this->load->view('auth/login', $data);
                    $this->load->view('templates/footer');
            } else {

                    // Get username
                    $email = $this->input->post('usuario');
                    // Get and encrypt the password
                    $password = md5($this->input->post('pass'));

                    // Login user
                    $user_id = $this->User_model->login($email, $password);
                    //print_r($user_id);die;
                    if($user_id){
                        $user_data = $this->User_model->get_user_data($user_id);
                            // Create session
                            //print_r($user_data);
                            $user_detail = array(
                                    'user_id' => $user_data['user_id'],
                                    'name' => $user_data['name'],
                                    'lastname' => $user_data['lastname'],
                                    'email' => $user_data['email'],
                                    'phone' => $user_data['phone'],
                                    'password' => $user_data['password'],
                                    'logged_in' => true
                            );
                            //print_r($user_detail);die;
                           $this->session->set_userdata('user_data_session', $user_detail);
                           $this->session->set_userdata('logged_in', true);
                           
                           //print_r($this->session->set_userdata());die;
                        
                            // Set message
                            $this->session->set_flashdata('user_loggedin', 'You are now logged in');
                            redirect('bookinglist');
                    } else {
                            // Set message
                            $this->session->set_flashdata('login_failed', 'Login is invalid');
                            redirect('user_auth/login');
                           $this->session->flashdata('login_failed');
                    }
                    
            }
                   
    }

    // Log user out
    public function logout(){
            // Unset user data
            $this->session->unset_userdata('logged_in');
            $this->session->unset_userdata('user_id');
            $this->session->unset_userdata('email');

            // Set message
            $this->session->set_flashdata('user_loggedout', 'You are now logged out');

            redirect('home');
    }


    // Check if email exists
   public function check_email_exists($email){
            $this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
            if($this->User_model->check_email_exists($email)){
                    return true;
            } else {
                    return false;
            }
    }
    public function htmlmail($result){
            $config = Array(    
              'protocol' => 'sendmail',
              'smtp_host' => 'mail.cars2gorentals.com',
              'smtp_port' => 587,
              'smtp_user' => 'no-reply@cars2gorentals.com',
              'smtp_pass' => 'Colombia.2018',
              'smtp_timeout' => '4',
              'mailtype' => 'html',
              'charset' => 'iso-8859-1'
            );

            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->from('no-reply@orient.com.co', 'Cars2Gorentals');
            
                $data['name'] = $result['names1'];
                $data['lname'] = $result['lastname1'];
                $data['emails'] = $result['email'];
                $data['phone'] = $result['phone'];
                $data['password'] = 'cars2go@123' ;
				$data['company'] = $result['company'];
                $data['ssn_tin'] = $result['ssn_tin'];
                
            $this->email->to($result['email']); 
            $this->email->subject('Account has been Created Successfully on Cars2GoRentals'); 
            $body = $this->load->view('emails/sendmail_views',$data,TRUE);
            $this->email->message($body); 
            $this->email->send();
          }
        
}
