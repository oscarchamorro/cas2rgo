<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bookinglist extends CI_Controller{
    function __construct() {
        parent::__construct();
        if(!$this->session->userdata('logged_in')){
            redirect('user_auth/login');
        }
        $this->load->model('UserBookinglisting_model','booking_list');
    }

    public function index(){
        //print_r($this->input->get());die;
        $userdetail=$this->session->userdata('user_data_session');
        $email = $userdetail['email'];
        $data['bookinglist'] = array();
        $bookinglist = $this->booking_list->get_bookinglist($email);
        foreach ($bookinglist as $bookinglists){
            $picktimenew = explode(',',$bookinglists->recogida);
            $droptimenew = explode(',',$bookinglists->devolucion);
                $droplocation = $this->booking_list->get_droplocaionbyid($bookinglists->devolucion);
                $pickuplocation = $this->booking_list->get_picklocaionbyid($bookinglists->recogida);
            $data['bookinglist'][] = array(
                'pick_city' => $pickuplocation[0]->city,
                'pick_state' => $pickuplocation[0]->address1,
                'pick_zipcode' => $pickuplocation[0]->ZipCode,
                'drop_city' => $droplocation[0]->city,
                'drop_state' => $droplocation[0]->address1,
                'drop_zipcode' => $droplocation[0]->ZipCode,
                'id' => $bookinglists->id,
                'bookid' => $bookinglists->reservaid,
                'date' => $bookinglists->fechadesolicitud,
                'image' => $bookinglists->vehicle,
                'modelNo' => $bookinglists->model,
                'vendor' => $bookinglists->vendor,
                'amount' => $bookinglists->amount,
                'currencycode' => $bookinglists->currencycode,
                'date' => $picktimenew[1],
                'timedate' => $picktimenew[1].','.$picktimenew[2],
                'time' => $picktimenew[2],
                'dropdate' => $droptimenew[1],
                'droptime' => $droptimenew[2],
            );
        }  //print_r($data['bookinglist']);die;
        $this->load->view('templates/header');
        $this->load->view('user_booking_pages/booking_list',$data);
        $this->load->view('templates/footer');
    }
    public function cancelcar(){
        $result = $this->booking_list->cancel_cars();
        $msg['success'] = false;
		if($result){
			$msg['success'] = true;
		}
		echo json_encode($msg);
    }
}
