<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tarifas_controller extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->model('Tarifas_model', 'tarifas_model');
    }
    public function tarifas_setup(){
        $datass = $this->tarifas_model->get_tarifas();
        echo $datass[0]['porcentaje'];
    }
}
