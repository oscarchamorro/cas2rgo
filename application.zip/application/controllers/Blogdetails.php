<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogdetails extends CI_Controller{
   function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Blogs_model','blogs_model');
    }
    public function index(){
        $blogid = $this->input->get('blogid');
        $data['blog_detail'] = array();
        $get_blogdetail = $this->blogs_model->get_blogdetail($blogid);
        foreach ($get_blogdetail as $get_blogdetails){
            $data['blog_detail'][] = array(
                'id' => $get_blogdetails->id,
                'title_name' => $get_blogdetails->title_name,
                'image' => $get_blogdetails->img,
                'discription' => $get_blogdetails->discription,
                //'discription' => html_entity_decode(substr($get_blogdetails->discription, 0, 165), ENT_QUOTES, 'UTF-8'),
                //'d_date' => date('d', strtotime($get_blogdetails->created_date)),
                'm_date' => date('d, M, Y', strtotime($get_blogdetails->created_date)),
            );
        }
        $this->load->view('templates/header');
        $this->load->view('Blog_form/blog_details',$data);
        $this->load->view('templates/footer');
    }
}
