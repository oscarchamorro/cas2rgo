<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paymentresult extends CI_Controller{
    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Paynow_Model', 'paynow');
    }
    public function index(){
       // print_r($this->input->get);die;
        if($this->input->get()){
            $data =array(
                'responsepasarella' => $this->input->get('ssl_result_message'),
                'phone1' => $this->input->get('ssl_phone'),
                'estado' => 1,
                //'responsepasarella' => $this->input->get(''),
            );
            $amountmail = $this->session->userdata('bookgetamount');
            $referencia = $amountmail['referencia'];
            $emilid = $this->input->get('ssl_email');
            $data = $this->security->xss_clean($data);
            $result = $this->paynow->updateAfter_payment($data,$emilid,$referencia);
            $approved = $result['responsepasarella'];
            $data['approved_list'] = $this->paynow->updateAfter_getdata($approved,$emilid,$referencia);
            $arraylocation =  $data['approved_list'];
            $data['plocatio'] = $arraylocation[0]->recogida;
            $data['devolucion'] = $arraylocation[0]->devolucion;
            $data['plocatio'] = explode(',',$data['plocatio']);
            $data['droplocatio'] = explode(',',$data['devolucion']);
            $this->load->view('home_pages/reservation_success',$data);
           
        }
        
    }
   

    public function setreservation($data = array(),$postvalue) {
       
        $this->security->xss_clean($this->input->post());
        if (empty($this->requestpost())) {
            $this->apperror('A request was not received');
        }
       
        //$formulario = $this->input->get('formulario');
        $formulario = strtolower($this->requestpost('formulario'));
        
        if (empty($formulario)) {
            $this->apperror('The form parameter is required.');
        }
        if (!preg_match('/^[a-z_]+$/i', $formulario)) {
            $this->apperror(
		'The form parameter can only have letters and scratches to the floor'
	);
        }
        $rutaArchivoFormulario = $this->ota_vehresrqcore($postvalue);
      
        if (empty($rutaArchivoFormulario)) {
            $this->apperror(
		'The definition for the form is not found "' .$formulario. '"'
	);
        }

        if (empty($rutaArchivoFormulario)) {
            $this->apperror(
		'Could not generate code for form "' .$formulario. '"'
	);
        }

        $details = $data['detail'];
        $urldata = $data['urllink'];
        $request = (
                '<?xml version="1.0" encoding="UTF-8"?>' .
                str_replace(
                        '<POS/>', (
                        '<POS>' .
                        '<Source' .
                        ' ISOCountry="BS"' .
                        ' AgentDutyCode="' . $details['validationCode'] . '"' .
                        '>' .
                        '<RequestorID' .
                        ' Type="4"' .
                        ' ID="' . $details['vendorNumber'] . '"' .
                        '>' .
                        '<CompanyName' .
                        ' Code="CP"' .
                        ' CodeContext="' . $details['consumerProductCode'] . '"' .
                        '/>' .
                        '</RequestorID>' .
                        '</Source><Source><RequestorID Type="5" ID="00203711"/></Source>' .
                        $this->wrapContent(
                                'Source', (
                                $this->postWrap(
                                        ['compania'], ['<RequestorID Type="8" ID="', '"/>']
                                )
                                )
                        ) .
                        '</POS>'
                        ), $rutaArchivoFormulario
                )
                );
        $response = file_get_contents(
                $urldata['test'], false, stream_context_create(
                        [
                            'http' => [
                                'header' => (
                                "Content-type: application/x-www-form-urlencoded\r\n"
                                ),
                                'method' => 'POST',
                                'content' => 'xmldata=' . $request,
                            ],
                        ]
                )
        );
        file_put_contents($formulario . '_' . $this->input->post('compania') . '_request.xml', $request);
        file_put_contents($formulario . '_' .$this->input->post('compania') . '_response.xml', $response);
       //echo $response; die;
        $this->appreply(simplexml_load_string($response));
        //echo '<script>window.location="index.php"</script>';
    }

    public function getreservation() {
        $this->load->model('Carlist_model', 'carlist_model');
        $rowresultmantenimiento = $this->carlist_model->get_mantenimiento();
        $mantenimiento = $rowresultmantenimiento[0]->estado;
        if ($mantenimiento == 0) {
            $data['detail'] = array(
                'consumerProductCode' => 'TT2G',
                'validationCode' => 'D3C23R7G15O',
                'vendorNumber' => 'T303',
            );
            $data['urllink'] = array(
                'test' => 'https://vv.xnet.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a',
            );
        } else {
            $data['detail'] = array(
                'consumerProductCode' => 'TT2G',
                'validationCode' => 'D3C23R7G15O',
                'vendorNumber' => 'T303',
            );
            $data['urllink'] = array(
                'test' => 'https://vv.xnet.hertz.com/DirectLinkWEB/handlers/DirectLinkHandler?id=ota2007a',
            );
        }
        
        $this->setreservation($data,$this->input->post());
    }

    public function clean(&$text) {
        $text = htmlspecialchars($text);
    }

    public function wrap($label, $attributes, $content = '', $requireContent = false) {
        $attributes = trim($attributes);
        if ((!$attributes && !$content) || ($requireContent && !$content)) {
            return '';
        }
        if ($content) {
            return (
                    '<' . $label . ($attributes ? ' ' . $attributes : '') . '>' .
                    $content .
                    '</' . $label . '>'
                    );
        }
        return '<' . $label . ' ' . $attributes . '/>';
    }

    public function wrapContent($label, $content) {
        return $this->wrap($label, '', $content);
    }

    public function wrapIfContent($label, $attributes, $content) {
        return $this->wrap($label, $attributes, $content, true);
    }
    
    public function requestpost($keys=[]){
		$return = $this->input->post();
		if(empty($keys)){
			return $return;
		}
		if(!is_array($keys)){
			$keys = [$keys];
		}
		for($i=0; $i<count($keys); $i++){
			if(isset($return[$keys[$i]])){
				if($i === count($keys)-1){
					return $return[$keys[$i]];
				}else{
					$return = $return[$keys[$i]];
				}
			}else{
				break;
			}
		}
		return '';
	}
	public function postWrap($keys, $wraps=''){
		return $this->textwrap($wraps, $this->requestpost($keys));
	}
        
        public function textwrap($wraps, $text){
		if(empty($text)){
			return '';
		}
		if(is_array($wraps)){
			$return = $wraps[0].$text;
			if(isset($wraps[1])){
				return $return.$wraps[1];
			}
			return $return;
		}
		return $wraps;
	}
        
        public function append($data, $error){
		die(
                    json_encode([
                            'datos' => $data,
                            'error' => $error,
                    ])
		);
	}
	public function apperror($error){
		$this->append('', $error);
	}
	public function appreply($data){
            //print_r($data);die;
		$this->append($data, '');
	}
public function ota_vehresrqcore($data = array()){
    $telefonos = '';
    $indice = 0;
    while($this->requestpost(['telefono',$indice])){
            $telefonos .= $this->wrap(
                    'Telephone',
                    (
                            $this->postWrap(
                                    ['telefono', $indice, 'tecnologia'],
                                    [' PhoneTechType="', '"']
                            ) .
                            $this->postWrap(
                                    ['telefono', $indice, 'codigoarea'],
                                    [' AreaCityCode="', '"']
                            ) .
                            $this->postWrap(
                                    ['telefono', $indice, 'numero'],
                                    [' PhoneNumber="', '"']
                            )
                    )
            );
            $indice++;
    }
    $documentos = '';
    $indice = 0;
    while($this->requestpost(['documento',$indice])){
            $documentos .= $this->wrap(
                    'Document',
                    (
                            $this->postWrap(
                                    ['documento', $indice, 'tipo'],
                                    [' DocType="', '"']
                            ) .
                            $this->postWrap(
                                    ['documento', $indice, 'numero'],
                                    [' DocID="', '"']
                            ) .
                            $this->postWrap(
                                    ['documento', $indice, 'ubicacion'],
                                    [' DocIssueLocation="', '"']
                            ) .
                            $this->postWrap(
                                    ['documento', $indice, 'pais'],
                                    [' DocIssueCountry="', '"']
                            ) .
                            $this->postWrap(
                                    ['documento', $indice, 'vencimiento'],
                                    [' ExpireDate="', '"']
                            )
                    )
            );
            $indice++;
    }
    $membresias = '';
    $indice = 0;
    while($this->requestpost(['membresia',$indice])){
            $membresias .= $this->wrap(
                    'CustLoyalty',
                    (
                            $this->postWrap(
                                    ['membresia', $indice, 'numero'],
                                    [' MembershipID="', '"']
                            ) .
                            $this->postWrap(
                                    ['membresia', $indice, 'programa'],
                                    [' ProgramID="', '"']
                            ) .
                            $this->postWrap(
                                    ['membresia', $indice, 'sector'],
                                    [' TravelSector="', '"']
                            )
                    )
            );
            $indice++;
    }
    $preferenciasEspeciales = '';
    $indice = 0;
    while($this->requestpost(['equipamientoespecial',$indice])){
            $preferenciasEspeciales .= $this->wrap(
                    'SpecialEquipPref',
                    (
                            $this->postWrap(
                                    ['equipamientoespecial', $indice, 'tipo'],
                                    [' EquipType="', '"']
                            ) .
                            $this->postWrap(
                                    ['equipamientoespecial', $indice, 'cantidad'],
                                    [' Quantity="', '"']
                            )
                    )
            );
            $indice++;
    }
    $serviciosOtraUbicacion = '';
    $indice = 0;
    while($this->requestpost(['serviciootraubicacion',$indice])){
            $membresias .= $this->wrap(
                    'OffLocService',
                    (
                            $this->postWrap(
                                    ['serviciootraubicacion', $indice, 'tipo'],
                                    [' Type="', '"']
                            ) .
                            $this->postWrap(
                                    ['serviciootraubicacion', $indice, 'instrucciones'],
                                    [' SpecInstructions="', '"']
                            )
                    ),
                    (
                            $this->wrap(
                                    'Address',
                                    (
                                            $this->postWrap(
                                                    ['serviciootraubicacion', $indice, 'direccion'],
                                                    ['<AddressLine>', '</AddressLine>']
                                            ) .
                                            $this->postWrap(
                                                    ['serviciootraubicacion', $indice, 'direccioncomplemento'],
                                                    ['<AddressLine>', '</AddressLine>']
                                            ) .
                                            $this->postWrap(
                                                    ['serviciootraubicacion', $indice, 'ciudad'],
                                                    ['<CityName>', '</CityName>']
                                            ) .
                                            $this->postWrap(
                                                    ['serviciootraubicacion', $indice, 'codigopostal'],
                                                    ['<PostalCode>', '</PostalCode>']
                                            ) .
                                            $this->postWrap(
                                                    ['serviciootraubicacion', $indice, 'departamento'],
                                                    ['<StateProv StateCode="', '"/>']
                                            ) .
                                            $this->postWrap(
                                                    ['serviciootraubicacion', $indice, 'pais'],
                                                    ['<CountryName Code="', '"/>']
                                            )
                                    )
                            ) .
                            $this->wrap(
                                    'Telephone',
                                    $this->postWrap(
                                            ['serviciootraubicacion', $indice, 'telefono'],
                                            [' PhoneNumber="', '"']
                                    )
                            )
                    )
            );
            $indice++;
    }
    $xml = (
            '<OTA_VehResRQ' .
            ' xmlns="http://www.opentravel.org/OTA/2003/05"' .
            ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' .
            ' xsi:schemaLocation="http://www.opentravel.org/OTA/2003/05 OTA_VehResRQ.xsd"' .
            ' Version="1.008"' .
            '>' .
                    '<POS/>' .
                    '<VehResRQCore Status="All">' .
                            '<VehRentalCore' .
                            ' PickUpDateTime="' .
                                    $this->requestpost(['recogida','fecha']) .
                                    'T' .
                                    $this->requestpost(['recogida','hora']). ':00' .
                                    '"' .
                            ' ReturnDateTime="' .
                                    $this->requestpost(['devolucion','fecha']) .
                                    'T' .
                                    $this->requestpost(['devolucion','hora']). ':00' .
                                    '"' .
                            '>' .
                                    '<PickUpLocation' .
                                    ' LocationCode="' .$this->requestpost(['recogida','lugar']). '"' .
                                    '/>' .
                                    '<ReturnLocation' .
                                    ' LocationCode="' .$this->requestpost(['devolucion','lugar']). '"' .
                                    '/>' .
                            '</VehRentalCore>' .
                            '<Customer>' .
                                    '<Primary' .
                                            $this->postWrap(
                                                    'fechanacimiento',
                                                    [' BirthDate="', '"']
                                            ) .
                                    '>' .
                                            '<PersonName>' .
                                                    '<GivenName>' .$this->requestpost('nombre'). '</GivenName>' .
                                                    '<Surname>' .$this->requestpost('apellido'). '</Surname>' .
                                            '</PersonName>' .
                                            $telefonos .
                                            $this->postWrap(
                                                    'correo',
                                                    ['<Email>', '</Email>']
                                            ) .
                                            $this->wrap(
                                                    'Address',
                                                    (
                                                            $this->postWrap(
                                                                    'direccion',
                                                                    ['<AddressLine>', '</AddressLine>']
                                                            ) .
                                                            $this->postWrap(
                                                                    'direccioncomplemento',
                                                                    ['<AddressLine>', '</AddressLine>']
                                                            ) .
                                                            $this->postWrap(
                                                                    'ciudad',
                                                                    ['<CityName>', '</CityName>']
                                                            ) .
                                                            $this->postWrap(
                                                                    'codigopostal',
                                                                    ['<PostalCode>', '</PostalCode>']
                                                            ) .
                                                            $this->postWrap(
                                                                    'departamento',
                                                                    ['<StateProv StateCode="', '"/>']
                                                            ) .
                                                            $this->postWrap(
                                                                    'pais',
                                                                    ['<CountryName Code="', '"/>']
                                                            )
                                                    )
                                            ) .
                                            $documentos .
                                            $membresias .
                                    '</Primary>' .
                            '</Customer>' .
                            $this->wrap(
                                    'VehPref',
                                    (
                                            $this->postWrap(
                                                    ['preferencia', 'aireacondicionado', 'incluido'],
                                                    ' AirConditionInd="true"'
                                            ) .
                                            $this->postWrap(
                                                    ['preferencia', 'aireacondicionado', 'requerido'],
                                                    ' AirConditionPref="Only"'
                                            ) .
                                            $this->postWrap(
                                                    ['preferencia', 'transmision', 'tipo'],
                                                    [' TransmissionType="', '"']
                                            ) .
                                            $this->postWrap(
                                                    ['preferencia', 'transmision', 'requerido'],
                                                    ' TransmissionPref="Only"'
                                            ) .
                                            $this->postWrap(
                                                    ['preferencia', 'combustible'],
                                                    [' FuelType="', '"']
                                            ) .
                                            $this->postWrap(
                                                    ['preferencia', 'manejo'],
                                                    [' DriveType="', '"']
                                            )
                                    ),
                                    (
                                            $this->wrap(
                                                    'VehType',
                                                    (
                                                            $this->postWrap(
                                                                    ['preferencia', 'vehiculo', 'categoria'],
                                                                    [' VehicleCategory="', '"']
                                                            ) .
                                                            $this->postWrap(
                                                                    ['preferencia', 'vehiculo', 'puertas'],
                                                                    [' DoorCount="', '"']
                                                            )
                                                    )
                                            ) .
                                            $this->wrap(
                                                    'VehClass',
                                                    $this->postWrap(
                                                            ['preferencia', 'vehiculo', 'tamano'],
                                                            [' Size="', '"']
                                                    )
                                            )
                                    )
                            ).
                            $this->wrap(
                                    'RateQualifier',
                                    (
                                            $this->postWrap(
                                                    'codigotasa',
                                                    [' RateQualifier="','"']
                                            ) .
                                            $this->postWrap(
                                                    'uso',
                                                    [' TravelPurpose="1"']
                                            ) .
                                            $this->postWrap(
                                                    ['descuentos', 'compania'],
                                                    [' CorpDiscountNmbr="', '"']
                                            ) .
                                            $this->postWrap(
                                                    ['descuentos', 'promocion'],
                                                    [' PromotionCode="', '"']
                                            )
                                    )
                            ) .
                            $this->wrapContent(
                                    'SpecialEquipPrefs',
                                    $preferenciasEspeciales
                            ) .
                    '</VehResRQCore>' .
                    '<VehResRQInfo>' .
                            $this->postWrap(
                                    'requerimientoespecial',
                                    ['<SpecialReqPref>', '</SpecialReqPref>']
                            ) .
                            $serviciosOtraUbicacion .
                            $this->wrap(
                                    'ArrivalDetails',
                                    (
                                            $this->postWrap(
                                                    ['detallesllegada', 'trasnporte'],
                                                    [' TransportationCode="', '"']
                                            ) .
                                            $this->postWrap(
                                                    ['detallesllegada', 'numerovuelo'],
                                                    [' Number="', '"']
                                            )
                                    ),
                                    $this->postWrap(
                                            ['detallesllegada', 'aerolinea'],
                                            ['<OperatingCompany Code="', '"/>']
                                    )
                            ) .
                            $this->wrap(
                                    'TourInfo',
                                    $this->postWrap(
                                            'numerotour',
                                            [' TourNumber="', '"']
                                    )
                            ) .
                            $this->wrap(
                                    'RentalPaymentPref',
                                    '',
                                    $this->postWrap(
                                            'voucher',
                                            ['<Voucher SeriesCode="', '"/>']
                                    )
                            ) .
                            '<Reference Type="16" ID="' .$this->requestpost('referencia'). '"/>' .
                            $this->wrapIfContent(
                                    'WrittenConfInst',
                                    'ConfirmInd="true" LanguageID="ENUS"',
                                    $this->wrapIfContent(
                                            'Email',
                                            'DefaultInd="true"',
                                            $this->requestpost('correo')
                                    )
                            ) .
                    '</VehResRQInfo>' .
            '</OTA_VehResRQ>'
    );
    return $xml;
        }
    public function cancelpayment(){
        if($this->input->get()){
            $data =array(
                'responsepasarella' => $this->input->get('ssl_result_message'),
                'phone1' => $this->input->get('ssl_phone'),
                'estado' => 1,
                //'responsepasarella' => $this->input->get(''),
            );
            //$amountmail = $this->session->userdata('bookgetamount');
            //$referencia = $amountmail['referencia'];
            $referencia = base64_decode($this->input->get('rf'));
            $emilid = $this->input->get('ssl_email');
            $data = $this->security->xss_clean($data);
            $result = $this->paynow->updateAfter_payment($data,$emilid,$referencia);
        }
        $id = $this->input->get('id');
        $referencia = base64_decode($this->input->get('rf'));

        $data['invoiceshow'] = $this->paynow->getdata_invoiceCancel($id,$referencia);
        $plocatio = $data['invoiceshow'][0]->recogida;
        $dlocatio = $data['invoiceshow'][0]->devolucion;
        
        $pickuplocation = $this->paynow->get_pickup($plocatio);
        $data['pickuplocation'] = ucwords(strtolower($pickuplocation[0]->description.' - '.$pickuplocation[0]->state1.' - '.$pickuplocation[0]->city.' - '.$pickuplocation[0]->Country));
        $droplocation = $this->paynow->get_drop($dlocatio);
        $data['droplocation']= ucwords(strtolower($droplocation[0]->description.' - '.$droplocation[0]->state1.' - '.$droplocation[0]->city.' - '.$droplocation[0]->Country));
        //print_r($data['pickuplocation']);die;
        $this->load->view('templates/header');
        $this->load->view('home_pages/cancelinvoice_view',$data);
        $this->load->view('templates/footer');
    }
}
