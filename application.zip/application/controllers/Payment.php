<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller{
    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Paynow_Model', 'paynow');
    }
    public function index(){
        
        $agentid=0;
        if($this->session->userdata('logged_in')){
            if($this->session->userdata('user_data_session')){
                $user_detail = $this->session->userdata('user_data_session');
                $email = $user_detail['email'];
                
            }
        }
        if(isset($email)){
                if($email != NULL){
                        $agentid=$email;
                }
        }else{
                $email = 0;
        }
        $recogidadata='';
        foreach($this->input->post('recogida') AS $recogida){
            $recogidadata = $recogidadata.','.$recogida;
        }
        $devoluciondata = '';
        foreach($this->input->post('devolucion') AS $devolucion){
                $devoluciondata = $devoluciondata.','.$devolucion;
        }
        $recogidadata = trim($recogidadata,',');
        $devoluciondata = trim($devoluciondata,',');
        
        $resultperfil = $this->paynow->getdatauser_byid($email);
        
        $rowperfil['perfil'] = 0;
        $rowperfil['commission'] = 0;
        $rowperfil['payment'] = 0;
        if($this->input->post()){
            $data = array(
                'recogida' => $recogidadata,
                'devolucion' => $devoluciondata,
                'referencia' => $this->input->post('referencia'),
                'nombre' => $this->input->post('nombre'),
                'apellido' => $this->input->post('apellido'),
                'correo' => $this->input->post('correo'),
                'reservaid' => 'WAIT',
                'numerotour' => $this->input->post('numerotour'),
                'amount' => $this->input->post('amount'),
                'currencycode' => $this->input->post('currencycode'),
                'model' => $this->input->post('model'),
                'vehicle' => $this->input->post('vehicle'),
                'vendor' => $this->input->post('compania'),
                'fechadesolicitud' => date('Y-m-d H:m:s'),
                'pago' => $rowperfil['payment'],
                'agentid' => $agentid,
                'estado' => 0,
            );
            $this->session->set_userdata('bookgetamount',$data);
            $this->session->userdata('bookgetamount');
            $data = $this->security->xss_clean($data);
            $result = $this->paynow->save_paymentdone($data);
           if($result){
           // redirect('paymentprocessing');
            redirect('authorize');
            }
        }
        $this->load->view('templates/header');
        $this->load->view('home_pages/cars_listing');
        $this->load->view('templates/footer');
    }
}
