<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InvoiceInfo extends CI_Controller{
    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Paynow_Model', 'paynow');
    }
    public function index(){
        
        $this->load->view('templates/header');
        $this->load->view('home_pages/invoiceinfomation_view');
        $this->load->view('templates/footer');
    }
}
