<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rejectedlist extends CI_Controller{
   function __construct() {
        parent::__construct();
        if(!$this->session->userdata('logged_in')){
            redirect('user_auth/login');
        }
        $this->load->model('UserBookinglisting_model','booking_list');
    }

    public function index(){
        $userdetail=$this->session->userdata('user_data_session');
        $email = $userdetail['email'];
        $data['rejectedlist'] = array();
        $rejectedlist = $this->booking_list->get_rejectedlist($email);
        foreach ($rejectedlist as $rejectedlists){
                $droplocation = $this->booking_list->get_droplocaionbyid($rejectedlists->devolucion);
                $pickuplocation = $this->booking_list->get_picklocaionbyid($rejectedlists->recogida);
            $data['rejectedlist'][] = array(
                'pick_city' => $pickuplocation[0]->city,
                'pick_state' => $pickuplocation[0]->address1,
                'pick_zipcode' => $pickuplocation[0]->ZipCode,
                'drop_city' => $droplocation[0]->city,
                'drop_state' => $droplocation[0]->address1,
                'drop_zipcode' => $droplocation[0]->ZipCode,
                'bookid' => $rejectedlists->reservaid,
                'date' => $rejectedlists->fechadesolicitud,
                'image' => $rejectedlists->vehicle,
                'modelNo' => $rejectedlists->model,
                'vendor' => $rejectedlists->vendor,
                'amount' => $rejectedlists->amount,
                'currencycode' => $rejectedlists->currencycode,
            );
        }
        $this->load->view('templates/header');
        $this->load->view('user_booking_pages/rejected_list',$data);
        $this->load->view('templates/footer');
    }
        
}
