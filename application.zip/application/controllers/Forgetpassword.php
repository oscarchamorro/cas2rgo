<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forgetpassword extends CI_Controller{
    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
        $this->load->model('Forgetpassword_model', 'forgetpasswordd');
    }
    public function index(){
        $this->load->library('email');
        $token = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 50);
            
        $mail = $this->input->post('email');
        $tokens = array('token'=>$token);
        $result = $this->forgetpasswordd->reset_password_insert($mail,$tokens);
       if($result){
           $this->sendmail($result);
           echo $result;
       }
        
    }
    public function sendmail($result){
         $this->load->library('email');
         $mail = $this->input->post('email');
         $tokens = $result['token'];
         $url =  base_url('assets/images/logo.png');
        $config = Array(    
              'protocol' => 'sendmail',
              'smtp_host' => 'mail.cars2gorentals.com',
              'smtp_port' => 587,
              'smtp_user' => 'no-reply@cars2gorentals.com',
              'smtp_pass' => 'Colombia.2018',
              'smtp_timeout' => '4',
              'mailtype' => 'html',
              'charset' => 'iso-8859-1'
            );
            $subject = 'Password Reset';
            $message = '';
            $message .= "<h2>You are receiving this message in response to your request for password reset</h2>"
                    . "<p>Follow this link to reset your password <a href='". base_url('passwordreset?token='.$tokens)."'>Reset Password(Click)</a> </p>"
                    . "<p>If You did not make this request kindly ignore!</p>"
                    . "<P class='pj'><h2>Kind Regard: Cars2Go</h2></p>"
                   ."<img src='".$url."' width='150'>"
                    . "<style>"
                    . ".pj{"
                    . "color:green;"
                    . "}"
                    . "</style>"
                    . "";

            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->from('no-reply@orient.com.co', 'Cars2GoRentals');
            $this->email->to($mail); 
            $this->email->subject('Forget Password');
            //print_r($message);die;
            $this->email->message($message); 
            $this->email->send();
    }
    
}
