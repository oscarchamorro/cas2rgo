<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Setup extends CI_Controller{
    function __construct() {
        parent::__construct();
        if(!$this->session->userdata('logged_in')){
            redirect('user_auth/login');
        }
        $this->load->model('Carlist_model','carlist_model');
    }
    
}
