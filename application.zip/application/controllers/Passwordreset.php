<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Passwordreset extends CI_Controller{
    function __construct() {
        parent::__construct();
//        if (!$this->session->userdata('logged_in')) {
//            redirect('user_auth/login');
//        }
         $this->load->model('Forgetpassword_model', 'forgetpasswordd');
    }
    public function index(){
      
        $this->form_validation->set_rules('pass', 'Password', 'required|min_length[5]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[pass]');              
        if($this->form_validation->run() === FALSE){
                    $this->load->view('templates/header');
                    $this->load->view('templates/forgetpassword_view');
                    $this->load->view('templates/footer');
            } else {
                $pass = md5($this->input->post('pass'));
                $tokens = $this->input->post('token');
                    $result = $this->forgetpasswordd->reset_password($tokens,$pass);
		$mail =$result[0]->email;
		
		if($mail){
			$this->sendmail($mail);
                    // Set message
                    $this->session->set_flashdata('password_changed', 'Congratulations you password is changed now!');
                    redirect('passwordreset?token='.$tokens);
                    $this->session->flashdata('password_changed');
					}
            }
    }
	public function sendmail($mail){
         $this->load->library('email');
         $url =  base_url('assets/images/logo.png');
        
        
        $config = Array(    
              'protocol' => 'sendmail',
              'smtp_host' => 'mail.cars2gorentals.com',
              'smtp_port' => 587,
              'smtp_user' => 'no-reply@cars2gorentals.com',
              'smtp_pass' => 'Colombia.2018',
              'smtp_timeout' => '4',
              'mailtype' => 'html',
              'charset' => 'iso-8859-1'
            );
            $subject = 'Congratulations you password is changed now';
            $message = '';
            $message .= "<h2>Congratulations! Your password is successfully changed!</h2>"
                    . "<p>Please login with your new password!</p>"
					. "<a href='".base_url('user_auth/login')."' target='_blank'>'".base_url('user_auth/login')."'</a>"
                    . "<p>If You did not make this request kindly ignore!</p>"
                    . "<P class='pj'><h2>Kind Regard: Cars2Go</h2></p>"
                    ."<img src='".$url."' width='150'>"
                    . "<style>"
                    . ".pj{"
                    . "color:green;"
                    . "}"
                    . "</style>"
                    . "";

            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");
            $this->email->from('no-reply@orient.com.co', 'Cars2GoRentals');
            $this->email->to($mail); 
            $this->email->subject('Forget Password');
            //print_r($message);die;
            $this->email->message($message); 
            $this->email->send();
    }
}
